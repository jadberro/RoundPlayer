#!/bin/bash
set -e

echo "[Setup] Configuring juggler_daemon.service..."
cat << 'EOF' > /etc/systemd/system/juggler_daemon.service
[Unit]
Description=Ballistic Music Juggler Master Playback Manager
After=network.target

[Service]
Type=simple
User=arduino
WorkingDirectory=/home/arduino/ball_bouncer
ExecStart=/usr/bin/python3 /home/arduino/ball_bouncer/playback_manager.py
Restart=always
RestartSec=3
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=default.target
EOF

echo "[Setup] Configuring juggler_dial.service with yt-cast-receiver..."
cat << 'EOF' > /etc/systemd/system/juggler_dial.service
[Unit]
Description=Ballistic Music Juggler YouTube Cast Receiver (yt-cast-receiver)
After=network.target juggler_daemon.service

[Service]
Type=simple
User=arduino
WorkingDirectory=/home/arduino/ball_bouncer/yt_receiver
ExecStart=/usr/bin/node /home/arduino/ball_bouncer/yt_receiver/index.mjs
Restart=always
RestartSec=3
Environment=NODE_ENV=production

[Install]
WantedBy=default.target
EOF

echo "[Setup] Configuring juggler_web.service..."
cat << 'EOF' > /etc/systemd/system/juggler_web.service
[Unit]
Description=Ballistic Music Juggler Mobile Web Remote
After=network.target juggler_daemon.service

[Service]
Type=simple
User=arduino
WorkingDirectory=/home/arduino/ball_bouncer
ExecStart=/usr/bin/python3 /home/arduino/ball_bouncer/web_remote.py
Restart=always
RestartSec=3
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=default.target
EOF

echo "[Setup] Setting up port 80 -> 8080 redirect for seamless http://juggler.local access..."
iptables -t nat -C PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 8080 2>/dev/null || \
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 8080

echo "[Setup] Reloading and restarting all systemd services..."
systemctl daemon-reload
systemctl enable juggler_daemon juggler_dial juggler_web
systemctl restart juggler_daemon juggler_dial juggler_web
echo "ALL_SERVICES_ONLINE_SUCCESS"
