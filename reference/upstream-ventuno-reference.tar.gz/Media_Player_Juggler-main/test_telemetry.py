import socket

s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
s.connect("/tmp/juggler_telemetry.sock")
print(s.recv(1024).decode())
