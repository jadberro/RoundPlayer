import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  runApp(const BallisticJugglerApp());
}

class BallisticJugglerApp extends StatelessWidget {
  const BallisticJugglerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ballistic Music Juggler',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const CircularHudScreen(),
    );
  }
}

enum PlinthMode {
  bootSequence,
  centerpiece,
  activePlayer,
  audiophileDeck,
  settingsMenu,
  cameraVision,
}

enum RepeatMode {
  off,
  all,
  one,
}

/// Universal tactile button providing instant sub-millisecond visual touch-down
/// feedback, depression animation, and immunity to gesture-arena slop cancellations.
class TactileButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double scaleFactor;
  final double minWidth;
  final double minHeight;
  final bool triggerOnTapDown;
  final Duration feedbackDuration;

  const TactileButton({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.scaleFactor = 0.93,
    this.minWidth = 0.0,
    this.minHeight = 0.0,
    this.triggerOnTapDown = false,
    this.feedbackDuration = const Duration(milliseconds: 70),
  });

  @override
  State<TactileButton> createState() => _TactileButtonState();
}

class _TactileButtonState extends State<TactileButton> {
  bool _isPressed = false;
  bool _alreadyTriggered = false;

  void _handleTapDown(TapDownDetails _) {
    if (widget.onTap == null) return;
    setState(() => _isPressed = true);
    if (widget.triggerOnTapDown && !_alreadyTriggered) {
      _alreadyTriggered = true;
      widget.onTap!();
    }
  }

  void _handleTapUp(TapUpDetails _) {
    setState(() => _isPressed = false);
    if (!widget.triggerOnTapDown && widget.onTap != null) {
      widget.onTap!();
    }
    _alreadyTriggered = false;
  }

  void _handleTapCancel() {
    if (mounted) setState(() => _isPressed = false);
    _alreadyTriggered = false;
  }

  @override
  Widget build(BuildContext context) {
    Widget content = widget.child;

    if (widget.minWidth > 0 || widget.minHeight > 0) {
      content = ConstrainedBox(
        constraints: BoxConstraints(
          minWidth: widget.minWidth,
          minHeight: widget.minHeight,
        ),
        child: content,
      );
    }

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: _handleTapDown,
      onTapUp: _handleTapUp,
      onTapCancel: _handleTapCancel,
      onLongPress: widget.onLongPress,
      child: AnimatedScale(
        scale: _isPressed ? widget.scaleFactor : 1.0,
        duration: widget.feedbackDuration,
        curve: Curves.easeOutCubic,
        child: content,
      ),
    );
  }
}

class CircularHudScreen extends StatefulWidget {
  const CircularHudScreen({super.key});

  @override
  State<CircularHudScreen> createState() => _CircularHudScreenState();
}

class _CircularHudScreenState extends State<CircularHudScreen>
    with TickerProviderStateMixin {
  late final Player _player;
  late final VideoController _videoController;

  // Active Plinth Mode & Previous Mode for Modal Navigation
  PlinthMode _currentMode = PlinthMode.bootSequence;
  PlinthMode _previousMode = PlinthMode.centerpiece;

  // Cinematic Boot Sequence
  late final AnimationController _bootController;

  // Luxury Idle Chronometer & Inactivity Management
  Timer? _inactivityTimer;
  Timer? _clockTimer;
  DateTime _currentClockTime = DateTime.now();
  int _idleTimeoutSeconds = 120;
  double _ambientBrightness = 0.85;

  // Immersive Media Controls & Touch Gesture State
  bool _areControlsVisible = true;
  Timer? _controlsVisibilityTimer;
  int _seekRippleCount = 0;
  Timer? _seekRippleTimer;

  // Settings Modal State
  int _settingsTab = 0; // 0: Display, 1: Kinematics, 2: Audio, 3: Pairing, 4: System

  // Animation controllers for kick beats and organic liquid wave motion
  late final AnimationController _beatPulseController;
  late final AnimationController _waveController;
  late final AnimationController _secondPulseController;

  // Subscriptions for media player state
  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<Duration>? _durationSub;
  StreamSubscription<bool>? _playingSub;
  StreamSubscription<bool>? _completedSub;

  // Media Player State Notifiers
  final ValueNotifier<Duration> _positionNotifier = ValueNotifier<Duration>(Duration.zero);
  final ValueNotifier<Duration> _durationNotifier = ValueNotifier<Duration>(const Duration(seconds: 225));
  final ValueNotifier<bool> _isPlayingNotifier = ValueNotifier<bool>(false);

  // WebSocket telemetry
  WebSocketChannel? _telemetryChannel;
  Timer? _reconnectTimer;

  // Real-time telemetry values (Driven via ValueNotifier for 0-allocation 60 FPS repaints)
  final ValueNotifier<int> _bpmNotifier = ValueNotifier<int>(126);
  final ValueNotifier<double> _phaseErrorNotifier = ValueNotifier<double>(0.0);
  final ValueNotifier<double> _apexHeightNotifier = ValueNotifier<double>(416.2);
  final ValueNotifier<String> _ballStateNotifier = ValueNotifier<String>('AIRBORNE');
  final ValueNotifier<double> _pitchNotifier = ValueNotifier<double>(0.0);
  final ValueNotifier<double> _rollNotifier = ValueNotifier<double>(0.0);

  // Search & Track states
  bool _isSearchOpen = false;
  bool _isQueueOpen = false;
  bool _isRadialCarouselOpen = false;
  double _carouselAngle = 0.0;
  Socket? _telemetrySocket;
  StreamSubscription? _socketSub;
  bool _isShiftUpper = true;
  bool _isArabicKeyboard = false;
  String _searchQuery = '';
  List<Map<String, dynamic>> _searchResults = [];
  List<Map<String, dynamic>> _cachedTracks = [];
  bool _isLoadingTracks = false;
  bool _isSwitchingTrack = false;
  Timer? _searchDebounceTimer;

  // Hi-Fi Lossless & Audiophile Deck State
  bool _isHiFi = false;
  String _audioFormat = 'FLAC';
  int _bitDepth = 24;
  int _sampleRateHz = 44100;
  String _currentAlbumName = '';
  int _hifiCatalogVersion = 0;
  bool _isHiFiBrowserOpen = false;
  Map<String, dynamic>? _hifiTree;
  bool _isLoadingHiFiTree = false;
  int _hifiBrowserLevel = 0; // 0: Artists, 1: Albums, 2: Tracks
  String _hifiSelectedArtist = '';
  String _hifiSelectedAlbum = '';
  List<Map<String, dynamic>> _hifiArtistList = [];
  List<Map<String, dynamic>> _hifiAlbumList = [];
  List<Map<String, dynamic>> _hifiTrackList = [];
  List<Map<String, dynamic>> _currentHiFiPlaylist = [];
  int _currentHiFiTrackIndex = 0;
  bool _isSearchHiFiMode = false;
  List<Map<String, dynamic>> _hifiFlatTrackIndex = [];
  List<Map<String, dynamic>> _hifiSearchResults = [];
  int _hifiNavTab = 0; // 0 = Artists, 1 = Playlists, 2 = Smart Mixes
  List<Map<String, dynamic>> _hifiPlaylists = [];
  bool _isLoadingPlaylists = false;
  String _hifiSelectedPlaylistId = '';
  String _hifiSelectedPlaylistName = '';
  List<Map<String, dynamic>> _hifiPlaylistTracks = [];
  final ScrollController _hifiArtistScrollController = ScrollController();
  late final AnimationController _vinylRotationController;
  bool _isShuffleEnabled = false;
  RepeatMode _repeatMode = RepeatMode.all;
  int _vinylCenterViewMode = 0; // 0 = Album Art, 1 = Audio Visualizer Waves, 2 = Hi-Res Specs

  // OV9281 Machine Vision & 3D Ball Tracking State
  Uint8List? _latestVisionFrameBytes;
  StreamSubscription<List<int>>? _visionStreamSub;
  http.Client? _visionHttpClient;

  // Audiophile DAC Pro (PCM5122) & PipeWire Settings State
  Map<String, dynamic> _audioSettings = {
    'filter': 'ringless',
    'analog-gain': '0',
    'pw-resample-quality': 14,
    'pw-keep-awake': 'on',
    'ramp': '1/0.5dB',
    'volume': 0.0,
    'channels': 'stereo',
  };
  Map<String, dynamic> _liveDacReadback = {
    'volume L/R': '+0.0 dB / +0.0 dB',
    'filter': 'ringless',
    'state': 'playing',
    'PLL': 'locked',
  };
  bool _isLoadingAudioSettings = false;
  String? _audioSettingsFeedback;

  Future<void> _loadAudioSettings() async {
    setState(() => _isLoadingAudioSettings = true);
    try {
      final res = await http.get(Uri.parse('http://127.0.0.1:8000/api/audio/settings')).timeout(const Duration(seconds: 3));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            if (data['settings'] != null) {
              _audioSettings = Map<String, dynamic>.from(data['settings']);
            }
            if (data['live'] != null) {
              _liveDacReadback = Map<String, dynamic>.from(data['live']);
            }
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _isLoadingAudioSettings = false);
  }

  Future<void> _updateAudioSetting(String key, dynamic value) async {
    setState(() {
      _audioSettings[key] = value;
      _audioSettingsFeedback = 'Applying $key: $value...';
    });
    try {
      final res = await http.post(
        Uri.parse('http://127.0.0.1:8000/api/audio/settings'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({key: value.toString()}),
      ).timeout(const Duration(seconds: 6));
      if (res.statusCode == 200) {
        if (mounted) {
          setState(() => _audioSettingsFeedback = '✓ $key: $value saved (survives reboot)');
        }
        await Future.delayed(const Duration(milliseconds: 1500));
        if (mounted) setState(() => _audioSettingsFeedback = null);
      }
      _loadAudioSettings();
    } catch (_) {
      if (mounted) setState(() => _audioSettingsFeedback = null);
    }
  }

  Future<void> _applyBestQualityPreset() async {
    setState(() => _audioSettingsFeedback = 'Applying Audiophile Preset (Ringless / 14 / Keep-Awake)...');
    try {
      await http.post(Uri.parse('http://127.0.0.1:8000/api/audio/preset/best-quality')).timeout(const Duration(seconds: 6));
      await _loadAudioSettings();
      if (mounted) {
        setState(() => _audioSettingsFeedback = '✓ Preset Active: 32-bit Hi-Res, Ringless, 14x Resample');
        await Future.delayed(const Duration(seconds: 2));
        if (mounted) setState(() => _audioSettingsFeedback = null);
      }
    } catch (_) {
      if (mounted) setState(() => _audioSettingsFeedback = null);
    }
  }

  Future<void> _resetAudioSettings() async {
    setState(() => _audioSettingsFeedback = 'Restoring DAC Factory Defaults...');
    try {
      await http.post(Uri.parse('http://127.0.0.1:8000/api/audio/reset')).timeout(const Duration(seconds: 6));
      await _loadAudioSettings();
      if (mounted) {
        setState(() => _audioSettingsFeedback = '✓ Factory Defaults Restored');
        await Future.delayed(const Duration(seconds: 2));
        if (mounted) setState(() => _audioSettingsFeedback = null);
      }
    } catch (_) {
      if (mounted) setState(() => _audioSettingsFeedback = null);
    }
  }
  bool _isVisionStreaming = false;
  String _visionColorMode = 'cyberpunk'; // 'cyberpunk', 'heatmap', 'monochrome'
  double _visionFps = 118.5;
  double _visionLatencyMs = 2.4;
  int _visionExposureUs = 1200;
  String _visionCameraModel = 'OV9281 GLOBAL SHUTTER';
  int _visionBallCount = 2;
  List<Map<String, dynamic>> _visionTrackedBalls = [];

  // City Search Overlay & On-Screen Touch Keyboard State
  bool _isCitySearchOpen = false;
  String _citySearchQuery = '';
  List<Map<String, dynamic>> _citySearchResults = [];
  bool _isLoadingCities = false;
  Timer? _citySearchDebounceTimer;
  bool _isCitySearchArabic = false;
  bool _isCityShiftUpper = true;
  String? _lastTelemetryTrackId;

  // Real-time Network Weather & Circadian State
  String _weatherCity = 'Sheffield';
  double _weatherTemp = 12.0;
  int _weatherCode = 0;
  int _weatherIsDay = 1;
  String _weatherCondition = 'Clear';
  Color _weatherThemeColor = const Color(0xFF38BDF8);
  Timer? _weatherPollTimer;

  IconData _getWeatherIcon(int code, int isDay) {
    if (code <= 1) {
      return isDay == 1 ? Icons.wb_sunny_rounded : Icons.nightlight_round;
    } else if (code <= 3) {
      return isDay == 1 ? Icons.cloud_rounded : Icons.nights_stay_rounded;
    } else if (code == 45 || code == 48) {
      return Icons.foggy;
    } else if (code >= 51 && code <= 67) {
      return Icons.grain_rounded;
    } else if (code >= 71 && code <= 77) {
      return Icons.ac_unit_rounded;
    } else if (code >= 80 && code <= 82) {
      return Icons.water_drop_rounded;
    } else if (code >= 95) {
      return Icons.thunderstorm_rounded;
    }
    return Icons.cloud_rounded;
  }

  Future<void> _fetchWeather() async {
    try {
      final res = await http.get(Uri.parse('http://127.0.0.1:8000/api/weather')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final city = data['city'] as String? ?? 'Sheffield';
        final temp = (data['temperature'] as num?)?.toDouble() ?? 12.0;
        final code = (data['weather_code'] as num?)?.toInt() ?? 0;
        final isDay = (data['is_day'] as num?)?.toInt() ?? 1;
        final cond = data['condition'] as String? ?? 'Clear';
        final colorHex = data['circadian_color'] as String? ?? '#38BDF8';
        final color = Color(int.parse(colorHex.replaceFirst('#', '0xFF')));

        if (mounted) {
          setState(() {
            _weatherCity = city;
            _weatherTemp = temp;
            _weatherCode = code;
            _weatherIsDay = isDay;
            _weatherCondition = cond;
            _weatherThemeColor = color;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _selectCity(String cityName, {double? lat, double? lon}) async {
    final query = cityName.startsWith('Auto') ? 'auto' : cityName;
    try {
      final payload = <String, dynamic>{'city': query};
      if (lat != null && lon != null) {
        payload['lat'] = lat;
        payload['lon'] = lon;
      }
      final res = await http.post(
        Uri.parse('http://127.0.0.1:8000/api/weather/city'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 5));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final w = data['weather'] as Map<String, dynamic>?;
        if (w != null && mounted) {
          final colorHex = w['circadian_color'] as String? ?? '#38BDF8';
          final color = Color(int.parse(colorHex.replaceFirst('#', '0xFF')));
          setState(() {
            _weatherCity = w['city'] ?? cityName;
            _weatherTemp = (w['temperature'] as num?)?.toDouble() ?? _weatherTemp;
            _weatherCondition = w['condition'] ?? _weatherCondition;
            _weatherCode = (w['weather_code'] as num?)?.toInt() ?? _weatherCode;
            _weatherIsDay = (w['is_day'] as num?)?.toInt() ?? 1;
            _weatherThemeColor = color;
          });
        }
      }
    } catch (e) {
      debugPrint('Error selecting weather city: $e');
    }
  }

  void _showCitySelectionDialog() {
    _resetInactivityTimer();
    setState(() {
      _isCitySearchOpen = true;
      _citySearchQuery = '';
      _citySearchResults = [];
      _isLoadingCities = false;
    });
  }

  Future<void> _performCitySearch(String query) async {
    final cleanQuery = query.trim();
    if (cleanQuery.length < 2) {
      if (mounted) {
        setState(() {
          _citySearchResults = [];
          _isLoadingCities = false;
        });
      }
      return;
    }
    if (mounted) setState(() => _isLoadingCities = true);
    try {
      final res = await http
          .get(Uri.parse('http://127.0.0.1:8000/api/weather/search?q=${Uri.encodeComponent(cleanQuery)}'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final List list = data['results'] as List? ?? [];
        if (mounted) {
          setState(() {
            _citySearchResults = list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
            _isLoadingCities = false;
          });
        }
        return;
      }
    } catch (e) {
      debugPrint('City search error: $e');
    }
    if (mounted) setState(() => _isLoadingCities = false);
  }

  void _triggerDebouncedCitySearch() {
    _citySearchDebounceTimer?.cancel();
    if (_citySearchQuery.trim().length >= 2) {
      _citySearchDebounceTimer = Timer(const Duration(milliseconds: 350), () {
        _performCitySearch(_citySearchQuery);
      });
    } else {
      if (mounted) {
        setState(() {
          _citySearchResults = [];
          _isLoadingCities = false;
        });
      }
    }
  }

  void _onCityKeyTapped(String char) {
    setState(() {
      if (char == 'BKSP' || char == 'DEL') {
        if (_citySearchQuery.isNotEmpty) {
          _citySearchQuery = _citySearchQuery.substring(0, _citySearchQuery.length - 1);
        }
      } else if (char == 'SPACE') {
        _citySearchQuery += ' ';
      } else if (char == 'CLEAR') {
        _citySearchQuery = '';
      } else if (char == 'SHIFT') {
        _isCityShiftUpper = !_isCityShiftUpper;
        return;
      } else if (char == 'LANG') {
        _isCitySearchArabic = !_isCitySearchArabic;
        return;
      } else {
        if (_isCitySearchArabic) {
          _citySearchQuery += char;
        } else {
          _citySearchQuery += _isCityShiftUpper ? char.toUpperCase() : char.toLowerCase();
        }
      }
    });
    _triggerDebouncedCitySearch();
  }

  void _openPlayer() {
    setState(() {
      _currentMode = _isHiFi ? PlinthMode.audiophileDeck : PlinthMode.activePlayer;
    });
    _resetInactivityTimer();
    _resetControlsVisibilityTimer();
    if (_activeVideoId == 'standby') {
      if (_isHiFi && _currentHiFiPlaylist.isNotEmpty) {
        final track = _currentHiFiPlaylist[_currentHiFiTrackIndex];
        final trackId = track['track_id']?.toString() ?? track['id']?.toString() ?? '';
        _playHiFiTrack(trackId, playlist: _currentHiFiPlaylist, index: _currentHiFiTrackIndex);
      } else if (_cachedTracks.isNotEmpty) {
        _playTrack(_cachedTracks.first);
      }
    } else if (!_isPlayingNotifier.value) {
      _player.play();
    }
  }

  // Volume state
  final ValueNotifier<double> _volumeNotifier = ValueNotifier<double>(100.0);
  double _lastVolumeBeforeMute = 100.0;
  Timer? _volumeSyncDebounce;

  // Dynamic prominent glow color (Smooth Organic Blending)
  final ValueNotifier<Color> _dominantColorNotifier = ValueNotifier<Color>(const Color(0xFF00E5FF));
  late final AnimationController _colorBlendController;
  Color _fromColor = const Color(0xFF00E5FF);
  Color _targetColor = const Color(0xFF00E5FF);

  void _smoothTransitionDominantColor(Color newColor) {
    if (newColor == _targetColor) return;
    _fromColor = _dominantColorNotifier.value;
    _targetColor = newColor;
    _colorBlendController.reset();
    _colorBlendController.forward();
  }

  // True aubio beats.npy tracking
  List<double> _beatTimestamps = [];
  double _currentTrackBpm = 103.0;
  DateTime _lastPositionUpdateTime = DateTime.now();
  double _lastKnownPositionSec = 0.0;

  // Current track state (Default to official motion music video for Daft Punk - Burnin')
  String _currentTrackTitle = "Daft Punk - Burnin' (Official Music Video)";
  String _currentArtist = 'Daft Punk';
  String _activeVideoId = 'DBHipNYuAZk';
  int _currentPlaylistIndex = 0;

  // Background 1080p preparation queue state (plays current song while downloading next)
  String? _preparingVideoId;
  String? _preparingTrackTitle;
  String? _preparingTrackArtist;
  double _preparingProgress = 0.0;
  int _preparingPercent = 0;
  String _preparingStatus = '';
  Timer? _preparingPollTimer;

  // Pre-cast state memory to cleanly revert upon Stop Cast
  String? _preCastTrackId;
  String? _preCastTrackTitle;
  String? _preCastArtist;
  bool _preCastIsHiFi = false;
  Duration _preCastPosition = Duration.zero;

  @override
  void initState() {
    super.initState();

    _player = Player(
      configuration: const PlayerConfiguration(
        bufferSize: 32 * 1024 * 1024,
      ),
    );
    _player.setVolume(100.0);
    try {
      final p = _player.platform as dynamic;
      p.setProperty('ao', 'pipewire');
      p.setProperty('audio-samplerate', '0');
      p.setProperty('audio-format', 'no');
      p.setProperty('af', '');
      p.setProperty('gapless-audio', 'yes');
      p.setProperty('volume-max', '100');
      p.setProperty('replaygain', 'album');
      p.setProperty('replaygain-clip', 'no');
    } catch (e) {
      debugPrint('Failed to set audiophile mpv properties: $e');
    }
    _loadAudioSettings();
    _videoController = VideoController(_player);

    _bootController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..addListener(() {
      setState(() {});
    });

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {
          _currentClockTime = DateTime.now();
        });
      }
    });

    _bootController.forward().whenComplete(() {
      if (mounted) {
        setState(() {
          _currentMode = PlinthMode.centerpiece;
        });
        _resetInactivityTimer();
      }
    });

    _colorBlendController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400), // Organic 2.4s liquid color bleed
    )..addListener(() {
      final curved = Curves.easeInOutCubic.transform(_colorBlendController.value);
      _dominantColorNotifier.value = Color.lerp(_fromColor, _targetColor, curved) ?? _targetColor;
    });

    _beatPulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 582), // 103 BPM default
    )..repeat();

    _waveController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 8000), // 8s smooth continuous liquid flow
    )..repeat();

    _secondPulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1), // 1s second pulse
    )..repeat();

    _vinylRotationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800), // 33.3 RPM rotation feel
    );

    _setupPlayerListeners();
    _connectTelemetry();
    _loadCachedTracks();
    _loadHiFiTree();
    _fetchSettings();
    _fetchWeather();
    _weatherPollTimer = Timer.periodic(const Duration(minutes: 10), (_) => _fetchWeather());

    // Start playing official music video in standby on boot
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startInitialPlayback();
    });
  }

  void _resetInactivityTimer() {
    _inactivityTimer?.cancel();
    if (_idleTimeoutSeconds <= 0) return; // Never sleep
    _inactivityTimer = Timer(Duration(seconds: _idleTimeoutSeconds), () {
      if (mounted && (_currentMode == PlinthMode.activePlayer || _currentMode == PlinthMode.audiophileDeck) && !_isPlayingNotifier.value) {
        setState(() {
          _currentMode = PlinthMode.centerpiece;
        });
      }
    });
  }

  Future<void> _fetchSettings() async {
    try {
      final res = await http.get(Uri.parse('http://127.0.0.1:8000/api/settings')).timeout(const Duration(seconds: 2));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            _idleTimeoutSeconds = (data['idle_timeout_seconds'] as num?)?.toInt() ?? 120;
            _ambientBrightness = (data['ambient_brightness'] as num?)?.toDouble() ?? 0.85;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _saveSettings(Map<String, dynamic> patch) async {
    try {
      await http.post(
        Uri.parse('http://127.0.0.1:8000/api/settings'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(patch),
      ).timeout(const Duration(seconds: 2));
    } catch (_) {}
  }

  void _setupPlayerListeners() {
    _positionSub = _player.stream.position.listen((pos) {
      _positionNotifier.value = pos;
      _lastKnownPositionSec = pos.inMicroseconds / 1000000.0;
      _lastPositionUpdateTime = DateTime.now();
    });
    _durationSub = _player.stream.duration.listen((dur) {
      if (dur > Duration.zero) {
        _durationNotifier.value = dur;
      }
    });
    _playingSub = _player.stream.playing.listen((playing) {
      _isPlayingNotifier.value = playing;
      if (playing) {
        _lastPositionUpdateTime = DateTime.now();
        if (_isHiFi) {
          _vinylRotationController.repeat();
        }
        if (_currentMode == PlinthMode.centerpiece) {
          if (_activeVideoId == 'standby') {
            _player.pause();
            _isPlayingNotifier.value = false;
            return;
          }
          setState(() {
            _currentMode = _isHiFi ? PlinthMode.audiophileDeck : PlinthMode.activePlayer;
          });
        }
        _resetControlsVisibilityTimer();
      } else {
        if (_isHiFi) {
          _vinylRotationController.stop();
        }
        _controlsVisibilityTimer?.cancel();
        if (mounted && !_areControlsVisible) {
          setState(() => _areControlsVisible = true);
        }
        _resetInactivityTimer();
      }
    });
    _completedSub = _player.stream.completed.listen((completed) {
      if (completed) {
        if (_repeatMode == RepeatMode.one) {
          _player.seek(Duration.zero);
          _player.play();
        } else {
          _playNextTrack();
        }
      }
    });
  }

  Future<void> _fetchBeatsAndColor(String videoId) async {
    if (videoId.startsWith('hifi_')) {
      final cleanId = videoId.replaceFirst('hifi_', '');
      try {
        final res = await http.get(Uri.parse('http://127.0.0.1:8000/media/hifi/$cleanId/beats')).timeout(const Duration(seconds: 3));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          final rawBeats = data['beats'] as List? ?? [];
          _beatTimestamps = rawBeats.map((e) => (e as num).toDouble()).toList();
          final bpmVal = (data['bpm'] as num?)?.toDouble() ?? 120.0;
          _currentTrackBpm = bpmVal;
          _bpmNotifier.value = bpmVal.round();
        }
      } catch (_) {}
      return;
    }

    try {
      final res = await http.get(Uri.parse('http://127.0.0.1:8000/media/$videoId/beats')).timeout(const Duration(seconds: 3));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final rawBeats = data['beats'] as List? ?? [];
        _beatTimestamps = rawBeats.map((e) => (e as num).toDouble()).toList();
        final bpmVal = (data['bpm'] as num?)?.toDouble() ?? 103.0;
        _currentTrackBpm = bpmVal;
        _bpmNotifier.value = bpmVal.round();
      }
    } catch (_) {}

    try {
      final colorRes = await http.get(Uri.parse('http://127.0.0.1:8000/media/$videoId/dominant_color')).timeout(const Duration(seconds: 2));
      if (colorRes.statusCode == 200) {
        final data = jsonDecode(colorRes.body);
        final hex = data['color'] as String?;
        if (hex != null && hex.startsWith('#') && hex.length == 7) {
          final colorVal = Color(int.parse(hex.replaceFirst('#', '0xFF')));
          _smoothTransitionDominantColor(colorVal);
        }
      }
    } catch (_) {}
  }

  Future<void> _startInitialPlayback() async {
    try {
      _fetchBeatsAndColor(_activeVideoId);
      final initialUrl = 'http://127.0.0.1:8000/media/$_activeVideoId/video.mp4';
      await _player.open(Media(initialUrl), play: false);
      await _player.setVolume(_volumeNotifier.value);
      await _player.pause();
      _isPlayingNotifier.value = false;
    } catch (e) {
      debugPrint('Initial playback standby error: $e');
    }
  }

  @override
  void dispose() {
    _inactivityTimer?.cancel();
    _controlsVisibilityTimer?.cancel();
    _seekRippleTimer?.cancel();
    _volumeSyncDebounce?.cancel();
    _weatherPollTimer?.cancel();
    _clockTimer?.cancel();
    _searchDebounceTimer?.cancel();
    _citySearchDebounceTimer?.cancel();
    _reconnectTimer?.cancel();
    _socketSub?.cancel();
    _telemetrySocket?.destroy();
    _telemetryChannel?.sink.close();
    _positionSub?.cancel();
    _durationSub?.cancel();
    _playingSub?.cancel();
    _completedSub?.cancel();
    _preparingPollTimer?.cancel();
    _stopVisionStream();

    _bootController.dispose();
    _beatPulseController.dispose();
    _waveController.dispose();
    _secondPulseController.dispose();
    _vinylRotationController.dispose();
    _colorBlendController.dispose();
    _player.dispose();

    _positionNotifier.dispose();
    _durationNotifier.dispose();
    _isPlayingNotifier.dispose();
    _volumeNotifier.dispose();
    _dominantColorNotifier.dispose();

    _bpmNotifier.dispose();
    _phaseErrorNotifier.dispose();
    _apexHeightNotifier.dispose();
    _ballStateNotifier.dispose();
    _pitchNotifier.dispose();
    _rollNotifier.dispose();
    super.dispose();
  }

  void _handleTelemetryJson(String raw) {
    try {
      final data = jsonDecode(raw);
      if (data is! Map) return;
      _bpmNotifier.value = (data['bpm'] as num?)?.toInt() ?? 103;
      _phaseErrorNotifier.value = (data['phase_error_ms'] as num?)?.toDouble() ?? 0.0;
      _apexHeightNotifier.value = (data['apex_height_mm'] as num?)?.toDouble() ?? 416.2;
      _ballStateNotifier.value = data['ball_state']?.toString().toUpperCase() ?? 'AIRBORNE';
      _pitchNotifier.value = (data['paddle_pitch_deg'] as num?)?.toDouble() ?? 0.0;
      _rollNotifier.value = (data['paddle_roll_deg'] as num?)?.toDouble() ?? 0.0;

      if (data['vision'] != null && data['vision'] is Map) {
        final v = data['vision'] as Map;
        _visionFps = (v['fps'] as num?)?.toDouble() ?? _visionFps;
        _visionLatencyMs = (v['latency_ms'] as num?)?.toDouble() ?? _visionLatencyMs;
        _visionExposureUs = (v['exposure_us'] as num?)?.toInt() ?? _visionExposureUs;
        _visionBallCount = (v['ball_count'] as num?)?.toInt() ?? _visionBallCount;
        _visionCameraModel = v['camera_model']?.toString() ?? _visionCameraModel;
        if (v['balls'] != null && v['balls'] is List) {
          _visionTrackedBalls = List<Map<String, dynamic>>.from(v['balls']);
        }
      }
      if (data['color'] != null) {
        final hex = data['color'].toString();
        if (hex.startsWith('#') && hex.length == 7) {
          _smoothTransitionDominantColor(Color(int.parse(hex.replaceFirst('#', '0xFF'))));
        }
      }

      if (data['is_hifi'] != null) {
        _isHiFi = data['is_hifi'] as bool? ?? false;
      }
      if (data['audio_format'] != null) {
        _audioFormat = data['audio_format'].toString();
      }
      if (data['bit_depth'] != null) {
        _bitDepth = (data['bit_depth'] as num?)?.toInt() ?? 16;
      }
      if (data['sample_rate_hz'] != null) {
        _sampleRateHz = (data['sample_rate_hz'] as num?)?.toInt() ?? 44100;
      }
      if (data['title'] != null && data['title'].toString().isNotEmpty) {
        _currentTrackTitle = data['title'].toString();
      }
      if (data['artist'] != null && data['artist'].toString().isNotEmpty) {
        _currentArtist = data['artist'].toString();
      }
      if (data['album'] != null && data['album'].toString().isNotEmpty) {
        _currentAlbumName = data['album'].toString();
      }

      // Live catalog version sync: when GDrive or library changes, auto-refresh catalog
      if (data['hifi_catalog_version'] != null) {
        final v = (data['hifi_catalog_version'] as num?)?.toInt() ?? 0;
        if (_hifiCatalogVersion != 0 && v > _hifiCatalogVersion) {
          _hifiCatalogVersion = v;
          _loadHiFiTree();
        } else {
          _hifiCatalogVersion = v;
        }
      }

      if (data['shuffle'] != null && data['shuffle'] is bool) {
        _isShuffleEnabled = data['shuffle'] as bool;
      }
      if (data['repeat'] != null) {
        final rStr = data['repeat'].toString();
        if (rStr == 'one') {
          _repeatMode = RepeatMode.one;
        } else if (rStr == 'all') {
          _repeatMode = RepeatMode.all;
        } else if (rStr == 'off') {
          _repeatMode = RepeatMode.off;
        }
      }

      // Synchronize track playback from Master Playback Manager
      final trackId = data['track_id'] as String?;
      final isPlaying = data['is_playing'] as bool?;

      // Auto-wake & track live preparation if track is being cached
      final cachingVideoId = data['caching_video_id'] as String?;
      if (cachingVideoId != null && cachingVideoId.isNotEmpty) {
        if (_preparingVideoId == null && _activeVideoId != 'standby' && _activeVideoId != cachingVideoId) {
          _preCastTrackId = _activeVideoId;
          _preCastTrackTitle = _currentTrackTitle;
          _preCastArtist = _currentArtist;
          _preCastIsHiFi = _isHiFi;
          _preCastPosition = _positionNotifier.value;
        }
        if (_currentMode == PlinthMode.centerpiece) {
          if (mounted) {
            setState(() {
              _currentMode = _isHiFi ? PlinthMode.audiophileDeck : PlinthMode.activePlayer;
            });
            _resetInactivityTimer();
          }
        }
        final cTitle = data['caching_title'] as String? ?? 'Incoming Cast';
        final cArtist = data['caching_artist'] as String? ?? '';
        final cPercent = (data['caching_percent'] as num?)?.toInt() ?? 0;
        final cStep = data['caching_progress'] as String? ?? 'Preparing 1080p...';

        if (_preparingVideoId != cachingVideoId || _preparingPercent != cPercent || _preparingStatus != cStep) {
          if (mounted) {
            setState(() {
              _preparingVideoId = cachingVideoId;
              _preparingTrackTitle = cTitle;
              _preparingTrackArtist = cArtist;
              _preparingProgress = (cPercent / 100.0).clamp(0.0, 1.0);
              _preparingPercent = cPercent;
              _preparingStatus = cStep;
            });
          }
        }
      } else if (_preparingVideoId != null && (cachingVideoId == null || cachingVideoId.isEmpty)) {
        if (mounted) {
          setState(() {
            _preparingVideoId = null;
          });
        }
      }

      if (trackId == 'standby' && (cachingVideoId == null || cachingVideoId.isEmpty)) {
        _activeVideoId = 'standby';
        _isPlayingNotifier.value = false;
        if (mounted && _preparingVideoId != null) {
          setState(() {
            _preparingVideoId = null;
          });
        }
        _player.pause();
        if (_isHiFi) _vinylRotationController.stop();
        if (_currentMode != PlinthMode.centerpiece && _currentMode != PlinthMode.settingsMenu) {
          if (mounted) {
            setState(() {
              _currentMode = PlinthMode.centerpiece;
            });
            _resetInactivityTimer();
          }
        }
        _lastTelemetryTrackId = 'standby';
        return;
      }

      // Auto-wake from idle only if a NEW track or casting is initiated externally
      final bool isNewTrackSelected = (trackId != null &&
          trackId.isNotEmpty &&
          trackId != 'standby' &&
          trackId != _lastTelemetryTrackId);
      final bool isNewCastIncoming = (cachingVideoId != null &&
          cachingVideoId.isNotEmpty &&
          cachingVideoId != _preparingVideoId);

      if ((isNewTrackSelected || isNewCastIncoming) && _currentMode == PlinthMode.centerpiece) {
        if (mounted) {
          setState(() {
            _currentMode = _isHiFi ? PlinthMode.audiophileDeck : PlinthMode.activePlayer;
          });
          _resetInactivityTimer();
        }
      }

      if (trackId != null && trackId.isNotEmpty && trackId != _activeVideoId && trackId != 'standby' && !_isSwitchingTrack) {
        if (_preCastTrackId == null && _activeVideoId != 'standby') {
          _preCastTrackId = _activeVideoId;
          _preCastTrackTitle = _currentTrackTitle;
          _preCastArtist = _currentArtist;
          _preCastIsHiFi = _isHiFi;
          _preCastPosition = _positionNotifier.value;
        }
        _activeVideoId = trackId;
        if (mounted && _preparingVideoId == trackId) {
          setState(() {
            _preparingVideoId = null;
          });
        }
        _switchAndPlayFromTelemetry(trackId);
      }
      _lastTelemetryTrackId = trackId;

      if (isPlaying != null && isPlaying != _isPlayingNotifier.value) {
        if (isPlaying) {
          if (_currentMode == PlinthMode.centerpiece || trackId == 'standby') {
            return;
          }
          if (_isHiFi) _vinylRotationController.repeat();
          _player.play();
        } else {
          if (_isHiFi) _vinylRotationController.stop();
          _player.pause();
        }
      }
    } catch (_) {}
  }

  Future<void> _switchAndPlayFromTelemetry(String videoId) async {
    if (_isSwitchingTrack) return;
    _isSwitchingTrack = true;
    try {
      try {
        await _player.pause();
      } catch (_) {}

      try {
        final stateRes = await http.get(Uri.parse('http://127.0.0.1:8000/api/state')).timeout(const Duration(seconds: 2));
        if (stateRes.statusCode == 200) {
          final sData = jsonDecode(stateRes.body);
          if (mounted) {
            setState(() {
              if (sData['title'] != null) _currentTrackTitle = sData['title'];
              if (sData['artist'] != null) _currentArtist = sData['artist'];
            });
          }
        }
      } catch (_) {}

      _fetchBeatsAndColor(videoId);

      if (videoId.startsWith('hifi_')) {
        final cleanId = videoId.replaceFirst('hifi_', '');
        final streamUrl = 'http://127.0.0.1:8000/media/hifi/$cleanId/stream';
        if (mounted) {
          setState(() {
            _isHiFi = true;
            _currentMode = PlinthMode.audiophileDeck;
          });
          _resetInactivityTimer();
        }
        await _player.open(Media(streamUrl), play: true);
        await _player.setVolume(_volumeNotifier.value);
        _vinylRotationController.repeat();
        _resetControlsVisibilityTimer();
      } else {
        if (mounted) {
          setState(() {
            _isHiFi = false;
            _currentMode = PlinthMode.activePlayer;
          });
          _resetInactivityTimer();
        }
        final streamUrl = 'http://127.0.0.1:8000/media/$videoId/video.mp4';
        await _player.open(Media(streamUrl), play: true);
        await _player.setVolume(_volumeNotifier.value);
        _resetControlsVisibilityTimer();
      }
    } catch (e) {
      debugPrint('Error switching track from telemetry: $e');
    } finally {
      _isSwitchingTrack = false;
    }
  }

  void _connectTelemetry() {
    _reconnectTimer?.cancel();
    if (Platform.isLinux) {
      _connectUnixSocket();
    } else {
      _connectWebSocket();
    }
  }

  void _connectUnixSocket() async {
    try {
      final sock = await Socket.connect(
        InternetAddress('/tmp/juggler_telemetry.sock', type: InternetAddressType.unix),
        0,
        timeout: const Duration(seconds: 2),
      );
      _telemetrySocket = sock;
      _socketSub = sock.listen(
        (data) {
          final text = utf8.decode(data);
          for (final line in text.split('\n')) {
            if (line.trim().isNotEmpty) {
              _handleTelemetryJson(line);
            }
          }
        },
        onError: (_) {
          _socketSub?.cancel();
          _telemetrySocket?.destroy();
          _scheduleReconnect();
        },
        onDone: () {
          _socketSub?.cancel();
          _telemetrySocket?.destroy();
          _scheduleReconnect();
        },
      );
    } catch (_) {
      // Unix socket not available yet, fall back to WebSocket
      _connectWebSocket();
    }
  }

  void _connectWebSocket() {
    try {
      _telemetryChannel = WebSocketChannel.connect(
        Uri.parse('ws://127.0.0.1:8000/ws/telemetry'),
      );
      _telemetryChannel!.stream.listen(
        (message) {
          if (message is String && message.trim().isNotEmpty) {
            _handleTelemetryJson(message);
          }
        },
        onError: (_) => _scheduleReconnect(),
        onDone: () => _scheduleReconnect(),
      );
    } catch (_) {
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) _connectTelemetry();
    });
  }

  void _startVisionStream() async {
    _stopVisionStream();
    _isVisionStreaming = true;

    try {
      http.post(
        Uri.parse('http://127.0.0.1:8000/api/vision/control'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'action': 'start'}),
      ).catchError((_) => http.Response('', 500));
    } catch (_) {}

    try {
      _visionHttpClient = http.Client();
      final req = http.Request('GET', Uri.parse('http://127.0.0.1:8000/api/vision/stream'));
      final res = await _visionHttpClient!.send(req);
      final List<int> buffer = [];

      _visionStreamSub = res.stream.listen((chunk) {
        if (!_isVisionStreaming || !mounted) return;
        buffer.addAll(chunk);

        while (true) {
          final eoi = _findJpegEoi(buffer);
          if (eoi == -1) break;

          final soi = _findJpegSoi(buffer, eoi);
          if (soi != -1 && eoi > soi) {
            final frameData = Uint8List.fromList(buffer.sublist(soi, eoi + 2));
            if (mounted) {
              setState(() {
                _latestVisionFrameBytes = frameData;
              });
            }
            buffer.removeRange(0, eoi + 2);
          } else {
            buffer.removeRange(0, eoi + 2);
          }
        }
      }, onError: (e) {
        debugPrint('Vision stream error: $e');
      });
    } catch (e) {
      debugPrint('Failed to start vision stream: $e');
    }
  }

  int _findJpegSoi(List<int> bytes, int beforeIndex) {
    for (int i = 0; i < beforeIndex - 1; i++) {
      if (bytes[i] == 0xFF && bytes[i + 1] == 0xD8) {
        return i;
      }
    }
    return -1;
  }

  int _findJpegEoi(List<int> bytes) {
    for (int i = 0; i < bytes.length - 1; i++) {
      if (bytes[i] == 0xFF && bytes[i + 1] == 0xD9) {
        return i;
      }
    }
    return -1;
  }

  void _stopVisionStream() {
    _isVisionStreaming = false;
    _visionStreamSub?.cancel();
    _visionStreamSub = null;
    _visionHttpClient?.close();
    _visionHttpClient = null;
  }

  void _toggleVisionColorMode() {
    final next = _visionColorMode == 'cyberpunk'
        ? 'heatmap'
        : _visionColorMode == 'heatmap'
            ? 'monochrome'
            : 'cyberpunk';
    setState(() {
      _visionColorMode = next;
    });
    try {
      http.post(
        Uri.parse('http://127.0.0.1:8000/api/vision/control'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'color_mode': next}),
      ).catchError((_) => http.Response('', 500));
    } catch (_) {}
  }


  Future<void> _loadCachedTracks() async {
    try {
      final res = await http.get(Uri.parse('http://127.0.0.1:8000/tracks')).timeout(const Duration(seconds: 2));
      if (res.statusCode == 200) {
        final List list = jsonDecode(res.body);
        setState(() {
          _cachedTracks = list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
        });
      }
    } catch (_) {}
  }

  Future<void> _performSearch(String query) async {
    final cleanQuery = query.trim();
    if (cleanQuery.isEmpty) {
      if (mounted) setState(() => _isLoadingTracks = false);
      return;
    }
    if (mounted) setState(() => _isLoadingTracks = true);
    try {
      final res = await http
          .get(Uri.parse('http://127.0.0.1:8000/search?q=${Uri.encodeComponent(cleanQuery)}'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final List list = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            _searchResults = list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
            _isLoadingTracks = false;
          });
        }
        return;
      }
    } catch (e) {
      debugPrint('Search error: $e');
    }
    if (mounted) {
      setState(() => _isLoadingTracks = false);
    }
  }

  Future<void> _performHiFiSearch(String query) async {
    final cleanQuery = query.trim().toLowerCase();
    if (cleanQuery.isEmpty) {
      if (mounted) {
        setState(() {
          _hifiSearchResults = [];
          _isLoadingTracks = false;
        });
      }
      return;
    }

    // Fast in-memory instant search if flat track index is loaded
    if (_hifiFlatTrackIndex.isNotEmpty) {
      final matches = _hifiFlatTrackIndex.where((t) {
        final title = (t['title'] as String? ?? '').toLowerCase();
        final artist = (t['artist'] as String? ?? '').toLowerCase();
        final album = (t['album'] as String? ?? '').toLowerCase();
        return title.contains(cleanQuery) || artist.contains(cleanQuery) || album.contains(cleanQuery);
      }).toList();

      matches.sort((a, b) {
        final aTitle = (a['title'] as String? ?? '').toLowerCase();
        final bTitle = (b['title'] as String? ?? '').toLowerCase();
        final aStarts = aTitle.startsWith(cleanQuery) ? 0 : 1;
        final bStarts = bTitle.startsWith(cleanQuery) ? 0 : 1;
        if (aStarts != bStarts) return aStarts.compareTo(bStarts);
        return aTitle.compareTo(bTitle);
      });

      if (mounted) {
        setState(() {
          _hifiSearchResults = matches;
          _isLoadingTracks = false;
        });
      }
      return;
    }

    // Fallback: Query backend Hi-Fi search endpoint
    if (mounted) setState(() => _isLoadingTracks = true);
    try {
      final res = await http
          .get(Uri.parse('http://127.0.0.1:8000/api/hifi/search?q=${Uri.encodeComponent(cleanQuery)}'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final List list = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            _hifiSearchResults = list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
            _isLoadingTracks = false;
          });
        }
        return;
      }
    } catch (e) {
      debugPrint('Hi-Fi search error: $e');
    }
    if (mounted) setState(() => _isLoadingTracks = false);
  }

  void _triggerDebouncedSearch() {
    _searchDebounceTimer?.cancel();
    final q = _searchQuery.trim();
    if (_isSearchHiFiMode ? q.isNotEmpty : q.length >= 2) {
      _searchDebounceTimer = Timer(Duration(milliseconds: _isSearchHiFiMode ? 150 : 400), () {
        if (_isSearchHiFiMode) {
          _performHiFiSearch(_searchQuery);
        } else {
          _performSearch(_searchQuery);
        }
      });
    } else {
      if (mounted) {
        setState(() {
          _searchResults = [];
          _hifiSearchResults = [];
          _isLoadingTracks = false;
        });
      }
    }
  }

  void _onKeyTapped(String char) {
    setState(() {
      if (char == 'BKSP' || char == 'DEL') {
        if (_searchQuery.isNotEmpty) {
          _searchQuery = _searchQuery.substring(0, _searchQuery.length - 1);
        }
      } else if (char == 'SPACE') {
        _searchQuery += ' ';
      } else if (char == 'ENTER') {
        _searchDebounceTimer?.cancel();
        if (_isSearchHiFiMode) {
          _performHiFiSearch(_searchQuery);
        } else {
          _performSearch(_searchQuery);
        }
        return;
      } else if (char == 'SHIFT') {
        _isShiftUpper = !_isShiftUpper;
        return;
      } else if (char == 'LANG') {
        _isArabicKeyboard = !_isArabicKeyboard;
        return;
      } else {
        if (_isArabicKeyboard) {
          _searchQuery += char;
        } else {
          _searchQuery += _isShiftUpper ? char.toUpperCase() : char.toLowerCase();
        }
      }
    });

    _triggerDebouncedSearch();
  }

  Future<void> _playTrack(Map<String, dynamic> track) async {
    final videoId = track['video_id'];
    if (videoId == null) return;

    final isAlreadyCached = track['is_cached'] == true;

    // Immediately close search and queue drawers so the user returns to the HUD
    setState(() {
      _isSearchOpen = false;
      _isQueueOpen = false;
    });

    if (isAlreadyCached) {
      _preparingPollTimer?.cancel();
      setState(() {
        _preparingVideoId = null;
        _currentTrackTitle = track['title'] ?? 'Selected Track';
        _currentArtist = track['artist'] ?? 'Artist';
        _activeVideoId = videoId;
      });
      await _switchAndPlay(videoId);
      return;
    }

    // New track not yet cached: queue in background without disrupting current playing track!
    setState(() {
      _preparingVideoId = videoId;
      _preparingTrackTitle = track['title'] ?? 'Queued Track';
      _preparingTrackArtist = track['artist'] ?? '';
      _preparingProgress = 0.05;
      _preparingPercent = 5;
      _preparingStatus = 'Starting 1080p download...';
    });

    try {
      await http.post(Uri.parse('http://127.0.0.1:8000/cache/$videoId'));
      _startPreparingPolling(videoId);
    } catch (e) {
      debugPrint('Playback trigger error: $e');
    }
  }

  void _startPreparingPolling(String videoId) {
    _preparingPollTimer?.cancel();
    _preparingPollTimer = Timer.periodic(const Duration(milliseconds: 750), (timer) async {
      if (!mounted || _preparingVideoId != videoId) {
        timer.cancel();
        return;
      }
      try {
        final res = await http.get(Uri.parse('http://127.0.0.1:8000/cache/status/$videoId'));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          final status = data['status'] as String? ?? 'downloading';
          final progress = (data['progress'] as num?)?.toDouble() ?? 0.05;
          final percent = (data['percent'] as num?)?.toInt() ?? (progress * 100).round();

          if (status == 'ready') {
            timer.cancel();
            if (mounted) {
              setState(() {
                _preparingProgress = 1.0;
                _preparingPercent = 100;
                _preparingStatus = '1080p Ready! Launching...';
              });
            }
            // Seamless transition to the new track
            await Future.delayed(const Duration(milliseconds: 600));
            if (!mounted || _preparingVideoId != videoId) return;

            setState(() {
              _currentTrackTitle = _preparingTrackTitle ?? 'Selected Track';
              _currentArtist = _preparingTrackArtist ?? '';
              _activeVideoId = videoId;
              _preparingVideoId = null;
            });

            await _switchAndPlay(videoId);
            _loadCachedTracks();
          } else if (status == 'error') {
            timer.cancel();
            if (mounted) {
              setState(() {
                _preparingStatus = 'Download failed: ${data['error'] ?? 'Unknown error'}';
              });
              Future.delayed(const Duration(seconds: 4), () {
                if (mounted && _preparingVideoId == videoId) {
                  setState(() => _preparingVideoId = null);
                }
              });
            }
          } else {
            String label = 'Downloading 1080p...';
            if (status == 'processing_1080p') {
              label = 'Optimizing 1080p Video...';
            } else if (status == 'analyzing_beats') {
              label = 'Aubio Beat Extraction...';
            } else if (status == 'color_and_metadata') {
              label = 'Extracting Dominant Palette...';
            }

            if (mounted) {
              setState(() {
                _preparingProgress = progress.clamp(0.0, 1.0);
                _preparingPercent = percent.clamp(0, 100);
                _preparingStatus = label;
              });
            }
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _switchAndPlay(String videoId) async {
    if (_isSwitchingTrack) return;
    _isSwitchingTrack = true;
    try {
      // Pause first to gracefully flush hardware EGL video decoder buffers
      try {
        await _player.pause();
      } catch (_) {}

      _activeVideoId = videoId;
      _fetchBeatsAndColor(videoId);

      try {
        final playRes = await http.post(Uri.parse('http://127.0.0.1:8000/play/$videoId')).timeout(const Duration(seconds: 2));
        if (playRes.statusCode == 200) {
          final data = jsonDecode(playRes.body);
          final detectedBpm = (data['bpm'] as num?)?.toDouble();
          if (detectedBpm != null && detectedBpm > 40 && detectedBpm < 240) {
            _bpmNotifier.value = detectedBpm.round();
            _currentTrackBpm = detectedBpm;
          }
          final hex = data['dominant_color'] as String?;
          if (hex != null && hex.startsWith('#') && hex.length == 7) {
            _smoothTransitionDominantColor(Color(int.parse(hex.replaceFirst('#', '0xFF'))));
          }
        }
      } catch (e) {
        debugPrint('Error notifying orchestrator of play: $e');
      }

      if (mounted) {
        setState(() {
          _currentMode = PlinthMode.activePlayer;
        });
        _resetInactivityTimer();
      }

      final streamUrl = 'http://127.0.0.1:8000/media/$videoId/video.mp4';
      await _player.open(Media(streamUrl), play: true);
      await _player.setVolume(_volumeNotifier.value);
      _resetControlsVisibilityTimer();
    } catch (e) {
      debugPrint('Error switching track: $e');
    } finally {
      _isSwitchingTrack = false;
    }
  }

  Future<void> _goToIdleStandby() async {
    try {
      await _player.pause();
      await _player.stop();
      _isPlayingNotifier.value = false;
      if (_isHiFi) _vinylRotationController.stop();
      _activeVideoId = 'standby';
      _lastTelemetryTrackId = 'standby';
      _preparingVideoId = null;
      _preparingPollTimer?.cancel();
      await http.post(
        Uri.parse('http://127.0.0.1:8000/api/control'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'action': 'idle'}),
      ).timeout(const Duration(milliseconds: 1500));
    } catch (_) {}
    if (mounted) {
      setState(() {
        _currentMode = PlinthMode.centerpiece;
        _isSearchOpen = false;
        _isQueueOpen = false;
        _isHiFiBrowserOpen = false;
        _isRadialCarouselOpen = false;
        _isCitySearchOpen = false;
      });
      _inactivityTimer?.cancel();
    }
  }

  Future<void> _stopCasting() async {
    try {
      await _player.pause();
      _isPlayingNotifier.value = false;
      if (_isHiFi) _vinylRotationController.stop();
      _preparingPollTimer?.cancel();
      _preparingVideoId = null;

      await http.post(
        Uri.parse('http://127.0.0.1:8000/api/control'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'action': 'stop_cast'}),
      ).timeout(const Duration(milliseconds: 1500));
    } catch (_) {}

    // Restore previous track in PAUSED state
    if (_preCastTrackId != null && _preCastTrackId != 'standby') {
      final prevId = _preCastTrackId!;
      final prevIsHiFi = _preCastIsHiFi;
      final prevTitle = _preCastTrackTitle;
      final prevArtist = _preCastArtist;
      final prevPos = _preCastPosition;

      _activeVideoId = prevId;
      _lastTelemetryTrackId = prevId;
      _isHiFi = prevIsHiFi;
      if (prevTitle != null) _currentTrackTitle = prevTitle;
      if (prevArtist != null) _currentArtist = prevArtist;

      if (mounted) {
        setState(() {
          _currentMode = _isHiFi ? PlinthMode.audiophileDeck : PlinthMode.activePlayer;
          _isSearchOpen = false;
          _isQueueOpen = false;
          _isHiFiBrowserOpen = false;
          _isRadialCarouselOpen = false;
        });
      }

      try {
        if (_isHiFi) {
          final cleanId = prevId.replaceFirst('hifi_', '');
          await _player.open(Media('http://127.0.0.1:8000/media/hifi/$cleanId/stream'), play: false);
        } else {
          await _player.open(Media('http://127.0.0.1:8000/media/$prevId/video.mp4'), play: false);
        }
        await _player.setVolume(_volumeNotifier.value);
        if (prevPos > Duration.zero) {
          await _player.seek(prevPos);
        }
        await _player.pause();
      } catch (e) {
        debugPrint('Error restoring previous track: $e');
      }

      _isPlayingNotifier.value = false;
      if (_isHiFi) _vinylRotationController.stop();
      _preCastTrackId = null;
    } else {
      await _player.pause();
      _isPlayingNotifier.value = false;
      if (_isHiFi) _vinylRotationController.stop();
      if (mounted) {
        setState(() {});
      }
    }
  }

  Future<void> _togglePlayPause() async {
    final willPlay = !_isPlayingNotifier.value;
    _isPlayingNotifier.value = willPlay;
    if (willPlay) {
      await _player.play();
      _resetControlsVisibilityTimer();
    } else {
      await _player.pause();
      _controlsVisibilityTimer?.cancel();
      if (mounted && !_areControlsVisible) {
        setState(() => _areControlsVisible = true);
      }
    }
    try {
      await http.post(
        Uri.parse('http://127.0.0.1:8000/api/control'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'action': willPlay ? 'play' : 'pause'}),
      ).timeout(const Duration(milliseconds: 1500));
    } catch (e) {
      debugPrint('Error syncing play/pause to orchestrator: $e');
    }
  }

  Future<void> _playNextTrack() async {
    try {
      final res = await http.post(
        Uri.parse('http://127.0.0.1:8000/api/queue/next'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 4));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final status = data['status']?.toString() ?? '';
        if (status == 'playing') {
          final trackId = data['track_id']?.toString() ?? '';
          if (trackId.startsWith('hifi_')) {
            final cleanId = trackId.replaceFirst('hifi_', '');
            await _playHiFiTrack(cleanId);
            return;
          } else if (trackId.isNotEmpty) {
            await _playTrack({
              'video_id': trackId,
              'title': data['title'] ?? 'Playing Track',
              'artist': data['artist'] ?? '',
            });
            return;
          }
        } else if (status == 'ended') {
          await _player.pause();
          _isPlayingNotifier.value = false;
          return;
        }
      }
    } catch (e) {
      debugPrint('Error invoking /api/queue/next: $e');
    }

    if (_isHiFi) {
      List<Map<String, dynamic>> playlist = _currentHiFiPlaylist;
      if (playlist.length <= 1) {
        if (_hifiTrackList.length > 1) {
          playlist = _hifiTrackList;
          _currentHiFiPlaylist = playlist;
        } else if (_hifiFlatTrackIndex.isNotEmpty) {
          playlist = _hifiFlatTrackIndex;
          _currentHiFiPlaylist = playlist;
        }
      }
      if (playlist.isNotEmpty) {
        final cleanActiveId = _activeVideoId.replaceFirst('hifi_', '');
        final currentIdx = playlist.indexWhere((t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == cleanActiveId);
        if (currentIdx >= 0) {
          _currentHiFiTrackIndex = currentIdx;
        }

        if (_isShuffleEnabled && playlist.length > 1) {
          int nextIdx;
          final rand = math.Random();
          do {
            nextIdx = rand.nextInt(playlist.length);
          } while (nextIdx == _currentHiFiTrackIndex);
          _currentHiFiTrackIndex = nextIdx;
        } else {
          _currentHiFiTrackIndex = (_currentHiFiTrackIndex + 1) % playlist.length;
        }
        final nextTrack = playlist[_currentHiFiTrackIndex];
        final trackId = nextTrack['track_id']?.toString() ?? nextTrack['id']?.toString() ?? '';
        if (trackId.isNotEmpty) {
          _playHiFiTrack(trackId, playlist: playlist, index: _currentHiFiTrackIndex);
        }
        return;
      }
      return; // Do NOT fall back to YouTube when in Hi-Fi mode!
    }
    if (_cachedTracks.isEmpty) return;
    final currentIdx = _cachedTracks.indexWhere((t) => t['video_id'] == _activeVideoId);
    if (currentIdx >= 0) {
      _currentPlaylistIndex = currentIdx;
    }
    if (_isShuffleEnabled && _cachedTracks.length > 1) {
      int nextIdx;
      final rand = math.Random();
      do {
        nextIdx = rand.nextInt(_cachedTracks.length);
      } while (nextIdx == _currentPlaylistIndex);
      _currentPlaylistIndex = nextIdx;
    } else {
      _currentPlaylistIndex = (_currentPlaylistIndex + 1) % _cachedTracks.length;
    }
    _playTrack(_cachedTracks[_currentPlaylistIndex]);
  }

  Future<void> _playPreviousTrack() async {
    // If track has been playing for > 3 seconds, seek back to beginning first
    if (_positionNotifier.value.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }

    try {
      final res = await http.post(
        Uri.parse('http://127.0.0.1:8000/api/queue/prev'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 4));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final status = data['status']?.toString() ?? '';
        if (status == 'playing') {
          final trackId = data['track_id']?.toString() ?? '';
          if (trackId.startsWith('hifi_')) {
            final cleanId = trackId.replaceFirst('hifi_', '');
            await _playHiFiTrack(cleanId);
            return;
          } else if (trackId.isNotEmpty) {
            await _playTrack({
              'video_id': trackId,
              'title': data['title'] ?? 'Playing Track',
              'artist': data['artist'] ?? '',
            });
            return;
          }
        }
      }
    } catch (e) {
      debugPrint('Error invoking /api/queue/prev: $e');
    }

    if (_isHiFi) {
      List<Map<String, dynamic>> playlist = _currentHiFiPlaylist;
      if (playlist.length <= 1) {
        if (_hifiTrackList.length > 1) {
          playlist = _hifiTrackList;
          _currentHiFiPlaylist = playlist;
        } else if (_hifiFlatTrackIndex.isNotEmpty) {
          playlist = _hifiFlatTrackIndex;
          _currentHiFiPlaylist = playlist;
        }
      }
      if (playlist.isNotEmpty) {
        final cleanActiveId = _activeVideoId.replaceFirst('hifi_', '');
        final currentIdx = playlist.indexWhere((t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == cleanActiveId);
        if (currentIdx >= 0) {
          _currentHiFiTrackIndex = currentIdx;
        }

        if (_isShuffleEnabled && playlist.length > 1) {
          int prevIdx;
          final rand = math.Random();
          do {
            prevIdx = rand.nextInt(playlist.length);
          } while (prevIdx == _currentHiFiTrackIndex);
          _currentHiFiTrackIndex = prevIdx;
        } else {
          _currentHiFiTrackIndex = (_currentHiFiTrackIndex - 1 + playlist.length) % playlist.length;
        }
        final prevTrack = playlist[_currentHiFiTrackIndex];
        final trackId = prevTrack['track_id']?.toString() ?? prevTrack['id']?.toString() ?? '';
        if (trackId.isNotEmpty) {
          _playHiFiTrack(trackId, playlist: playlist, index: _currentHiFiTrackIndex);
        }
        return;
      }
      return; // Do NOT fall back to YouTube when in Hi-Fi mode!
    }
    if (_cachedTracks.isEmpty) return;
    final currentIdx = _cachedTracks.indexWhere((t) => t['video_id'] == _activeVideoId);
    if (currentIdx >= 0) {
      _currentPlaylistIndex = currentIdx;
    }
    if (_isShuffleEnabled && _cachedTracks.length > 1) {
      int prevIdx;
      final rand = math.Random();
      do {
        prevIdx = rand.nextInt(_cachedTracks.length);
      } while (prevIdx == _currentPlaylistIndex);
      _currentPlaylistIndex = prevIdx;
    } else {
      _currentPlaylistIndex = (_currentPlaylistIndex - 1 + _cachedTracks.length) % _cachedTracks.length;
    }
    _playTrack(_cachedTracks[_currentPlaylistIndex]);
  }

  void _toggleShuffle() {
    setState(() {
      _isShuffleEnabled = !_isShuffleEnabled;
    });
    try {
      http.post(
        Uri.parse('http://127.0.0.1:8000/api/playback/modes'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'shuffle': _isShuffleEnabled}),
      ).timeout(const Duration(milliseconds: 1500));
    } catch (e) {
      debugPrint('Error syncing shuffle: $e');
    }
  }

  void _toggleRepeat() {
    setState(() {
      switch (_repeatMode) {
        case RepeatMode.off:
          _repeatMode = RepeatMode.all;
          break;
        case RepeatMode.all:
          _repeatMode = RepeatMode.one;
          break;
        case RepeatMode.one:
          _repeatMode = RepeatMode.off;
          break;
      }
    });
    try {
      final repStr = _repeatMode == RepeatMode.one ? 'one' : (_repeatMode == RepeatMode.all ? 'all' : 'off');
      http.post(
        Uri.parse('http://127.0.0.1:8000/api/playback/modes'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'repeat': repStr}),
      ).timeout(const Duration(milliseconds: 1500));
    } catch (e) {
      debugPrint('Error syncing repeat: $e');
    }
  }

  void _resetControlsVisibilityTimer() {
    _controlsVisibilityTimer?.cancel();
    if (!_areControlsVisible) {
      if (mounted) setState(() => _areControlsVisible = true);
    }
    final isPlayerMode = (_currentMode == PlinthMode.activePlayer || _currentMode == PlinthMode.audiophileDeck);
    if (_isPlayingNotifier.value &&
        !_isSearchOpen &&
        !_isQueueOpen &&
        !_isRadialCarouselOpen &&
        !_isHiFiBrowserOpen &&
        isPlayerMode) {
      _controlsVisibilityTimer = Timer(const Duration(seconds: 12), () {
        if (mounted &&
            _isPlayingNotifier.value &&
            !_isSearchOpen &&
            !_isQueueOpen &&
            !_isRadialCarouselOpen &&
            !_isHiFiBrowserOpen &&
            (_currentMode == PlinthMode.activePlayer || _currentMode == PlinthMode.audiophileDeck)) {
          setState(() => _areControlsVisible = false);
        }
      });
    }
  }

  void _toggleControlsVisibility() {
    if (_areControlsVisible) {
      _controlsVisibilityTimer?.cancel();
      if (mounted) setState(() => _areControlsVisible = false);
    } else {
      _resetControlsVisibilityTimer();
    }
  }

  int _lastBackdropTapTime = 0;
  Offset _lastBackdropTapPos = Offset.zero;

  void _onBackdropTapDown(TapDownDetails details, double size) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final pos = details.localPosition;
    if (now - _lastBackdropTapTime < 320 && (pos - _lastBackdropTapPos).distance < 60) {
      _lastBackdropTapTime = 0;
      _handleVideoDoubleTap(details, size);
    } else {
      _lastBackdropTapTime = now;
      _lastBackdropTapPos = pos;
      _toggleControlsVisibility();
    }
  }

  void _handleVideoDoubleTap(TapDownDetails details, double size) {
    final tapX = details.localPosition.dx;
    final isLeft = tapX < size / 2;
    final seekSec = isLeft ? -10 : 10;
    _seekRelative(seekSec);

    _seekRippleTimer?.cancel();
    if (mounted) {
      setState(() => _seekRippleCount = seekSec);
    }
    _seekRippleTimer = Timer(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _seekRippleCount = 0);
    });

    _resetControlsVisibilityTimer();
  }

  void _seekRelative(int seconds) {
    final current = _positionNotifier.value;
    final target = current + Duration(seconds: seconds);
    final clamped = Duration(
      milliseconds: target.inMilliseconds.clamp(0, _durationNotifier.value.inMilliseconds),
    );
    _player.seek(clamped);
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  void _setVolume(double volume) {
    final clamped = volume.clamp(0.0, 100.0);
    _volumeNotifier.value = clamped;
    // Always keep player software volume at 100% (0 dB) to avoid digital truncation clipping.
    _player.setVolume(100.0);
    _resetControlsVisibilityTimer();
    _volumeSyncDebounce?.cancel();
    _volumeSyncDebounce = Timer(const Duration(milliseconds: 100), () async {
      try {
        await http.post(
          Uri.parse('http://127.0.0.1:8000/api/audio/volume'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'volume_pct': clamped}),
        );
      } catch (_) {}
    });
  }

  void _toggleMute() {
    if (_volumeNotifier.value > 0.01) {
      _lastVolumeBeforeMute = _volumeNotifier.value;
      _setVolume(0.0);
    } else {
      _setVolume(_lastVolumeBeforeMute > 0 ? _lastVolumeBeforeMute : 100.0);
    }
  }

  double _computeBeatPhase(double t) {
    if (_beatTimestamps.isEmpty) {
      final period = 60.0 / (_currentTrackBpm > 0 ? _currentTrackBpm : 103.0);
      return (t % period) / period;
    }
    if (t < _beatTimestamps.first) {
      final period = 60.0 / (_currentTrackBpm > 0 ? _currentTrackBpm : 103.0);
      final dist = _beatTimestamps.first - t;
      return (1.0 - (dist % period) / period).clamp(0.0, 1.0);
    }
    if (t >= _beatTimestamps.last) {
      final period = 60.0 / (_currentTrackBpm > 0 ? _currentTrackBpm : 103.0);
      final dist = t - _beatTimestamps.last;
      return ((dist % period) / period).clamp(0.0, 1.0);
    }
    // Binary search for beat interval [b_i, b_{i+1}]
    int low = 0;
    int high = _beatTimestamps.length - 1;
    while (low <= high) {
      int mid = (low + high) >> 1;
      if (_beatTimestamps[mid] <= t) {
        if (mid == _beatTimestamps.length - 1 || _beatTimestamps[mid + 1] > t) {
          final bStart = _beatTimestamps[mid];
          final bEnd = _beatTimestamps[mid + 1];
          final interval = bEnd - bStart;
          if (interval <= 0) return 0.0;
          return ((t - bStart) / interval).clamp(0.0, 1.0);
        }
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }
    return 0.0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final size = math.min(constraints.maxWidth, constraints.maxHeight);

          return Center(
            child: SizedBox(
              width: size,
              height: size,
              child: ClipOval(
                child: Listener(
                  behavior: HitTestBehavior.translucent,
                  onPointerDown: (_) {
                    _resetInactivityTimer();
                  },
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      // MODE 1: Hardware Accelerated Video Surface & HUD (Active Player, Audiophile Deck, or under Settings)
                      if (_currentMode == PlinthMode.activePlayer || _currentMode == PlinthMode.audiophileDeck || _currentMode == PlinthMode.settingsMenu) ...[
                        // LAYER 0: Surface - Video or Audiophile Turntable Centerpiece (Fully interactive, zero-latency)
                        Positioned.fill(
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTapDown: (details) => _onBackdropTapDown(details, size),
                            onHorizontalDragEnd: (details) {
                              final velocity = details.primaryVelocity ?? 0;
                              if (velocity < -200) {
                                _playNextTrack();
                              } else if (velocity > 200) {
                                _playPreviousTrack();
                              }
                            },
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Container(color: Colors.black),
                                if (_currentMode == PlinthMode.audiophileDeck)
                                  _buildAudiophileTurntableCenterpiece(size)
                                else
                                  Video(
                                    controller: _videoController,
                                    fit: BoxFit.cover,
                                  ),
                              ],
                            ),
                          ),
                        ),

                        // LAYER 1: Deep Refractive Perimeter Vignette (IgnorePointer so it never swallows gestures)
                        Positioned.fill(
                          child: IgnorePointer(
                            child: Container(
                              decoration: const BoxDecoration(
                                gradient: RadialGradient(
                                  center: Alignment.center,
                                  radius: 0.98,
                                  colors: [
                                    Colors.transparent,
                                    Colors.transparent,
                                    Color(0x33000000),
                                    Color(0x88040814),
                                    Color(0xE602040A),
                                  ],
                                  stops: [0.0, 0.58, 0.78, 0.90, 1.0],
                                ),
                              ),
                            ),
                          ),
                        ),

                        // LAYER 2: Apple-Grade Additive Optical Glow Ribbon (IgnorePointer so it never swallows gestures)
                        IgnorePointer(
                          child: RepaintBoundary(
                            child: AnimatedBuilder(
                              animation: Listenable.merge([_waveController, _dominantColorNotifier]),
                              builder: (context, child) {
                                final now = DateTime.now();
                                final elapsed = _isPlayingNotifier.value
                                    ? now.difference(_lastPositionUpdateTime).inMicroseconds / 1000000.0
                                    : 0.0;
                                final currentSec = _lastKnownPositionSec + elapsed;
                                final beatPhase = _computeBeatPhase(currentSec);
                                final kickDecay = math.exp(-beatPhase * 6.0);

                                return CustomPaint(
                                  painter: AppleGlowRibbonPainter(
                                    flowProgress: _waveController.value,
                                    kickPulse: kickDecay,
                                    phaseLock: _phaseErrorNotifier.value.abs() < 1.0 ? 1.0 : 0.0,
                                    glowColor: _dominantColorNotifier.value,
                                  ),
                                );
                              },
                            ),
                          ),
                        ),

                        // LAYER 3: Typographic Telemetry & Apple Glass Interface Elements
                        Positioned.fill(
                          child: AnimatedOpacity(
                            duration: const Duration(milliseconds: 350),
                            curve: Curves.easeInOut,
                            opacity: (_areControlsVisible || !_isPlayingNotifier.value || _isSearchOpen || _isQueueOpen) ? 1.0 : 0.0,
                            child: IgnorePointer(
                              ignoring: !(_areControlsVisible || !_isPlayingNotifier.value || _isSearchOpen || _isQueueOpen),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  // Backdrop tap/double-tap detector when controls are visible (zero-latency)
                                  Positioned.fill(
                                    child: GestureDetector(
                                      behavior: HitTestBehavior.opaque,
                                      onTapDown: (details) => _onBackdropTapDown(details, size),
                                    ),
                                  ),
                                  if (!_isSearchOpen && !_isQueueOpen) ...[
                                    // Top Bar: Centered within safe circular touch zone (Max width: 550px, top: size * 0.165)
                                    Positioned(
                                      top: size * 0.165,
                                      left: 0,
                                      right: 0,
                                      child: Center(
                                        child: SizedBox(
                                          width: 550,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              // Ambient Idle / Centerpiece Return Button
                                              TactileButton(
                                                scaleFactor: 0.90,
                                                minWidth: 48,
                                                minHeight: 48,
                                                onTap: _goToIdleStandby,
                                                child: Container(
                                                  width: 48,
                                                  height: 48,
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xE8080E1B),
                                                    borderRadius: BorderRadius.circular(15),
                                                    border: Border.all(color: const Color(0x7760A5FA), width: 1.5),
                                                    boxShadow: const [
                                                      BoxShadow(color: Color(0x3300E5FF), blurRadius: 10),
                                                      BoxShadow(color: Colors.black54, blurRadius: 6, offset: Offset(0, 2)),
                                                    ],
                                                  ),
                                                  child: const Icon(Icons.bedtime_rounded, color: Color(0xFF67E8F9), size: 24),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              // YouTube Search Capsule
                                              Expanded(
                                                child: TactileButton(
                                                  scaleFactor: 0.96,
                                                  onTap: () {
                                                    setState(() => _isSearchOpen = true);
                                                    _loadCachedTracks();
                                                  },
                                                  child: _buildYouTubeCapsule(),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              // Hi-Fi Lossless Library Button
                                              TactileButton(
                                                scaleFactor: 0.92,
                                                onTap: () {
                                                  setState(() {
                                                    _isHiFiBrowserOpen = !_isHiFiBrowserOpen;
                                                    if (_isHiFiBrowserOpen) _loadHiFiTree();
                                                  });
                                                },
                                                child: Container(
                                                  width: 48,
                                                  height: 48,
                                                  decoration: BoxDecoration(
                                                    color: _isHiFi
                                                        ? const Color(0x33F59E0B)
                                                        : const Color(0xE8080E1B),
                                                    borderRadius: BorderRadius.circular(15),
                                                    border: Border.all(
                                                      color: _isHiFi
                                                          ? const Color(0xFFF59E0B)
                                                          : const Color(0x7760A5FA),
                                                      width: 1.5,
                                                    ),
                                                    boxShadow: [
                                                      if (_isHiFi)
                                                        const BoxShadow(color: Color(0x66F59E0B), blurRadius: 12),
                                                      const BoxShadow(color: Colors.black54, blurRadius: 6, offset: Offset(0, 2)),
                                                    ],
                                                  ),
                                                  child: Icon(
                                                    Icons.album_rounded,
                                                    color: _isHiFi ? const Color(0xFFFBBF24) : const Color(0xFF93C5FD),
                                                    size: 24,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              // Settings Menu Button
                                              TactileButton(
                                                scaleFactor: 0.92,
                                                onTap: () {
                                                  setState(() {
                                                    _previousMode = _currentMode;
                                                    _currentMode = PlinthMode.settingsMenu;
                                                  });
                                                },
                                                child: Container(
                                                  width: 48,
                                                  height: 48,
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xE8080E1B),
                                                    borderRadius: BorderRadius.circular(15),
                                                    border: Border.all(color: const Color(0x7760A5FA), width: 1.5),
                                                    boxShadow: const [
                                                      BoxShadow(color: Color(0x3300E5FF), blurRadius: 10),
                                                      BoxShadow(color: Colors.black54, blurRadius: 6, offset: Offset(0, 2)),
                                                    ],
                                                  ),
                                                  child: const Icon(Icons.settings_rounded, color: Color(0xFF93C5FD), size: 24),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),

                                    // Floating Hi-Res Lossless Spec Badge (in Audiophile Deck Mode)
                                    if (_isHiFi && _preparingVideoId == null)
                                      Positioned(
                                        top: size * 0.228,
                                        left: 0,
                                        right: 0,
                                        child: Center(
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
                                            decoration: BoxDecoration(
                                              color: const Color(0xE6080D1A),
                                              borderRadius: BorderRadius.circular(999),
                                              border: Border.all(color: const Color(0xFFF59E0B), width: 1.4),
                                              boxShadow: const [
                                                BoxShadow(color: Color(0x66F59E0B), blurRadius: 16),
                                                BoxShadow(color: Colors.black87, blurRadius: 10, offset: Offset(0, 4)),
                                              ],
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                const Icon(Icons.graphic_eq_rounded, color: Color(0xFFFBBF24), size: 16),
                                                const SizedBox(width: 8),
                                                Text(
                                                  'HI-RES LOSSLESS • $_bitDepth-BIT / ${(_sampleRateHz / 1000).toStringAsFixed(1)} kHz • $_audioFormat',
                                                  style: const TextStyle(
                                                    color: Color(0xFFFBBF24),
                                                    fontSize: 13,
                                                    letterSpacing: 1.2,
                                                    fontWeight: FontWeight.w700,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),

                                    // Dedicated Background 1080p Preparation & Loading Pill
                                    if (_preparingVideoId != null)
                                      Positioned(
                                        top: size * 0.198,
                                        left: 0,
                                        right: 0,
                                        child: Center(
                                          child: _buildPreparingTrackBanner(),
                                        ),
                                      ),

                                    // Mid-Left: Large BPM & Phase Lock Readout
                                    Positioned(
                                      left: size * 0.12,
                                      top: size * 0.31,
                                      child: _buildBpmTelemetry(),
                                    ),

                                    // Mid-Right: Track Title & Glass Library Queue Button
                                    Positioned(
                                      right: size * 0.12,
                                      top: size * 0.31,
                                      child: _buildTrackInfoCallout(),
                                    ),

                                    // Center-Lower: Enchanced Apple Liquid Glass Transport Controls Bar
                                    Positioned(
                                      bottom: size * 0.17,
                                      left: 0,
                                      right: 0,
                                      child: Center(
                                        child: _buildMediaTransportControls(),
                                      ),
                                    ),

                                    // Bottom: Timecode & Robot Kinematics Complication
                                    Positioned(
                                      bottom: size * 0.075,
                                      left: 0,
                                      right: 0,
                                      child: Center(
                                        child: _buildKinematicsAndTimeline(),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),

                        // Double-Tap Seek Visual Ripple Indicator (Always prominent on top)
                        if (_seekRippleCount != 0)
                          Positioned(
                            left: _seekRippleCount < 0 ? size * 0.16 : null,
                            right: _seekRippleCount > 0 ? size * 0.16 : null,
                            top: size * 0.44,
                            child: IgnorePointer(
                              child: AnimatedBuilder(
                                animation: _dominantColorNotifier,
                                builder: (context, _) {
                                  final themeCol = _dominantColorNotifier.value;
                                  return Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                                    decoration: BoxDecoration(
                                      color: const Color(0xEE081224),
                                      borderRadius: BorderRadius.circular(30),
                                      border: Border.all(color: themeCol, width: 2.0),
                                      boxShadow: [
                                        BoxShadow(
                                          color: themeCol.withValues(alpha: 0.6),
                                          blurRadius: 24,
                                          spreadRadius: 3,
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          _seekRippleCount < 0 ? Icons.replay_10_rounded : Icons.forward_10_rounded,
                                          color: Colors.white,
                                          size: 28,
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          _seekRippleCount < 0 ? '-10s' : '+10s',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 18,
                                            fontWeight: FontWeight.w800,
                                            letterSpacing: 1.0,
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),

                        // LAYER 4: Swipe-in Radial Carousel for Locally Cached Favorites
                        if (_isRadialCarouselOpen) _buildRadialCarousel(size),

                        // LAYER 5: Quick Playlist / Queue Drawer
                        if (_isQueueOpen) _buildQueueDrawer(size),

                        // LAYER 6: Centered Circular-Fit Touch Keyboard & Search Overlay
                        if (_isSearchOpen) _buildGlassSearchOverlay(size),
                      ],

                      // MODE 2: Living Room Centerpiece Mode (Ambient Swiss Chronometer)
                      if (_currentMode == PlinthMode.centerpiece)
                        _buildCenterpieceMode(size),

                      // MODE: OV9281 Full-Screen Ball Vision & 3D Tracking Deck
                      if (_currentMode == PlinthMode.cameraVision)
                        _buildCameraVisionMode(size),

                      // MODE 3: First Cinematic Boot Sequence
                      if (_currentMode == PlinthMode.bootSequence)
                        _buildBootSequence(size),

                      // MODE 4: Circular Settings Deck Modal
                      if (_currentMode == PlinthMode.settingsMenu)
                        _buildSettingsDeck(size),

                      // OVERLAY: Full Touch Keyboard City Search & Autocomplete
                      if (_isCitySearchOpen)
                        _buildCitySearchOverlay(size),

                      // OVERLAY: Hi-Fi Folder & Lossless Library Browser Drawer
                      if (_isHiFiBrowserOpen)
                        _buildHiFiBrowserOverlay(size),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // --- WIDGET BUILDERS ---

  Widget _buildYouTubeCapsule() {
    final isPreparing = _preparingVideoId != null;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xE0070E1C),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: isPreparing ? const Color(0xFF38BDF8) : const Color(0x9960A5FA),
          width: 1.8,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x6600E5FF),
            blurRadius: 20,
            spreadRadius: 1,
            offset: Offset(0, 3),
          ),
          BoxShadow(
            color: Colors.black87,
            blurRadius: 25,
            spreadRadius: 4,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Sleek YouTube Logo Badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isPreparing
                    ? [const Color(0xFF0284C7), const Color(0xFF0369A1)]
                    : [const Color(0xFFFF0000), const Color(0xFFCC0000)],
              ),
              borderRadius: BorderRadius.circular(7),
              boxShadow: [
                BoxShadow(
                  color: isPreparing ? const Color(0x8838BDF8) : const Color(0x88FF0000),
                  blurRadius: 10,
                ),
              ],
            ),
            child: isPreparing
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              isPreparing
                  ? '$_preparingPercent% • ${_preparingTrackTitle ?? 'Preparing...'}'
                  : (_searchQuery.isEmpty ? 'Search YouTube Videos & Tracks...' : _searchQuery),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 15.5,
                color: (_searchQuery.isEmpty && !isPreparing) ? const Color(0x99FFFFFF) : Colors.white,
                fontWeight: (_searchQuery.isEmpty && !isPreparing) ? FontWeight.w400 : FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 14),
          const Icon(Icons.search, size: 22, color: Color(0xFF60A5FA)),
        ],
      ),
    );
  }

  // Apple-Grade Floating Dynamic HUD Pill: Displays Active FLAC / 1080p Download & Live Progress
  Widget _buildPreparingTrackBanner() {
    if (_preparingVideoId == null) return const SizedBox.shrink();

    final isHiFiPrep = _isHiFi || (_preparingVideoId?.startsWith('hifi_') ?? false);
    final accentColor = isHiFiPrep ? const Color(0xFFF59E0B) : const Color(0xFF38BDF8);
    final accentDark = isHiFiPrep ? const Color(0xFFD97706) : const Color(0xFF0284C7);
    final badgeText = isHiFiPrep ? 'BUFFERING LOSSLESS FLAC' : 'NEXT IN QUEUE • 1080P HD';

    return Container(
      width: 450,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
      decoration: BoxDecoration(
        color: const Color(0xF207111F),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accentColor.withValues(alpha: 0.8), width: 1.6),
        boxShadow: [
          BoxShadow(
            color: accentDark.withValues(alpha: 0.35),
            blurRadius: 26,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
          const BoxShadow(
            color: Colors.black87,
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isHiFiPrep
                            ? const [Color(0xFFD97706), Color(0xFFB45309)]
                            : const [Color(0xFF0284C7), Color(0xFF0369A1)],
                      ),
                      borderRadius: BorderRadius.circular(6),
                      boxShadow: [
                        BoxShadow(color: accentColor.withValues(alpha: 0.4), blurRadius: 6),
                      ],
                    ),
                    child: Text(
                      badgeText,
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 13,
                    height: 13,
                    child: CircularProgressIndicator(strokeWidth: 2, color: accentColor),
                  ),
                ],
              ),
              GestureDetector(
                onTap: () {
                  _preparingPollTimer?.cancel();
                  setState(() {
                    _preparingVideoId = null;
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0x33FFFFFF),
                    border: Border.all(color: accentColor.withValues(alpha: 0.3), width: 1.0),
                  ),
                  child: const Icon(Icons.close, size: 14, color: Colors.white70),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            _preparingTrackTitle ?? 'Loading track...',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Container(
                      height: 5,
                      decoration: BoxDecoration(
                        color: const Color(0x28FFFFFF),
                        borderRadius: BorderRadius.circular(2.5),
                      ),
                    ),
                    FractionallySizedBox(
                      widthFactor: _preparingProgress.clamp(0.0, 1.0),
                      child: Container(
                        height: 5,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: isHiFiPrep
                                ? const [Color(0xFFD97706), Color(0xFFFBBF24)]
                                : const [Color(0xFF0284C7), Color(0xFF38BDF8)],
                          ),
                          borderRadius: BorderRadius.circular(2.5),
                          boxShadow: [
                            BoxShadow(color: accentColor.withValues(alpha: 0.5), blurRadius: 6),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Text(
                '$_preparingPercent%',
                style: TextStyle(
                  color: accentColor,
                  fontWeight: FontWeight.w800,
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 3),
          Text(
            _preparingStatus,
            style: const TextStyle(
              fontSize: 11,
              color: Color(0xAA94A3B8),
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBpmTelemetry() {
    return ValueListenableBuilder<int>(
      valueListenable: _bpmNotifier,
      builder: (context, bpm, child) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  '$bpm',
                  style: const TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.w200,
                    letterSpacing: -1.5,
                    color: Colors.white,
                    shadows: [
                      Shadow(color: Color(0x6600E5FF), blurRadius: 16),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                const Text(
                  'BPM',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                    color: Color(0xDD60A5FA),
                  ),
                ),
              ],
            ),
            ValueListenableBuilder<bool>(
              valueListenable: _isPlayingNotifier,
              builder: (context, isPlaying, _) {
                if (!isPlaying) {
                  return const SizedBox.shrink();
                }
                return ValueListenableBuilder<double>(
                  valueListenable: _phaseErrorNotifier,
                  builder: (context, phaseError, child) {
                    final isLocked = phaseError.abs() < 1.0;
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 9,
                          height: 9,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isLocked ? const Color(0xFF10B981) : const Color(0xFFF59E0B),
                            boxShadow: [
                              BoxShadow(
                                color: isLocked ? const Color(0xFF10B981) : const Color(0xFFF59E0B),
                                blurRadius: 8,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 7),
                        Text(
                          isLocked ? 'PHASE LOCK +/-${phaseError.abs().toStringAsFixed(1)}ms' : 'SYNCHRONIZING',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.2,
                            color: Color(0xCCFFFFFF),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        );
      },
    );
  }

  Widget _buildTrackInfoCallout() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 380,
          child: Text(
            _currentTrackTitle,
            textAlign: TextAlign.right,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w900,
              height: 1.12,
              letterSpacing: -0.6,
              color: Colors.white,
              shadows: [
                Shadow(color: Colors.black, blurRadius: 18),
                Shadow(color: Color(0xCC000000), blurRadius: 6),
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          _currentArtist,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: Color(0xCCBAE6FD),
            shadows: [
              Shadow(color: Colors.black, blurRadius: 8),
            ],
          ),
        ),
        if (_isHiFi && _currentAlbumName.isNotEmpty) ...[
          const SizedBox(height: 2),
          Text(
            _currentAlbumName,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: Color(0x99FBBF24),
              shadows: [
                Shadow(color: Colors.black, blurRadius: 6),
              ],
            ),
          ),
        ],
        const SizedBox(height: 7),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Liquid Glass Queue Pill Button
            TactileButton(
              scaleFactor: 0.93,
              onTap: () {
                setState(() => _isQueueOpen = true);
                _loadCachedTracks();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0x403B82F6),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0x9960A5FA), width: 1.4),
                  boxShadow: const [
                    BoxShadow(color: Color(0x3300E5FF), blurRadius: 12),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.queue_music, size: 16, color: Color(0xFF93C5FD)),
                    SizedBox(width: 6),
                    Text(
                      'QUEUE',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: Color(0xFF93C5FD)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Radial Favorites Carousel Pill Button
            TactileButton(
              scaleFactor: 0.93,
              onTap: () {
                setState(() => _isRadialCarouselOpen = true);
                _loadCachedTracks();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0x4010B981),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0x9934D399), width: 1.4),
                  boxShadow: const [
                    BoxShadow(color: Color(0x3310B981), blurRadius: 12),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.stars_rounded, size: 16, color: Color(0xFF6EE7B7)),
                    SizedBox(width: 6),
                    Text(
                      'FAVORITES',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: Color(0xFF6EE7B7)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Dedicated Stop Cast / Disconnect Button
            TactileButton(
              scaleFactor: 0.93,
              onTap: _stopCasting,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0x40EF4444),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0x99F87171), width: 1.4),
                  boxShadow: const [
                    BoxShadow(color: Color(0x33EF4444), blurRadius: 12),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.stop_circle_rounded, size: 16, color: Color(0xFFFCA5A5)),
                    SizedBox(width: 6),
                    Text(
                      'STOP CAST',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.8, color: Color(0xFFFCA5A5)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // Apple-Grade Liquid Glass Floating Transport Controls (With Centered Volume & Dynamic Prominent Color)
  Widget _buildMediaTransportControls() {
    return ValueListenableBuilder<Color>(
      valueListenable: _dominantColorNotifier,
      builder: (context, glowColor, _) {
        return Container(
          width: 540,
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xEE080D1A),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: glowColor.withValues(alpha: 0.55), width: 1.6),
            boxShadow: [
              BoxShadow(
                color: glowColor.withValues(alpha: 0.30),
                blurRadius: 28,
                spreadRadius: 1,
                offset: const Offset(0, 4),
              ),
              const BoxShadow(
                color: Colors.black87,
                blurRadius: 24,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 1. SUBTLE INTEGRATED SCRUBBER BAR
              ValueListenableBuilder<Duration>(
                valueListenable: _positionNotifier,
                builder: (context, pos, _) {
                  return ValueListenableBuilder<Duration>(
                    valueListenable: _durationNotifier,
                    builder: (context, dur, _) {
                      final durMs = dur.inMilliseconds;
                      final posMs = pos.inMilliseconds;
                      final progress = durMs > 0 ? (posMs / durMs).clamp(0.0, 1.0) : 0.0;

                      return Row(
                        children: [
                          // Current Position
                          SizedBox(
                            width: 44,
                            child: Text(
                              _formatDuration(pos),
                              style: const TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.5,
                                color: Color(0xCCBAE6FD),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Interactive Scrubber Track
                          Expanded(
                            child: LayoutBuilder(
                              builder: (context, constraints) {
                                final trackWidth = constraints.maxWidth;
                                return GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTapDown: (details) {
                                    if (durMs > 0 && trackWidth > 0) {
                                      final tapFraction = (details.localPosition.dx / trackWidth).clamp(0.0, 1.0);
                                      final seekMs = (tapFraction * durMs).round();
                                      _player.seek(Duration(milliseconds: seekMs));
                                    }
                                  },
                                  onHorizontalDragUpdate: (details) {
                                    if (durMs > 0 && trackWidth > 0) {
                                      final dragFraction = (details.localPosition.dx / trackWidth).clamp(0.0, 1.0);
                                      final seekMs = (dragFraction * durMs).round();
                                      _player.seek(Duration(milliseconds: seekMs));
                                    }
                                  },
                                  child: Container(
                                    height: 22, // Generous touch target
                                    alignment: Alignment.center,
                                    child: Stack(
                                      alignment: Alignment.centerLeft,
                                      children: [
                                        // Background Track
                                        Container(
                                          height: 4.0,
                                          width: trackWidth,
                                          decoration: BoxDecoration(
                                            color: const Color(0x28FFFFFF),
                                            borderRadius: BorderRadius.circular(2),
                                          ),
                                        ),
                                        // Active Filled Glow Bar with Dynamic Dominant Tint
                                        Container(
                                          height: 4.0,
                                          width: trackWidth * progress,
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              colors: [glowColor, Color.lerp(glowColor, Colors.white, 0.4)!],
                                            ),
                                            borderRadius: BorderRadius.circular(2),
                                            boxShadow: [
                                              BoxShadow(
                                                color: glowColor.withValues(alpha: 0.6),
                                                blurRadius: 6,
                                              ),
                                            ],
                                          ),
                                        ),
                                        // Luminous Scrubber Bead
                                        Positioned(
                                          left: (trackWidth * progress - 6).clamp(0.0, trackWidth - 12),
                                          child: Container(
                                            width: 12,
                                            height: 12,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Colors.white,
                                              border: Border.all(color: glowColor, width: 1.5),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: glowColor,
                                                  blurRadius: 8,
                                                  spreadRadius: 1,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Total Duration
                          SizedBox(
                            width: 44,
                            child: Text(
                              _formatDuration(dur),
                              textAlign: TextAlign.right,
                              style: const TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.5,
                                color: Color(0x99BAE6FD),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),

              const SizedBox(height: 6),

              // 2. PRIMARY TRANSPORT ROW (AUDIOPHILE TACTILE CONTROLS - ENLARGED TOUCH TARGETS)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // Shuffle Toggle Button
                  TactileButton(
                    scaleFactor: 0.88,
                    onTap: _toggleShuffle,
                    child: Container(
                      width: 48,
                      height: 52,
                      alignment: Alignment.center,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Icon(
                            Icons.shuffle_rounded,
                            color: _isShuffleEnabled ? const Color(0xFFF59E0B) : const Color(0x7794A3B8),
                            size: 25,
                          ),
                          if (_isShuffleEnabled)
                            Positioned(
                              bottom: 3,
                              child: Container(
                                width: 5,
                                height: 5,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xFFF59E0B),
                                  boxShadow: [
                                    BoxShadow(color: Color(0xFFF59E0B), blurRadius: 4),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),

                  // Rewind 10s
                  TactileButton(
                    scaleFactor: 0.88,
                    onTap: () => _seekRelative(-10),
                    child: Container(
                      width: 50,
                      height: 54,
                      alignment: Alignment.center,
                      child: const Icon(Icons.replay_10, color: Color(0xDD93C5FD), size: 30),
                    ),
                  ),

                  // Previous Track
                  TactileButton(
                    scaleFactor: 0.88,
                    onTap: _playPreviousTrack,
                    child: Container(
                      width: 58,
                      height: 58,
                      alignment: Alignment.center,
                      child: const Icon(Icons.skip_previous_rounded, color: Colors.white, size: 38),
                    ),
                  ),

                  // Centered Play / Pause Button (Soft Frosted Obsidian Glass, Subtle Organic Tint, Breathing in Standby)
                  ValueListenableBuilder<bool>(
                    valueListenable: _isPlayingNotifier,
                    builder: (context, isPlaying, _) {
                      return TactileButton(
                        scaleFactor: 0.92,
                        onTap: _togglePlayPause,
                        child: AnimatedBuilder(
                          animation: _waveController,
                          builder: (context, child) {
                            final breath = isPlaying
                                ? 0.0
                                : (math.sin(_waveController.value * 2 * math.pi) * 0.5 + 0.5);
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 600),
                              curve: Curves.easeInOutCubic,
                              width: 74 + (breath * 6),
                              height: 74 + (breath * 6),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xEE080D18),
                                border: Border.all(
                                  color: glowColor.withValues(alpha: isPlaying ? 0.22 : 0.35 + 0.30 * breath),
                                  width: isPlaying ? 1.5 : 1.8 + 0.6 * breath,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: glowColor.withValues(alpha: isPlaying ? 0.15 : 0.25 + 0.28 * breath),
                                    blurRadius: isPlaying ? 22 : 26 + 10 * breath,
                                    spreadRadius: isPlaying ? 0 : 2 * breath,
                                  ),
                                  const BoxShadow(
                                    color: Colors.black87,
                                    blurRadius: 16,
                                    offset: Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Icon(
                                  isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                  color: Colors.white.withValues(alpha: isPlaying ? 0.90 : 0.98),
                                  size: isPlaying ? 42 : 44,
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),

                  // Next Track
                  TactileButton(
                    scaleFactor: 0.88,
                    onTap: _playNextTrack,
                    child: Container(
                      width: 58,
                      height: 58,
                      alignment: Alignment.center,
                      child: const Icon(Icons.skip_next_rounded, color: Colors.white, size: 38),
                    ),
                  ),

                  // Forward 10s
                  TactileButton(
                    scaleFactor: 0.88,
                    onTap: () => _seekRelative(10),
                    child: Container(
                      width: 50,
                      height: 54,
                      alignment: Alignment.center,
                      child: const Icon(Icons.forward_10, color: Color(0xDD93C5FD), size: 30),
                    ),
                  ),

                  // Repeat Toggle Button
                  TactileButton(
                    scaleFactor: 0.88,
                    onTap: _toggleRepeat,
                    child: Container(
                      width: 48,
                      height: 52,
                      alignment: Alignment.center,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Icon(
                            _repeatMode == RepeatMode.one ? Icons.repeat_one_rounded : Icons.repeat_rounded,
                            color: _repeatMode != RepeatMode.off ? const Color(0xFFF59E0B) : const Color(0x7794A3B8),
                            size: 25,
                          ),
                          if (_repeatMode != RepeatMode.off)
                            Positioned(
                              bottom: 3,
                              child: Container(
                                width: 5,
                                height: 5,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xFFF59E0B),
                                  boxShadow: [
                                    BoxShadow(color: Color(0xFFF59E0B), blurRadius: 4),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 6),

              // 3. INTEGRATED APPLE GLASS VOLUME CONTROL CENTERED DIRECTLY BELOW PLAY BUTTON
              ValueListenableBuilder<double>(
                valueListenable: _volumeNotifier,
                builder: (context, vol, _) {
                  final isMuted = vol <= 0.01;
                  final iconData = isMuted
                      ? Icons.volume_off_rounded
                      : (vol < 50 ? Icons.volume_down_rounded : Icons.volume_up_rounded);

                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Mute Toggle Icon (Touch friendly)
                      TactileButton(
                        scaleFactor: 0.88,
                        onTap: _toggleMute,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                          child: Icon(
                            iconData,
                            color: isMuted ? const Color(0xFFF87171) : glowColor,
                            size: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Tactile Volume Slider Track (190px wide for easy finger sliding)
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapDown: (details) {
                          const sliderW = 190.0;
                          final newVol = ((details.localPosition.dx / sliderW) * 100.0).clamp(0.0, 100.0);
                          _setVolume(newVol);
                        },
                        onHorizontalDragUpdate: (details) {
                          const sliderW = 190.0;
                          final newVol = ((details.localPosition.dx / sliderW) * 100.0).clamp(0.0, 100.0);
                          _setVolume(newVol);
                        },
                        child: Container(
                          width: 190,
                          height: 34,
                          alignment: Alignment.centerLeft,
                          child: Stack(
                            alignment: Alignment.centerLeft,
                            children: [
                              Container(
                                height: 6,
                                width: 190,
                                decoration: BoxDecoration(
                                  color: const Color(0x33FFFFFF),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                              ),
                              Container(
                                height: 6,
                                width: 190 * (vol / 100.0),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [glowColor, Color.lerp(glowColor, Colors.white, 0.35)!],
                                  ),
                                  borderRadius: BorderRadius.circular(3),
                                  boxShadow: [
                                    BoxShadow(
                                      color: glowColor.withValues(alpha: 0.6),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                              ),
                              Positioned(
                                left: (190 * (vol / 100.0) - 7).clamp(0.0, 176.0),
                                child: Container(
                                  width: 14,
                                  height: 14,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.white,
                                    border: Border.all(color: glowColor, width: 2),
                                    boxShadow: [
                                      BoxShadow(
                                        color: glowColor.withValues(alpha: 0.8),
                                        blurRadius: 7,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Volume Percentage
                      SizedBox(
                        width: 36,
                        child: Text(
                          '${vol.round()}%',
                          style: TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                            color: isMuted ? const Color(0x88F87171) : const Color(0xCCBAE6FD),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildKinematicsAndTimeline() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Robot Telemetry Complication Line
        ValueListenableBuilder<double>(
          valueListenable: _apexHeightNotifier,
          builder: (context, apex, _) {
            return ValueListenableBuilder<String>(
              valueListenable: _ballStateNotifier,
              builder: (context, ballState, _) {
                return ValueListenableBuilder<double>(
                  valueListenable: _pitchNotifier,
                  builder: (context, pitch, _) {
                    return ValueListenableBuilder<double>(
                      valueListenable: _rollNotifier,
                      builder: (context, roll, _) {
                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                          decoration: BoxDecoration(
                            color: const Color(0x99080E1C),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: const Color(0x3360A5FA), width: 1.0),
                          ),
                          child: Text(
                            'BALL: $ballState   |   APEX: ${apex.toStringAsFixed(1)} MM   |   PITCH: ${pitch >= 0 ? "+" : ""}${pitch.toStringAsFixed(1)}°',
                            style: const TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.0,
                              color: Color(0xAA93C5FD),
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            );
          },
        ),
      ],
    );
  }

  // --- RADIAL CAROUSEL FOR LOCALLY CACHED FAVORITES ---
  Widget _buildRadialCarousel(double size) {
    final radius = size * 0.33;
    final count = _cachedTracks.length;
    final angleStep = count > 0 ? (2 * math.pi / count) : 0.0;

    return GestureDetector(
      onPanUpdate: (details) {
        setState(() {
          _carouselAngle += details.delta.dx * 0.006;
        });
      },
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Dark glassmorphic backdrop vignette
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 0.95,
                colors: [
                  Color(0xF2050811),
                  Color(0xF8030509),
                  Color(0xFA000000),
                ],
              ),
            ),
          ),

          // Center Close / Favorites Indicator
          TactileButton(
            scaleFactor: 0.94,
            onTap: () => setState(() => _isRadialCarouselOpen = false),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xCC0B132B),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: const Color(0xFF34D399), width: 1.6),
                boxShadow: const [
                  BoxShadow(color: Color(0x4410B981), blurRadius: 20),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.stars_rounded, color: Color(0xFF34D399), size: 22),
                      SizedBox(width: 8),
                      Text(
                        'FAVORITES',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    count == 0 ? 'No cached tracks' : '$count tracks • Tap to close',
                    style: const TextStyle(
                      color: Color(0x99A7F3D0),
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Orbital Cards
          if (count > 0)
            ...List.generate(count, (index) {
              final track = _cachedTracks[index];
              final angle = angleStep * index + _carouselAngle;
              final x = radius * math.cos(angle);
              final y = radius * math.sin(angle);
              final isCurrent = track['video_id'] == _activeVideoId;
              final videoId = track['video_id'] ?? '';

              return Positioned(
                left: size / 2 + x - 60,
                top: size / 2 + y - 60,
                child: TactileButton(
                  scaleFactor: 0.92,
                  onTap: () {
                    _currentPlaylistIndex = index;
                    _playTrack(track);
                    setState(() => _isRadialCarouselOpen = false);
                  },
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: const Color(0xEE0B1528),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: isCurrent ? const Color(0xFF34D399) : const Color(0x4460A5FA),
                        width: isCurrent ? 2.5 : 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: isCurrent ? const Color(0x6610B981) : Colors.black87,
                          blurRadius: 14,
                        ),
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        // Cover image
                        Image.network(
                          'http://127.0.0.1:8000/media/$videoId/cover.jpg',
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Container(
                            color: const Color(0xFF1E293B),
                            child: const Icon(Icons.music_note, color: Colors.white54, size: 36),
                          ),
                        ),
                        // Bottom gradient shadow for readable text
                        Container(
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.transparent, Color(0xDD000000)],
                              stops: [0.35, 1.0],
                            ),
                          ),
                        ),
                        // Track title & artist
                        Positioned(
                          left: 8,
                          right: 8,
                          bottom: 8,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                track['title'] ?? 'Track',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              Text(
                                track['artist'] ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Color(0xAA93C5FD),
                                  fontSize: 8.5,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (isCurrent)
                          Positioned(
                            top: 6,
                            right: 6,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xFF10B981),
                              ),
                              child: const Icon(Icons.play_arrow, color: Colors.white, size: 14),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }

  // --- QUEUE / PLAYLIST QUICK DRAWER ---

  Widget _buildQueueDrawer(double size) {
    return Stack(
      children: [
        Container(color: const Color(0xF505070B)),
        Positioned(
          top: size * 0.16,
          left: size * 0.16,
          right: size * 0.16,
          bottom: size * 0.15,
          child: Column(
            children: [
              // Header with spacious safe margins and large tap target close button
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.queue_music, size: 20, color: Color(0xFF60A5FA)),
                        SizedBox(width: 8),
                        Text(
                          'QUEUE & LIBRARY',
                          style: TextStyle(
                            fontSize: 15.5,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.2,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                    TactileButton(
                      scaleFactor: 0.88,
                      onTap: () => setState(() => _isQueueOpen = false),
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0x33FFFFFF),
                          border: Border.all(color: const Color(0x5560A5FA), width: 1.2),
                          boxShadow: const [
                            BoxShadow(color: Colors.black54, blurRadius: 6),
                          ],
                        ),
                        child: const Icon(Icons.close, size: 22, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: _cachedTracks.isEmpty
                    ? const Center(
                        child: Text(
                          'No cached tracks found.\nUse Search to download music videos.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Color(0x66FFFFFF), fontSize: 13.5),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
                        itemCount: _cachedTracks.length,
                        itemBuilder: (context, idx) {
                          final t = _cachedTracks[idx];
                          final isCurrent = t['video_id'] == _activeVideoId;
                          return TactileButton(
                            scaleFactor: 0.96,
                            onTap: () {
                              _currentPlaylistIndex = idx;
                              _playTrack(t);
                            },
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 3.5),
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                              decoration: BoxDecoration(
                                color: isCurrent ? const Color(0x443B82F6) : const Color(0x1AFFFFFF),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: isCurrent ? const Color(0xFF60A5FA) : const Color(0x22FFFFFF),
                                  width: 1.4,
                                ),
                              ),
                              child: Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: SizedBox(
                                      width: 38,
                                      height: 38,
                                      child: Stack(
                                        fit: StackFit.expand,
                                        children: [
                                          Image.network(
                                            'http://127.0.0.1:8000/media/${t['video_id']}/cover.jpg',
                                            fit: BoxFit.cover,
                                            errorBuilder: (_, _, _) => Container(
                                              color: const Color(0x3360A5FA),
                                              child: Icon(
                                                isCurrent ? Icons.play_arrow_rounded : Icons.music_note_rounded,
                                                color: isCurrent ? const Color(0xFF60A5FA) : Colors.white60,
                                                size: 20,
                                              ),
                                            ),
                                          ),
                                          if (isCurrent)
                                            Container(
                                              color: const Color(0x660284C7),
                                              child: const Center(
                                                child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 20),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          t['title'] ?? 'Unknown',
                                          style: TextStyle(
                                            color: isCurrent ? const Color(0xFF93C5FD) : Colors.white,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 13,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Text(
                                          '${t['artist'] ?? ''} - ${t['bpm'] ?? '--'} BPM',
                                          style: const TextStyle(color: Color(0x88FFFFFF), fontSize: 11),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // --- CIRCULAR-CONSTRAINED GLASS SEARCH OVERLAY & KEYBOARD ---

  Widget _buildGlassSearchOverlay(double size) {
    const enRow1 = ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'];
    const enRow2 = ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'];
    const enRow3 = ['Z', 'X', 'C', 'V', 'B', 'N', 'M'];

    const arRow1 = ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج'];
    const arRow2 = ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط'];
    const arRow3 = ['ئ', 'ء', 'ؤ', 'ر', 'ى', 'ة', 'و', 'ز', 'ظ'];

    final displayItems = _searchResults.isNotEmpty
        ? _searchResults
        : _cachedTracks.map((t) => {
              'video_id': t['video_id'],
              'title': t['title'],
              'artist': t['artist'],
              'duration': '${(t['duration_seconds'] ?? 0) ~/ 60}:${((t['duration_seconds'] ?? 0) % 60).toString().padLeft(2, '0')}',
              'is_cached': true,
            }).toList();

    return Stack(
      children: [
        // Dark Dimmer
        Container(color: const Color(0xF205070B)),

        // Search Input Header & Mode Switcher (Centered safe width: 500px at top: size * 0.11)
        Positioned(
          top: size * 0.11,
          left: 0,
          right: 0,
          child: Center(
            child: SizedBox(
              width: 500,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Search Bar Container
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                    decoration: BoxDecoration(
                      color: const Color(0xF0121827),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: _isSearchHiFiMode ? const Color(0xFFF59E0B) : const Color(0x8860A5FA),
                        width: 1.6,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _isSearchHiFiMode ? const Color(0x33F59E0B) : const Color(0x3360A5FA),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                        const BoxShadow(color: Colors.black54, blurRadius: 10, offset: Offset(0, 4)),
                      ],
                    ),
                    child: Row(
                      children: [
                        Icon(
                          _isSearchHiFiMode ? Icons.album_rounded : Icons.search,
                          color: _isSearchHiFiMode ? const Color(0xFFFBBF24) : const Color(0xFFFF0000),
                          size: 20,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _searchQuery.isEmpty
                                ? (_isSearchHiFiMode ? 'Search Hi-Fi Lossless (FLAC)...' : 'Type to search YouTube...')
                                : _searchQuery,
                            style: TextStyle(
                              fontSize: 15.0,
                              fontWeight: FontWeight.w500,
                              color: _searchQuery.isEmpty ? const Color(0x66FFFFFF) : Colors.white,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (_searchQuery.isNotEmpty)
                          TactileButton(
                            scaleFactor: 0.88,
                            onTap: () {
                              setState(() {
                                _searchQuery = '';
                                _searchResults = [];
                                _hifiSearchResults = [];
                              });
                            },
                            child: Container(
                              margin: const EdgeInsets.only(right: 8),
                              width: 32,
                              height: 32,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0x33FFFFFF),
                              ),
                              child: const Icon(Icons.clear_rounded, size: 18, color: Colors.white70),
                            ),
                          ),
                        TactileButton(
                          scaleFactor: 0.88,
                          onTap: () => setState(() => _isSearchOpen = false),
                          child: Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0x33FFFFFF),
                              border: Border.all(
                                color: _isSearchHiFiMode ? const Color(0x66F59E0B) : const Color(0x5560A5FA),
                                width: 1.0,
                              ),
                            ),
                            child: const Icon(Icons.close, size: 20, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 8),

                  // Segmented Mode Switcher Pill: [ 🎬 YouTube ] | [ 💿 Hi-Fi Lossless ]
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: const Color(0xEE0D1322),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: _isSearchHiFiMode ? const Color(0x55F59E0B) : const Color(0x4460A5FA),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // YouTube Tab
                        TactileButton(
                          scaleFactor: 0.94,
                          onTap: () {
                            if (_isSearchHiFiMode) {
                              setState(() => _isSearchHiFiMode = false);
                              _triggerDebouncedSearch();
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
                            decoration: BoxDecoration(
                              color: !_isSearchHiFiMode ? const Color(0xFF2563EB) : Colors.transparent,
                              borderRadius: BorderRadius.circular(999),
                              border: !_isSearchHiFiMode
                                  ? Border.all(color: const Color(0xFF93C5FD), width: 1.2)
                                  : null,
                              boxShadow: !_isSearchHiFiMode
                                  ? const [BoxShadow(color: Color(0x662563EB), blurRadius: 10)]
                                  : null,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.smart_display_rounded,
                                  size: 16,
                                  color: !_isSearchHiFiMode ? Colors.white : const Color(0x88FFFFFF),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'YouTube',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: !_isSearchHiFiMode ? FontWeight.w800 : FontWeight.w500,
                                    color: !_isSearchHiFiMode ? Colors.white : const Color(0x88FFFFFF),
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(width: 6),

                        // Hi-Fi Lossless Tab
                        TactileButton(
                          scaleFactor: 0.94,
                          onTap: () {
                            if (!_isSearchHiFiMode) {
                              setState(() => _isSearchHiFiMode = true);
                              if (_hifiFlatTrackIndex.isEmpty) {
                                _loadHiFiTree();
                              }
                              _triggerDebouncedSearch();
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
                            decoration: BoxDecoration(
                              color: _isSearchHiFiMode ? const Color(0xFFD97706) : Colors.transparent,
                              borderRadius: BorderRadius.circular(999),
                              border: _isSearchHiFiMode
                                  ? Border.all(color: const Color(0xFFFDE68A), width: 1.2)
                                  : null,
                              boxShadow: _isSearchHiFiMode
                                  ? const [BoxShadow(color: Color(0x66F59E0B), blurRadius: 10)]
                                  : null,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.album_rounded,
                                  size: 16,
                                  color: _isSearchHiFiMode ? Colors.white : const Color(0x88FFFFFF),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Hi-Fi Lossless',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: _isSearchHiFiMode ? FontWeight.w800 : FontWeight.w500,
                                    color: _isSearchHiFiMode ? Colors.white : const Color(0x88FFFFFF),
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // Result List in Middle Viewport (Safe inside 1080px circle, sits cleanly above raised keyboard)
        Positioned(
          top: size * 0.23,
          bottom: size * 0.44,
          left: size * 0.14,
          right: size * 0.14,
          child: _isLoadingTracks
              ? Center(
                  child: SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: _isSearchHiFiMode ? const Color(0xFFFBBF24) : const Color(0xFF3B82F6),
                    ),
                  ),
                )
              : _isSearchHiFiMode
                  ? _buildHiFiSearchResultsList()
                  : _buildYouTubeSearchResultsList(displayItems),
        ),

        // Raised Touch Keyboard Fitted Inside 1080px Circular Safe Zone (Total width ~520px)
        Positioned(
          bottom: size * 0.12,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xF4080D18),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: _isSearchHiFiMode ? const Color(0x88F59E0B) : const Color(0x6660A5FA),
                  width: 1.6,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _isSearchHiFiMode ? const Color(0x44F59E0B) : const Color(0x4400E5FF),
                    blurRadius: 24,
                    spreadRadius: 1,
                  ),
                  const BoxShadow(
                    color: Colors.black87,
                    blurRadius: 28,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: _isArabicKeyboard
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Arabic Row 1: 11 keys
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: arRow1.map((k) => _buildKey(k, 42, height: 52)).toList(),
                        ),
                        const SizedBox(height: 5),
                        // Arabic Row 2: 11 keys
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: arRow2.map((k) => _buildKey(k, 42, height: 52)).toList(),
                        ),
                        const SizedBox(height: 5),
                        // Arabic Row 3: 9 keys + BKSP
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ...arRow3.map((k) => _buildKey(k, 42, height: 52)),
                            _buildIconKey(Icons.backspace_rounded, 'BKSP', 62, height: 52, isAction: true),
                          ],
                        ),
                        const SizedBox(height: 5),
                        // Arabic Row 4: Switch to English + Space + Enter
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildKey('LANG', 68, height: 50, isAction: true, displayText: '🌐 EN'),
                            const SizedBox(width: 4),
                            _buildKey('SPACE', 310, height: 50, isAction: true, displayText: 'مسافة'),
                            const SizedBox(width: 4),
                            _buildIconKey(Icons.keyboard_return_rounded, 'ENTER', 78, height: 50, isAction: true),
                          ],
                        ),
                      ],
                    )
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // English Row 1 (QWERTY: 10 keys * 47px = 470px)
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: enRow1.map((k) => _buildKey(
                            _isShiftUpper ? k.toUpperCase() : k.toLowerCase(),
                            47,
                            height: 52,
                          )).toList(),
                        ),
                        const SizedBox(height: 5),
                        // English Row 2 (ASDF: 9 keys * 51px = 459px)
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: enRow2.map((k) => _buildKey(
                            _isShiftUpper ? k.toUpperCase() : k.toLowerCase(),
                            51,
                            height: 52,
                          )).toList(),
                        ),
                        const SizedBox(height: 5),
                        // English Row 3 (Shift + 7 keys + Backspace)
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildIconKey(Icons.arrow_upward_rounded, 'SHIFT', 58, height: 52, isAction: true, isActive: _isShiftUpper),
                            ...enRow3.map((k) => _buildKey(
                              _isShiftUpper ? k.toUpperCase() : k.toLowerCase(),
                              47,
                              height: 52,
                            )),
                            _buildIconKey(Icons.backspace_rounded, 'BKSP', 58, height: 52, isAction: true),
                          ],
                        ),
                        const SizedBox(height: 5),
                        // English Row 4: Switch to Arabic + Space + Enter
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildKey('LANG', 68, height: 50, isAction: true, displayText: '🌐 عربي'),
                            const SizedBox(width: 4),
                            _buildKey('SPACE', 310, height: 50, isAction: true, displayText: 'SPACE'),
                            const SizedBox(width: 4),
                            _buildIconKey(Icons.keyboard_return_rounded, 'ENTER', 78, height: 50, isAction: true),
                          ],
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHiFiSearchResultsList() {
    final displayHiFi = _hifiSearchResults.isNotEmpty
        ? _hifiSearchResults
        : (_searchQuery.isEmpty ? _hifiFlatTrackIndex.take(35).toList() : <Map<String, dynamic>>[]);

    if (displayHiFi.isEmpty) {
      return Center(
        child: Text(
          _searchQuery.isEmpty
              ? 'Touch keys below to search ${_hifiFlatTrackIndex.length} Hi-Fi tracks'
              : 'No lossless tracks found for "$_searchQuery"',
          style: const TextStyle(color: Color(0x77FFFFFF), fontSize: 13.5),
          textAlign: TextAlign.center,
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemCount: displayHiFi.length,
      itemBuilder: (context, index) {
        final item = displayHiFi[index];
        final title = item['title']?.toString() ?? 'Unknown Track';
        final artist = item['artist']?.toString() ?? 'Unknown Artist';
        final album = item['album']?.toString() ?? '';
        final coverKey = item['cover_key']?.toString() ?? '${artist}_$album';
        final trackId = item['track_id']?.toString() ?? '';

        return TactileButton(
          scaleFactor: 0.96,
          onTap: () {
            setState(() => _isSearchOpen = false);
            final playlist = _hifiSearchResults.isNotEmpty ? _hifiSearchResults : _hifiFlatTrackIndex;
            final idx = playlist.indexOf(item);
            _playHiFiTrack(trackId, playlist: playlist, index: idx >= 0 ? idx : 0);
          },
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 3),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0x22F59E0B),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0x33F59E0B), width: 1.0),
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: SizedBox(
                    width: 36,
                    height: 36,
                    child: Image.network(
                      'http://127.0.0.1:8000/api/hifi/cover?key=${Uri.encodeComponent(coverKey)}',
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => Container(
                        color: const Color(0x33F59E0B),
                        child: const Icon(
                          Icons.album_rounded,
                          color: Color(0xFFFBBF24),
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        album.isNotEmpty ? '$artist • $album' : artist,
                        style: const TextStyle(
                          color: Color(0x99FFFFFF),
                          fontSize: 11,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: const Color(0x33F59E0B),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: const Color(0x88F59E0B), width: 0.8),
                  ),
                  child: const Text(
                    'FLAC',
                    style: TextStyle(
                      color: Color(0xFFFBBF24),
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildYouTubeSearchResultsList(List<Map<String, dynamic>> displayItems) {
    if (displayItems.isEmpty) {
      return const Center(
        child: Text(
          'Touch letters below to search or play cached tracks',
          style: TextStyle(color: Color(0x59FFFFFF), fontSize: 13.5),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemCount: displayItems.length,
      itemBuilder: (context, index) {
        final item = displayItems[index];
        final isCached = item['is_cached'] == true;
        return TactileButton(
          scaleFactor: 0.96,
          onTap: () => _playTrack(item),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 3),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              color: const Color(0x22FFFFFF),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0x25FFFFFF), width: 1.0),
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: SizedBox(
                    width: 34,
                    height: 34,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.network(
                          isCached
                              ? 'http://127.0.0.1:8000/media/${item['video_id']}/cover.jpg'
                              : (item['thumbnail'] ?? 'http://127.0.0.1:8000/media/${item['video_id']}/cover.jpg'),
                          fit: BoxFit.cover,
                          errorBuilder: (_, _, _) => Container(
                            color: const Color(0x3360A5FA),
                            child: Icon(
                              isCached ? Icons.offline_pin_rounded : Icons.ondemand_video_rounded,
                              color: isCached ? const Color(0xFF10B981) : const Color(0xFF60A5FA),
                              size: 18,
                            ),
                          ),
                        ),
                        if (isCached)
                          Positioned(
                            top: 2,
                            right: 2,
                            child: Container(
                              padding: const EdgeInsets.all(2),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xFF10B981),
                              ),
                              child: const Icon(Icons.check, size: 8, color: Colors.white),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item['title'] ?? 'Unknown',
                        style: const TextStyle(color: Colors.white, fontSize: 13.5, fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        '${item['artist'] ?? ''} - ${item['duration'] ?? ''}',
                        style: const TextStyle(color: Color(0x88FFFFFF), fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCitySearchOverlay(double size) {
    const enRow1 = ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'];
    const enRow2 = ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'];
    const enRow3 = ['Z', 'X', 'C', 'V', 'B', 'N', 'M'];

    const arRow1 = ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج'];
    const arRow2 = ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط'];
    const arRow3 = ['ئ', 'ء', 'ؤ', 'ر', 'ى', 'ة', 'و', 'ز', 'ظ'];

    final quickCities = [
      'Auto (IP)',
      'Sheffield',
      'London',
      'Manchester',
      'Paris',
      'New York',
      'Dubai',
      'Riyadh',
      'Tokyo',
      'Cairo',
      'Amsterdam',
    ];

    return Stack(
      children: [
        // Dark Dimmer
        Container(color: const Color(0xF4040711)),

        // Search Input Header (Centered safe width: 510px at top: size * 0.12)
        Positioned(
          top: size * 0.12,
          left: 0,
          right: 0,
          child: Center(
            child: SizedBox(
              width: 510,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xF0101827),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: _weatherThemeColor, width: 1.8),
                  boxShadow: [
                    BoxShadow(color: _weatherThemeColor.withValues(alpha: 0.3), blurRadius: 16),
                    const BoxShadow(color: Colors.black87, blurRadius: 10, offset: Offset(0, 4)),
                  ],
                ),
                child: Row(
                  children: [
                    Icon(Icons.location_on_rounded, color: _weatherThemeColor, size: 22),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _citySearchQuery.isEmpty ? 'Type city to search (e.g. Dubai, London)...' : _citySearchQuery,
                        style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.w600,
                          color: _citySearchQuery.isEmpty ? const Color(0x66FFFFFF) : Colors.white,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (_citySearchQuery.isNotEmpty)
                      TactileButton(
                        scaleFactor: 0.88,
                        onTap: () {
                          setState(() {
                            _citySearchQuery = '';
                            _citySearchResults = [];
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(right: 8),
                          width: 32,
                          height: 32,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0x33FFFFFF),
                          ),
                          child: const Icon(Icons.clear_rounded, size: 18, color: Colors.white70),
                        ),
                      ),
                    TactileButton(
                      scaleFactor: 0.88,
                      onTap: () => setState(() => _isCitySearchOpen = false),
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0x33FFFFFF),
                          border: Border.all(color: Colors.white24, width: 1.0),
                        ),
                        child: const Icon(Icons.close_rounded, size: 20, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),

        // Quick City Chips Row
        Positioned(
          top: size * 0.185,
          left: size * 0.12,
          right: size * 0.12,
          child: SizedBox(
            height: 36,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: quickCities.length,
              separatorBuilder: (_, _) => const SizedBox(width: 8),
              itemBuilder: (context, idx) {
                final cName = quickCities[idx];
                final isAuto = cName.startsWith('Auto');
                final isCurrent = _weatherCity.toLowerCase() == cName.toLowerCase();
                return TactileButton(
                  scaleFactor: 0.94,
                  onTap: () async {
                    setState(() => _isCitySearchOpen = false);
                    await _selectCity(cName);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: isCurrent
                          ? _weatherThemeColor.withValues(alpha: 0.3)
                          : (isAuto ? const Color(0x3300E5FF) : const Color(0x22FFFFFF)),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: isCurrent ? _weatherThemeColor : (isAuto ? const Color(0x6600E5FF) : Colors.white24),
                        width: 1.2,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (isAuto) ...[
                          const Icon(Icons.my_location_rounded, size: 14, color: Color(0xFF00E5FF)),
                          const SizedBox(width: 5),
                        ],
                        Text(
                          cName,
                          style: TextStyle(
                            color: isCurrent ? Colors.white : (isAuto ? const Color(0xFF00E5FF) : Colors.white70),
                            fontSize: 12.5,
                            fontWeight: isCurrent ? FontWeight.w700 : FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),

        // Result List in Middle Viewport
        Positioned(
          top: size * 0.24,
          bottom: size * 0.43,
          left: size * 0.14,
          right: size * 0.14,
          child: _isLoadingCities
              ? Center(
                  child: SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(strokeWidth: 2.5, color: _weatherThemeColor),
                  ),
                )
              : _citySearchResults.isEmpty && _citySearchQuery.trim().length >= 2
                  ? const Center(
                      child: Text(
                        'No matching cities found. Check spelling.',
                        style: TextStyle(color: Color(0x88FFFFFF), fontSize: 14),
                      ),
                    )
                  : _citySearchResults.isEmpty
                      ? const Center(
                          child: Text(
                            'Touch keyboard below to search any city worldwide',
                            style: TextStyle(color: Color(0x55FFFFFF), fontSize: 13.5),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          itemCount: _citySearchResults.length,
                          itemBuilder: (context, idx) {
                            final r = _citySearchResults[idx];
                            final name = r['name']?.toString() ?? '';
                            final country = r['country']?.toString() ?? '';
                            final admin1 = r['admin1']?.toString() ?? '';
                            final subLabel = [admin1, country].where((s) => s.isNotEmpty).join(', ');
                            final lat = (r['latitude'] as num?)?.toDouble();
                            final lon = (r['longitude'] as num?)?.toDouble();

                            return TactileButton(
                              scaleFactor: 0.96,
                              onTap: () async {
                                setState(() => _isCitySearchOpen = false);
                                await _selectCity(name, lat: lat, lon: lon);
                              },
                              child: Container(
                                margin: const EdgeInsets.symmetric(vertical: 4),
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                decoration: BoxDecoration(
                                  color: const Color(0x22FFFFFF),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: Colors.white24, width: 1.2),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.location_city_rounded, color: _weatherThemeColor, size: 22),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            name,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          if (subLabel.isNotEmpty) ...[
                                            const SizedBox(height: 2),
                                            Text(
                                              subLabel,
                                              style: TextStyle(
                                                color: Colors.white.withValues(alpha: 0.65),
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                    Icon(Icons.arrow_forward_ios_rounded, color: _weatherThemeColor.withValues(alpha: 0.7), size: 16),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
        ),

        // Keyboard Surface (Safe inside 1080px round HUD circle at bottom)
        Positioned(
          bottom: size * 0.05,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xF4080D18),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _weatherThemeColor.withValues(alpha: 0.5), width: 1.6),
                boxShadow: [
                  BoxShadow(color: _weatherThemeColor.withValues(alpha: 0.25), blurRadius: 20),
                  const BoxShadow(color: Colors.black87, blurRadius: 28, offset: Offset(0, 8)),
                ],
              ),
              child: _isCitySearchArabic
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: arRow1.map((k) => _buildKey(k, 42, height: 52, onTap: () => _onCityKeyTapped(k))).toList(),
                        ),
                        const SizedBox(height: 5),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: arRow2.map((k) => _buildKey(k, 42, height: 52, onTap: () => _onCityKeyTapped(k))).toList(),
                        ),
                        const SizedBox(height: 5),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ...arRow3.map((k) => _buildKey(k, 42, height: 52, onTap: () => _onCityKeyTapped(k))),
                            _buildIconKey(Icons.backspace_rounded, 'BKSP', 62, height: 52, isAction: true, onTap: () => _onCityKeyTapped('BKSP')),
                          ],
                        ),
                        const SizedBox(height: 5),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildKey('LANG', 68, height: 50, isAction: true, displayText: '🌐 EN', onTap: () => _onCityKeyTapped('LANG')),
                            const SizedBox(width: 4),
                            _buildKey('SPACE', 310, height: 50, isAction: true, displayText: 'مسافة', onTap: () => _onCityKeyTapped('SPACE')),
                            const SizedBox(width: 4),
                            _buildKey('CLEAR', 78, height: 50, isAction: true, displayText: 'مسح', onTap: () => _onCityKeyTapped('CLEAR')),
                          ],
                        ),
                      ],
                    )
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: enRow1.map((k) => _buildKey(
                            _isCityShiftUpper ? k.toUpperCase() : k.toLowerCase(),
                            47,
                            height: 52,
                            onTap: () => _onCityKeyTapped(k),
                          )).toList(),
                        ),
                        const SizedBox(height: 5),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: enRow2.map((k) => _buildKey(
                            _isCityShiftUpper ? k.toUpperCase() : k.toLowerCase(),
                            51,
                            height: 52,
                            onTap: () => _onCityKeyTapped(k),
                          )).toList(),
                        ),
                        const SizedBox(height: 5),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildIconKey(
                              Icons.arrow_upward_rounded,
                              'SHIFT',
                              58,
                              height: 52,
                              isAction: true,
                              isActive: _isCityShiftUpper,
                              onTap: () => _onCityKeyTapped('SHIFT'),
                            ),
                            ...enRow3.map((k) => _buildKey(
                              _isCityShiftUpper ? k.toUpperCase() : k.toLowerCase(),
                              47,
                              height: 52,
                              onTap: () => _onCityKeyTapped(k),
                            )),
                            _buildIconKey(Icons.backspace_rounded, 'BKSP', 58, height: 52, isAction: true, onTap: () => _onCityKeyTapped('BKSP')),
                          ],
                        ),
                        const SizedBox(height: 5),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildKey('LANG', 68, height: 50, isAction: true, displayText: '🌐 عربي', onTap: () => _onCityKeyTapped('LANG')),
                            const SizedBox(width: 4),
                            _buildKey('SPACE', 310, height: 50, isAction: true, displayText: 'SPACE', onTap: () => _onCityKeyTapped('SPACE')),
                            const SizedBox(width: 4),
                            _buildKey('CLEAR', 78, height: 50, isAction: true, displayText: 'CLEAR', onTap: () => _onCityKeyTapped('CLEAR')),
                          ],
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildKey(
    String label,
    double width, {
    double height = 60,
    bool isAction = false,
    String? displayText,
    VoidCallback? onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2.5),
      child: TactileButton(
        scaleFactor: 0.88,
        triggerOnTapDown: true,
        onTap: onTap ?? () => _onKeyTapped(label),
        child: Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            color: isAction ? const Color(0xEE1E293B) : const Color(0xDD0F172A),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isAction ? const Color(0x8860A5FA) : const Color(0x40FFFFFF),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.35),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            displayText ?? label,
            style: TextStyle(
              color: isAction ? const Color(0xFF93C5FD) : Colors.white,
              fontSize: isAction ? 15.5 : 23,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildIconKey(
    IconData icon,
    String action,
    double width, {
    double height = 60,
    bool isAction = true,
    bool isActive = false,
    VoidCallback? onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2.5),
      child: TactileButton(
        scaleFactor: 0.88,
        triggerOnTapDown: true,
        onTap: onTap ?? () => _onKeyTapped(action),
        child: Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            color: isActive
                ? const Color(0xFF2563EB)
                : (isAction ? const Color(0xEE1E293B) : const Color(0xDD0F172A)),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isActive ? const Color(0xFF93C5FD) : const Color(0x8860A5FA),
              width: 1.4,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.35),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Icon(
            icon,
            size: 24,
            color: isActive ? Colors.white : const Color(0xFF93C5FD),
          ),
        ),
      ),
    );
  }

  // --- CINEMATIC BOOTUP, CENTERPIECE & SETTINGS DECK BUILDERS ---

  Widget _buildBootSequence(double size) {
    final progress = _bootController.value;
    String status = 'INITIALIZING SYSTEM...';
    if (progress < 0.25) {
      status = 'CONNECTING TELEMETRY BUS & SHARED MEMORY...';
    } else if (progress < 0.50) {
      status = 'CALIBRATING 3-RRS INVERSE KINEMATICS...';
    } else if (progress < 0.75) {
      status = 'SYNCHRONIZING 1080P MEDIA PIPELINE...';
    } else if (progress < 0.95) {
      status = 'ENGAGING AUBIO BEAT TRACKING ENGINE...';
    } else {
      status = 'SYSTEM READY • CENTERPIECE ENGAGED';
    }

    return Container(
      color: Colors.black,
      child: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(
            painter: BootCalibrationPainter(
              progress: progress,
              primaryColor: const Color(0xFF00E5FF),
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: const Color(0xFF00E5FF), width: 1.8),
                    boxShadow: const [
                      BoxShadow(color: Color(0x6600E5FF), blurRadius: 18, spreadRadius: 2),
                    ],
                  ),
                  child: const Center(
                    child: Icon(Icons.blur_on_rounded, color: Colors.white, size: 36),
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  '3-RRS BALLISTIC JUGGLER',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 4.0,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'ARDUINO VENTUNO Q • DRAGONWING MPU',
                  style: TextStyle(
                    color: Color(0x9900E5FF),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 2.5,
                  ),
                ),
                const SizedBox(height: 28),
                Text(
                  '${(progress * 100).toInt()}%',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 36,
                    fontWeight: FontWeight.w200,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0x3300E5FF),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0x6600E5FF), width: 1.0),
                  ),
                  child: Text(
                    status,
                    style: const TextStyle(
                      color: Color(0xFFE0F2FE),
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: size * 0.12,
            left: 0,
            right: 0,
            child: Center(
              child: GestureDetector(
                onTap: () {
                  _bootController.stop();
                  setState(() {
                    _currentMode = PlinthMode.centerpiece;
                  });
                  _resetInactivityTimer();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0x33FFFFFF),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: const Color(0x44FFFFFF), width: 1.0),
                  ),
                  child: const Text(
                    'SKIP BOOT',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 2.0,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildCenterpieceMode(double size) {
    final hour = _currentClockTime.hour;
    final min = _currentClockTime.minute;
    final hour12 = (hour % 12 == 0) ? 12 : (hour % 12);
    final hourStr = hour12.toString();
    final minStr = min.toString().padLeft(2, '0');
    final amPmStr = hour >= 12 ? 'PM' : 'AM';

    const fullWeekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const fullMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    final dateStr = '${fullWeekdays[_currentClockTime.weekday - 1]}, ${fullMonths[_currentClockTime.month - 1]} ${_currentClockTime.day}';

    final themeColor = _weatherThemeColor;
    final weatherIcon = _getWeatherIcon(_weatherCode, _weatherIsDay);
    final tempStr = '${_weatherTemp.round()}°C';

    return Container(
      color: const Color(0xFF040812),
      child: Stack(
          fit: StackFit.expand,
          children: [
            // Layer 0: Deep Celestial Obsidian Canvas (Fills entire round display edge-to-edge)
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 1.25,
                    colors: [
                      Color(0xFF0C192E),
                      Color(0xFF081224),
                      Color(0xFF050D1A),
                      Color(0xFF030712),
                    ],
                    stops: [0.0, 0.45, 0.75, 1.0],
                  ),
                ),
              ),
            ),

            // Layer 0.5: Ambient Weather Tint Wash filling the whole round display
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0, -0.25),
                    radius: 1.15,
                    colors: [
                      themeColor.withValues(alpha: 0.15),
                      themeColor.withValues(alpha: 0.04),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.55, 1.0],
                  ),
                ),
              ),
            ),

            // Layer 1: Celestial Star Map & Constellation Geometry
            RepaintBoundary(
              child: CustomPaint(
                painter: CelestialConstellationPainter(
                  starColor: themeColor,
                ),
              ),
            ),

            // Layer 2: Perimeter Dotted Dial & Bezel Progression Arc
            RepaintBoundary(
              child: CustomPaint(
                painter: PerimeterDottedDialPainter(
                  progress: (min * 60 + _currentClockTime.second) / 3600.0,
                  themeColor: themeColor,
                ),
              ),
            ),

            // Layer 3: Generative Multi-Ribbon Silk Wave (Acoustic wireframe ribbon matching reference photo)
            RepaintBoundary(
              child: AnimatedBuilder(
                animation: _waveController,
                builder: (context, _) {
                  return CustomPaint(
                    painter: EtherealSilkRibbonPainter(
                      animationProgress: _waveController.value,
                      ribbonColor: themeColor,
                    ),
                  );
                },
              ),
            ),

            // Layer 4: Prominent Outdoor Weather & Date (Human-sized, easily readable across the room)
            Positioned(
              top: size * 0.155,
              left: 0,
              right: 0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Formatted Date - LARGER FOR HUMAN USE
                  Text(
                    dateStr.toUpperCase(),
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.88),
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2.8,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Big Weather Row (Tap to change city)
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: _showCitySelectionDialog,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(weatherIcon, color: themeColor, size: 40),
                        const SizedBox(width: 12),
                        Text(
                          tempStr,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 46,
                            fontWeight: FontWeight.w300,
                            letterSpacing: -1.0,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Container(
                          height: 32,
                          width: 1.5,
                          color: Colors.white.withValues(alpha: 0.25),
                        ),
                        const SizedBox(width: 14),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  _weatherCondition,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 19,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Icon(
                                  Icons.edit_location_alt_rounded,
                                  color: themeColor.withValues(alpha: 0.85),
                                  size: 16,
                                ),
                              ],
                            ),
                            const SizedBox(height: 1),
                            Text(
                              _weatherCity.isNotEmpty ? _weatherCity : 'Sheffield',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.65),
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.4,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Layer 5: Clean Swiss Center Chronometer (Crisp white digits + AM/PM) - Tap to Open Player
            Center(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _openPlayer,
                child: Padding(
                  padding: const EdgeInsets.only(top: 24),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text(
                        '$hourStr:$minStr',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 126,
                          fontWeight: FontWeight.w200,
                          letterSpacing: -2.5,
                          shadows: [
                            Shadow(color: Color(0x99000000), blurRadius: 20, offset: Offset(0, 4)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        amPmStr,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.90),
                          fontSize: 40,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.5,
                          shadows: const [
                            Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 3)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Layer 6: Large Human-Sized Touch Buttons (Safe inside bottom chord)
            Positioned(
              bottom: size * 0.12,
              left: 0,
              right: 0,
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Generously sized PLAYER button for human touch
                    TactileButton(
                      scaleFactor: 0.92,
                      onTap: _openPlayer,
                      child: Container(
                        height: 64,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              themeColor.withValues(alpha: 0.28),
                              const Color(0xEE0B182B),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(32),
                          border: Border.all(color: themeColor.withValues(alpha: 0.85), width: 2.0),
                          boxShadow: [
                            BoxShadow(
                              color: themeColor.withValues(alpha: 0.35),
                              blurRadius: 18,
                              spreadRadius: 1,
                              offset: const Offset(0, 4),
                            ),
                            const BoxShadow(
                              color: Colors.black87,
                              blurRadius: 14,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.play_arrow_rounded, color: themeColor, size: 30),
                            const SizedBox(width: 10),
                            const Text(
                              'PLAYER',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    // Generously sized CAMERA TEST button for human touch
                    TactileButton(
                      scaleFactor: 0.92,
                      onTap: () {
                        setState(() {
                          _previousMode = _currentMode;
                          _currentMode = PlinthMode.cameraVision;
                        });
                        _startVisionStream();
                      },
                      child: Container(
                        height: 64,
                        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0x3800E5FF),
                              Color(0xEE081F38),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(32),
                          border: Border.all(color: const Color(0xFF00E5FF).withValues(alpha: 0.90), width: 2.0),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF00E5FF).withValues(alpha: 0.35),
                              blurRadius: 18,
                              spreadRadius: 1,
                              offset: const Offset(0, 4),
                            ),
                            const BoxShadow(
                              color: Colors.black87,
                              blurRadius: 14,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.videocam_rounded, color: Color(0xFF00E5FF), size: 28),
                            SizedBox(width: 8),
                            Text(
                              'CAMERA TEST',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    // Generously sized SETTINGS button for human touch
                    TactileButton(
                      scaleFactor: 0.92,
                      onTap: () {
                        setState(() {
                          _previousMode = _currentMode;
                          _currentMode = PlinthMode.settingsMenu;
                        });
                      },
                      child: Container(
                        height: 64,
                        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0x35FFFFFF),
                              Color(0xEE111C2E),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(32),
                          border: Border.all(color: Colors.white.withValues(alpha: 0.45), width: 1.8),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black87,
                              blurRadius: 14,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.tune_rounded, color: Colors.white.withValues(alpha: 0.85), size: 26),
                            const SizedBox(width: 10),
                            Text(
                              'SETTINGS',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.85),
                                fontSize: 17,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
  }

  Widget _buildCameraVisionMode(double size) {
    return Container(
      width: size,
      height: size,
      color: const Color(0xFF02050B),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // LAYER 0: Video Stream Surface (OV9281 Monochrome Global Shutter Camera Feed)
          Positioned.fill(
            child: _latestVisionFrameBytes != null
                ? Image.memory(
                    _latestVisionFrameBytes!,
                    gaplessPlayback: true,
                    fit: BoxFit.cover,
                    width: size,
                    height: size,
                  )
                : Container(
                    color: const Color(0xFF030712),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                            width: 54,
                            height: 54,
                            child: CircularProgressIndicator(
                              strokeWidth: 3.0,
                              color: Color(0xFF00E5FF),
                            ),
                          ),
                          const SizedBox(height: 20),
                          const Text(
                            'CONNECTING TO OV9281...',
                            style: TextStyle(
                              color: Color(0xFF00E5FF),
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2.0,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'CAMERA PORT 1 • GLOBAL SHUTTER 120 FPS',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.6),
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),

          // LAYER 1: Futuristic Instrument Cluster Perimeter Vignette
          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 1.0,
                    colors: [
                      Colors.transparent,
                      Colors.transparent,
                      Color(0x33000000),
                      Color(0x99020612),
                      Color(0xEE010308),
                    ],
                    stops: [0.0, 0.62, 0.78, 0.90, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // LAYER 2: GPU-Accelerated Vector Reticles & 3D XYZ Ball Tags
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                size: Size(size, size),
                painter: CircularVisionHudPainter(
                  trackedBalls: _visionTrackedBalls,
                  colorMode: _visionColorMode,
                  animationVal: (_currentClockTime.second * 1000 + _currentClockTime.millisecond) / 60000.0,
                ),
              ),
            ),
          ),

          // LAYER 3: Top Telemetry Badge (Within Safe Upper Chord)
          Positioned(
            top: size * 0.08,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xD0081426),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFF00E5FF).withValues(alpha: 0.8), width: 1.5),
                  boxShadow: const [
                    BoxShadow(color: Color(0x66000000), blurRadius: 16, offset: Offset(0, 4)),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: const BoxDecoration(
                        color: Color(0xFF10B981),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: Color(0xFF10B981), blurRadius: 8, spreadRadius: 2),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'OV9281 PORT 1  •  GLOBAL SHUTTER',
                      style: TextStyle(
                        color: Color(0xFF00E5FF),
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(height: 14, width: 1, color: Colors.white24),
                    const SizedBox(width: 12),
                    Text(
                      '${_visionFps.toStringAsFixed(1)} FPS',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // LAYER 4: Left Chord Telemetry Card
          Positioned(
            left: size * 0.08,
            top: size * 0.38,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xCC050E1C),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withValues(alpha: 0.25), width: 1.2),
                boxShadow: const [
                  BoxShadow(color: Colors.black87, blurRadius: 14),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('CAMERA TELEMETRY', style: TextStyle(color: Color(0xFF00E5FF), fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.0)),
                  const SizedBox(height: 6),
                  Text('EXP: ${_visionExposureUs}µs', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text('LAT: ${_visionLatencyMs.toStringAsFixed(1)}ms', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  const Text('BALL: Ø 40.0mm', style: TextStyle(color: Color(0xFFFBBF24), fontSize: 13, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),

          // LAYER 5: Right Chord Telemetry Card
          Positioned(
            right: size * 0.08,
            top: size * 0.38,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xCC050E1C),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withValues(alpha: 0.25), width: 1.2),
                boxShadow: const [
                  BoxShadow(color: Colors.black87, blurRadius: 14),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('BALL TRACKER', style: TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.0)),
                  const SizedBox(height: 6),
                  Text('BALLS: ${_visionTrackedBalls.length}', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  const Text('POSE: 3D (XYZ mm)', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  const Text('RESTITUTION: 0.88', style: TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500)),
                ],
              ),
            ),
          ),

          // LAYER 6: Bottom Control Cluster (Safe Lower Chord)
          Positioned(
            bottom: size * 0.10,
            left: 0,
            right: 0,
            child: Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Prominent CLOSE FEED Button
                  TactileButton(
                    scaleFactor: 0.92,
                    onTap: () {
                      setState(() {
                        _currentMode = PlinthMode.centerpiece;
                      });
                      _stopVisionStream();
                    },
                    child: Container(
                      height: 58,
                      padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Color(0x35EF4444),
                            Color(0xEE1E0B0B),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: const Color(0xFFEF4444).withValues(alpha: 0.85), width: 2.0),
                        boxShadow: const [
                          BoxShadow(color: Color(0x44EF4444), blurRadius: 16, offset: Offset(0, 4)),
                          BoxShadow(color: Colors.black87, blurRadius: 12),
                        ],
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.close_rounded, color: Color(0xFFEF4444), size: 26),
                          SizedBox(width: 8),
                          Text(
                            'CLOSE FEED',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),

                  // THEME / COLOR MODE TOGGLE
                  TactileButton(
                    scaleFactor: 0.92,
                    onTap: _toggleVisionColorMode,
                    child: Container(
                      height: 58,
                      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Color(0x3000E5FF),
                            Color(0xEE0A1828),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: const Color(0xFF00E5FF).withValues(alpha: 0.75), width: 1.8),
                        boxShadow: const [
                          BoxShadow(color: Colors.black87, blurRadius: 12),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.palette_rounded, color: Color(0xFF00E5FF), size: 24),
                          const SizedBox(width: 8),
                          Text(
                            _visionColorMode.toUpperCase(),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildSettingsDeck(double size) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFA050912),
        gradient: RadialGradient(
          center: Alignment.center,
          radius: 1.0,
          colors: [
            Color(0xFF0C1629),
            Color(0xFA050912),
            Colors.black,
          ],
          stops: [0.0, 0.65, 1.0],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Header: Safely centered within circular display chord
          Positioned(
            top: size * 0.145,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 480,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: const [
                        Icon(Icons.tune_rounded, color: Color(0xFF00E5FF), size: 20),
                        SizedBox(width: 10),
                        Text(
                          'SYSTEM SETTINGS',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 2.2,
                          ),
                        ),
                      ],
                    ),
                    TactileButton(
                      scaleFactor: 0.88,
                      minWidth: 48,
                      minHeight: 48,
                      onTap: () {
                        setState(() {
                          _currentMode = _previousMode;
                        });
                      },
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0x33FFFFFF),
                          border: Border.all(color: const Color(0x66FFFFFF), width: 1.2),
                          boxShadow: const [
                            BoxShadow(color: Colors.black54, blurRadius: 6),
                          ],
                        ),
                        child: const Icon(Icons.close_rounded, color: Colors.white, size: 20),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Tab Bar: Centered within circular display chord
          Positioned(
            top: size * 0.22,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 500,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildSettingsTabIcon(0, Icons.palette_rounded, 'Display'),
                      const SizedBox(width: 8),
                      _buildSettingsTabIcon(1, Icons.precision_manufacturing_rounded, 'Kinematics'),
                      const SizedBox(width: 8),
                      _buildSettingsTabIcon(2, Icons.volume_up_rounded, 'Audio'),
                      const SizedBox(width: 8),
                      _buildSettingsTabIcon(3, Icons.qr_code_2_rounded, 'Pairing'),
                      const SizedBox(width: 8),
                      _buildSettingsTabIcon(4, Icons.dns_rounded, 'System'),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // Content Area: Centered safely above bottom bezel
          Positioned(
            top: size * 0.31,
            bottom: size * 0.16,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 510,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xE608101E),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0x3860A5FA), width: 1.4),
                    boxShadow: const [
                      BoxShadow(color: Colors.black87, blurRadius: 20, offset: Offset(0, 6)),
                      BoxShadow(color: Color(0x1A00E5FF), blurRadius: 16),
                    ],
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                  child: _buildSettingsTabContent(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsTabIcon(int index, IconData icon, String label) {
    final isSelected = _settingsTab == index;
    return TactileButton(
      scaleFactor: 0.92,
      onTap: () {
        setState(() => _settingsTab = index);
        if (index == 2) _loadAudioSettings();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0x3300E5FF) : const Color(0x18FFFFFF),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? const Color(0xFF00E5FF) : const Color(0x28FFFFFF),
            width: isSelected ? 1.4 : 1.0,
          ),
          boxShadow: isSelected
              ? [
                  const BoxShadow(color: Color(0x3300E5FF), blurRadius: 10),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? const Color(0xFF00E5FF) : Colors.white70,
              size: 16,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.white70,
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsTabContent() {
    switch (_settingsTab) {
      case 0:
        return _buildDisplaySettingsTab();
      case 1:
        return _buildKinematicsSettingsTab();
      case 2:
        return _buildAudioSettingsTab();
      case 3:
        return _buildPairingSettingsTab();
      case 4:
        return _buildSystemSettingsTab();
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildDisplaySettingsTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.light_mode_rounded, color: Color(0xFF00E5FF), size: 16),
              SizedBox(width: 8),
              Text(
                'AMBIENT AURA BRIGHTNESS',
                style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: const Color(0xFF00E5FF),
                    inactiveTrackColor: const Color(0x33FFFFFF),
                    thumbColor: const Color(0xFF00E5FF),
                    overlayColor: const Color(0x3300E5FF),
                    trackHeight: 4,
                  ),
                  child: Slider(
                    value: _ambientBrightness,
                    min: 0.2,
                    max: 1.0,
                    onChanged: (v) {
                      setState(() => _ambientBrightness = v);
                      _saveSettings({'ambient_brightness': v});
                    },
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0x2200E5FF),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0x4400E5FF)),
                ),
                child: Text(
                  '${(_ambientBrightness * 100).toInt()}%',
                  style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: const [
              Icon(Icons.bedtime_rounded, color: Color(0xFF67E8F9), size: 16),
              SizedBox(width: 8),
              Text(
                'IDLE SLEEP TIMEOUT',
                style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [30, 60, 120, 300, 0].map((sec) {
              final label = sec == 0 ? 'Never' : '${sec}s';
              final isSelected = _idleTimeoutSeconds == sec;
              return TactileButton(
                scaleFactor: 0.92,
                onTap: () {
                  setState(() => _idleTimeoutSeconds = sec);
                  _saveSettings({'idle_timeout_seconds': sec});
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSelected ? const Color(0xFF00E5FF) : const Color(0x18FFFFFF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isSelected ? const Color(0xFF00E5FF) : const Color(0x33FFFFFF),
                      width: isSelected ? 1.4 : 1.0,
                    ),
                    boxShadow: isSelected
                        ? [const BoxShadow(color: Color(0x4400E5FF), blurRadius: 8)]
                        : null,
                  ),
                  child: Text(
                    label,
                    style: TextStyle(
                      color: isSelected ? Colors.black : Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildKinematicsSettingsTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: AnimatedBuilder(
        animation: Listenable.merge([_pitchNotifier, _rollNotifier, _apexHeightNotifier, _ballStateNotifier]),
        builder: (cardContext, child) {
          return Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildTelemetryCard('PITCH', '${_pitchNotifier.value.toStringAsFixed(1)}°', Icons.screen_rotation_rounded),
                  _buildTelemetryCard('ROLL', '${_rollNotifier.value.toStringAsFixed(1)}°', Icons.sync_alt_rounded),
                  _buildTelemetryCard('APEX', '${_apexHeightNotifier.value.toStringAsFixed(0)} mm', Icons.vertical_align_top_rounded),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0x1AFFFFFF),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0x33FFFFFF)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: const [
                        Icon(Icons.sports_baseball_rounded, color: Color(0xFF67E8F9), size: 16),
                        SizedBox(width: 8),
                        Text('BALL STATE', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.2)),
                      ],
                    ),
                    Text(
                      _ballStateNotifier.value.toUpperCase(),
                      style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              TactileButton(
                scaleFactor: 0.94,
                onTap: () async {
                  try {
                    await http.post(
                      Uri.parse('http://127.0.0.1:8000/api/control'),
                      headers: {'Content-Type': 'application/json'},
                      body: jsonEncode({'action': 'calibrate'}),
                    );
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Kinematics calibrated & homed'), duration: Duration(seconds: 2)),
                    );
                  } catch (_) {}
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 24),
                  decoration: BoxDecoration(
                    color: const Color(0x3300E5FF),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF00E5FF), width: 1.4),
                    boxShadow: const [
                      BoxShadow(color: Color(0x2200E5FF), blurRadius: 10),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.center_focus_strong_rounded, color: Color(0xFF00E5FF), size: 16),
                      SizedBox(width: 8),
                      Text(
                        'ZERO KINEMATICS & HOMING',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.5),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildTelemetryCard(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0x1EFFFFFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0x28FFFFFF)),
      ),
      child: Column(
        children: [
          Icon(icon, color: Colors.white60, size: 14),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 9, letterSpacing: 1.2)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 13, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildAudioSettingsTab() {
    final activeFilter = _audioSettings['filter']?.toString() ?? 'ringless';
    final analogGain = _audioSettings['analog-gain']?.toString() ?? '0';
    final analogBoost = _audioSettings['boost']?.toString() ?? 'off';
    final balanceVal = double.tryParse(_audioSettings['balance']?.toString() ?? '0') ?? 0.0;
    final channels = _audioSettings['channels']?.toString() ?? 'stereo';
    final ramp = _audioSettings['ramp']?.toString() ?? '1/0.5dB';
    final autoMute = _audioSettings['auto-mute']?.toString() ?? 'off';
    final deemphasis = _audioSettings['deemphasis']?.toString() ?? 'off';
    final muteState = _audioSettings['mute']?.toString() ?? 'unmuted';
    final hires = _audioSettings['pw-hires']?.toString() ?? 'on';
    final resampleQ = _audioSettings['pw-resample-quality']?.toString() ?? '14';
    final keepAwake = _audioSettings['pw-keep-awake']?.toString() ?? 'on';
    final dither = _audioSettings['pw-dither']?.toString() ?? 'none';
    final dacPll = _liveDacReadback['PLL']?.toString().toUpperCase() ?? 'LOCKED';
    final dacState = _liveDacReadback['state']?.toString().toUpperCase() ?? 'PLAYING';

    String balanceLabel;
    if (balanceVal.abs() < 0.1) {
      balanceLabel = 'Center (0.0 dB)';
    } else if (balanceVal < 0) {
      balanceLabel = 'L ${(-balanceVal).toStringAsFixed(1)} dB';
    } else {
      balanceLabel = 'R ${balanceVal.toStringAsFixed(1)} dB';
    }

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // DAC Status Badge Card
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0x3310B981), Color(0x1800E5FF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0x5510B981), width: 1.2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: Color(0xFF10B981),
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Color(0xFF10B981), blurRadius: 6)],
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'TI PCM5122 DAC PRO',
                      style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2),
                    ),
                  ],
                ),
                Text(
                  '32-BIT · $dacState · PLL $dacPll',
                  style: const TextStyle(color: Color(0xFF34D399), fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // Feedback Banner if any
          if (_audioSettingsFeedback != null) ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0x3300E5FF),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF00E5FF)),
              ),
              child: Text(
                _audioSettingsFeedback!,
                style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 10, fontWeight: FontWeight.w600),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 10),
          ],

          // Action Buttons: Audiophile Profile & Reset Defaults
          Row(
            children: [
              Expanded(
                flex: 3,
                child: TactileButton(
                  scaleFactor: 0.94,
                  onTap: _applyBestQualityPreset,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0x44F59E0B), Color(0x22F59E0B)],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFF59E0B), width: 1.2),
                      boxShadow: const [BoxShadow(color: Color(0x33F59E0B), blurRadius: 8)],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.auto_awesome_rounded, color: Color(0xFFFBBF24), size: 14),
                        SizedBox(width: 6),
                        Text(
                          'AUDIOPHILE PROFILE',
                          style: TextStyle(color: Color(0xFFFDE68A), fontSize: 9.5, fontWeight: FontWeight.bold, letterSpacing: 0.8),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: TactileButton(
                  scaleFactor: 0.94,
                  onTap: _resetAudioSettings,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 10),
                    decoration: BoxDecoration(
                      color: const Color(0x18FFFFFF),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0x44FFFFFF), width: 1.0),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.restart_alt_rounded, color: Colors.white70, size: 14),
                        SizedBox(width: 5),
                        Text(
                          'DEFAULTS',
                          style: TextStyle(color: Colors.white70, fontSize: 9.5, fontWeight: FontWeight.w600, letterSpacing: 0.8),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // 1. Interpolation Filter Selector (5 filters)
          const Text(
            'INTERPOLATION FILTER (DAC SOUND CHARACTER)',
            style: TextStyle(color: Colors.white70, fontSize: 9.5, fontWeight: FontWeight.bold, letterSpacing: 1.1),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _buildAudioOptionChip('filter', 'ringless', 'Ringless (Warm)', activeFilter),
              const SizedBox(width: 6),
              _buildAudioOptionChip('filter', 'fir', 'FIR (Sharp)', activeFilter),
              const SizedBox(width: 6),
              _buildAudioOptionChip('filter', 'iir', 'IIR (Low-Lat)', activeFilter),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _buildAudioOptionChip('filter', 'high-atten', 'High-Atten (Pure)', activeFilter),
              const SizedBox(width: 6),
              _buildAudioOptionChip('filter', 'fixed', 'Fixed Filter', activeFilter),
            ],
          ),
          const SizedBox(height: 14),

          // 2. Analog Stage (Gain & Boost)
          Row(
            children: [
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('ANALOG GAIN', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('analog-gain', '0', '0 dB (2V)', analogGain),
                        const SizedBox(width: 6),
                        _buildAudioOptionChip('analog-gain', '-6', '-6 dB (1V)', analogGain),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('ANALOG BOOST', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('boost', 'off', 'Off', analogBoost),
                        const SizedBox(width: 6),
                        _buildAudioOptionChip('boost', 'on', '+0.8 dB', analogBoost),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // 3. Stereo Balance Slider (-12 dB to +12 dB)
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'STEREO BALANCE',
                style: TextStyle(color: Colors.white70, fontSize: 9.5, fontWeight: FontWeight.bold, letterSpacing: 1.1),
              ),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _updateAudioSetting('balance', 0),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0x2200E5FF),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: const Color(0x4400E5FF)),
                  ),
                  child: Text(
                    balanceLabel,
                    style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 9.5, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: const Color(0xFF00E5FF),
              inactiveTrackColor: const Color(0x33FFFFFF),
              thumbColor: const Color(0xFF00E5FF),
              trackHeight: 3,
            ),
            child: Slider(
              value: balanceVal.clamp(-12.0, 12.0),
              min: -12.0,
              max: 12.0,
              divisions: 24,
              onChanged: (v) {
                setState(() => _audioSettings['balance'] = v.round());
              },
              onChangeEnd: (v) => _updateAudioSetting('balance', v.round()),
            ),
          ),
          const SizedBox(height: 10),

          // 4. Channel Routing
          const Text(
            'CHANNEL ROUTING',
            style: TextStyle(color: Colors.white70, fontSize: 9.5, fontWeight: FontWeight.bold, letterSpacing: 1.1),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _buildAudioOptionChip('channels', 'stereo', 'Stereo', channels),
              const SizedBox(width: 5),
              _buildAudioOptionChip('channels', 'swap', 'Swap L/R', channels),
              const SizedBox(width: 5),
              _buildAudioOptionChip('channels', 'mono-left', 'Mono L', channels),
              const SizedBox(width: 5),
              _buildAudioOptionChip('channels', 'mono-right', 'Mono R', channels),
            ],
          ),
          const SizedBox(height: 14),

          // 5. Volume Ramp & Auto-Mute Gate Row
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('VOLUME RAMP', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('ramp', '1/0.5dB', 'Smooth', ramp),
                        const SizedBox(width: 5),
                        _buildAudioOptionChip('ramp', '1/1dB', '1dB', ramp),
                        const SizedBox(width: 5),
                        _buildAudioOptionChip('ramp', 'instant', 'Fast', ramp),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('AUTO-MUTE GATE', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('auto-mute', 'off', 'Off', autoMute),
                        const SizedBox(width: 5),
                        _buildAudioOptionChip('auto-mute', '106ms', '106ms', autoMute),
                        const SizedBox(width: 5),
                        _buildAudioOptionChip('auto-mute', '1.07s', '1.07s', autoMute),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // 6. CD De-emphasis & Soft Mute
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('CD DE-EMPHASIS', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('deemphasis', 'off', 'Off', deemphasis),
                        const SizedBox(width: 6),
                        _buildAudioOptionChip('deemphasis', 'on', 'On (50/15µs)', deemphasis),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('OUTPUT MUTE', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('mute', 'unmuted', 'Live Output', muteState),
                        const SizedBox(width: 6),
                        _buildAudioOptionChip('mute', 'muted', 'Soft Mute', muteState),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // 7. PipeWire 32-bit Hi-Res & Resample Quality
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('PIPEWIRE HI-RES', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('pw-hires', 'on', '32b/192k', hires),
                        const SizedBox(width: 6),
                        _buildAudioOptionChip('pw-hires', 'off', '16b/48k', hires),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('PW KEEP-AWAKE', style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _buildAudioOptionChip('pw-keep-awake', 'on', 'Active (0 Pop)', keepAwake),
                        const SizedBox(width: 6),
                        _buildAudioOptionChip('pw-keep-awake', 'off', 'Suspend', keepAwake),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // 8. Resample Quality (4 tiers)
          const Text(
            'PIPEWIRE RESAMPLE QUALITY (44.1k -> 48k/96k/192k)',
            style: TextStyle(color: Colors.white70, fontSize: 9.5, fontWeight: FontWeight.bold, letterSpacing: 1.1),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _buildAudioOptionChip('pw-resample-quality', '4', '4 (Fast)', resampleQ),
              const SizedBox(width: 5),
              _buildAudioOptionChip('pw-resample-quality', '10', '10 (Transp)', resampleQ),
              const SizedBox(width: 5),
              _buildAudioOptionChip('pw-resample-quality', '12', '12 (Ultra)', resampleQ),
              const SizedBox(width: 5),
              _buildAudioOptionChip('pw-resample-quality', '14', '14 (Max Audiophile)', resampleQ),
            ],
          ),
          const SizedBox(height: 14),

          // 9. PipeWire Dithering
          const Text(
            'PIPEWIRE DITHERING',
            style: TextStyle(color: Colors.white70, fontSize: 9.5, fontWeight: FontWeight.bold, letterSpacing: 1.1),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _buildAudioOptionChip('pw-dither', 'none', 'None (32-bit Native)', dither),
              const SizedBox(width: 5),
              _buildAudioOptionChip('pw-dither', 'triangular-hf', 'Tri-HF', dither),
              const SizedBox(width: 5),
              _buildAudioOptionChip('pw-dither', 'lipshitz5', 'Lipshitz5', dither),
              const SizedBox(width: 5),
              _buildAudioOptionChip('pw-dither', 'wannamaker3', 'Wann3', dither),
            ],
          ),
          const SizedBox(height: 16),

          // Master Hardware Volume Slider
          Row(
            children: const [
              Icon(Icons.volume_up_rounded, color: Color(0xFF00E5FF), size: 16),
              SizedBox(width: 8),
              Text(
                'HARDWARE DAC VOLUME (LOSSLESS 32-BIT)',
                style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1.2),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Expanded(
                child: SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    activeTrackColor: const Color(0xFF00E5FF),
                    inactiveTrackColor: const Color(0x33FFFFFF),
                    thumbColor: const Color(0xFF00E5FF),
                    trackHeight: 4,
                  ),
                  child: Slider(
                    value: _volumeNotifier.value,
                    min: 0.0,
                    max: 100.0,
                    onChanged: (v) => _setVolume(v),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0x2200E5FF),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0x4400E5FF)),
                ),
                child: Text(
                  '${_volumeNotifier.value.toInt()}%',
                  style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 11, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Status Footer
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0x11FFFFFF),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0x22FFFFFF)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text('CONFIG PERSISTENCE', style: TextStyle(color: Colors.white54, fontSize: 9, letterSpacing: 1.0)),
                Text('/etc/ventudac.json (Survives Reboot)', style: TextStyle(color: Color(0xFF00E5FF), fontSize: 9, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAudioOptionChip(String key, String value, String label, String active, {int flex = 1, double fontSize = 9.0}) {
    final isSelected = active.toLowerCase() == value.toLowerCase();
    return Expanded(
      flex: flex,
      child: TactileButton(
        scaleFactor: 0.92,
        onTap: () => _updateAudioSetting(key, value),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
          decoration: BoxDecoration(
            color: isSelected ? const Color(0x3300E5FF) : const Color(0x18FFFFFF),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isSelected ? const Color(0xFF00E5FF) : const Color(0x28FFFFFF),
              width: isSelected ? 1.4 : 1.0,
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: isSelected ? const Color(0xFF00E5FF) : Colors.white70,
              fontSize: fontSize,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPairingSettingsTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [
                BoxShadow(color: Color(0x6600E5FF), blurRadius: 16),
              ],
            ),
            child: Image.network(
              'http://127.0.0.1:8000/api/system/qr.png',
              width: 130,
              height: 130,
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) => const SizedBox(
                width: 130,
                height: 130,
                child: Center(child: Text('QR Offline', style: TextStyle(color: Colors.black, fontSize: 12))),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.qr_code_scanner_rounded, color: Color(0xFF00E5FF), size: 16),
              SizedBox(width: 6),
              Text(
                'SCAN TO PAIR PHONE REMOTE',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1.5),
              ),
            ],
          ),
          const SizedBox(height: 4),
          const Text(
            'Point iPhone or Android camera to control songs & kinematics',
            style: TextStyle(color: Colors.white60, fontSize: 10),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0x22FFFFFF),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0x33FFFFFF)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.link_rounded, color: Color(0xFF93C5FD), size: 14),
                SizedBox(width: 6),
                Text(
                  'http://192.168.0.214:8080',
                  style: TextStyle(color: Color(0xFF93C5FD), fontFamily: 'monospace', fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSystemSettingsTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TactileButton(
                scaleFactor: 0.94,
                onTap: () async {
                  try {
                    await http.post(Uri.parse('http://127.0.0.1:8000/api/search/history/clear'));
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Search history cleared'), duration: Duration(seconds: 2)),
                    );
                  } catch (_) {}
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                  decoration: BoxDecoration(
                    color: const Color(0x33F59E0B),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFF59E0B), width: 1.2),
                    boxShadow: const [
                      BoxShadow(color: Color(0x22F59E0B), blurRadius: 8),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.history_toggle_off_rounded, color: Colors.white, size: 16),
                      SizedBox(width: 6),
                      Text(
                        'CLEAR HISTORY',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 0.8),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              TactileButton(
                scaleFactor: 0.94,
                onTap: () async {
                  try {
                    await http.post(Uri.parse('http://127.0.0.1:8000/api/cache/clear'));
                    _loadCachedTracks();
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Music cache cleared'), duration: Duration(seconds: 2)),
                    );
                  } catch (_) {}
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
                  decoration: BoxDecoration(
                    color: const Color(0x33EF4444),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFEF4444), width: 1.2),
                    boxShadow: const [
                      BoxShadow(color: Color(0x22EF4444), blurRadius: 8),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.delete_sweep_rounded, color: Colors.white, size: 16),
                      SizedBox(width: 6),
                      Text(
                        'CLEAR CACHED MUSIC',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 0.8),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TactileButton(
            scaleFactor: 0.94,
            onTap: () async {
              try {
                await http.post(Uri.parse('http://127.0.0.1:8000/api/system/restart-services'));
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Services restarting in background...'), duration: Duration(seconds: 2)),
                );
              } catch (_) {}
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
              decoration: BoxDecoration(
                color: const Color(0x333B82F6),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF3B82F6), width: 1.2),
                boxShadow: const [
                  BoxShadow(color: Color(0x223B82F6), blurRadius: 8),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.restart_alt_rounded, color: Colors.white, size: 16),
                  SizedBox(width: 6),
                  Text(
                    'RESTART SERVICES',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.0),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.memory_rounded, color: Colors.white38, size: 12),
              SizedBox(width: 6),
              Text(
                'Arduino Ventuno Q (Dragonwing MPU)\nLinux DRM-KMS Wayland Kiosk Active',
                style: TextStyle(color: Colors.white60, fontSize: 10, height: 1.4),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- HI-FI LOSSLESS AUDIO & GOOGLE DRIVE BROWSER METHODS ---

  Future<void> _loadHiFiTree({bool force = false}) async {
    setState(() => _isLoadingHiFiTree = true);
    try {
      if (force) {
        try {
          http.post(
            Uri.parse('http://127.0.0.1:8000/api/hifi/sync_drive'),
            headers: {'Content-Type': 'application/json'},
            body: '{}',
          ).timeout(const Duration(seconds: 4)).then((_) {}).catchError((_) {});
        } catch (_) {}
      }
      final url = 'http://127.0.0.1:8000/api/hifi/tree';
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 6));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final artists = (data['artists'] as List? ?? []).cast<Map<String, dynamic>>();
        final List<Map<String, dynamic>> flatTracks = [];
        for (final artist in artists) {
          final artistName = artist['name']?.toString() ?? 'Unknown Artist';
          final albums = (artist['albums'] as List? ?? []).cast<Map<String, dynamic>>();
          for (final album in albums) {
            final albumName = album['name']?.toString() ?? 'Unknown Album';
            final tracks = (album['tracks'] as List? ?? []).cast<Map<String, dynamic>>();
            for (final track in tracks) {
              flatTracks.add({
                'track_id': track['track_id']?.toString() ?? '',
                'title': track['title']?.toString() ?? 'Unknown Track',
                'artist': artistName,
                'album': albumName,
                'format': track['format']?.toString() ?? 'FLAC',
                'duration_seconds': track['duration_seconds'] ?? 0,
                'cover_key': '${artistName}_$albumName',
              });
            }
          }
        }
        setState(() {
          _hifiTree = data;
          _hifiArtistList = artists;
          _hifiFlatTrackIndex = flatTracks;
          _isLoadingHiFiTree = false;
        });
        _loadHiFiPlaylists();
      } else {
        setState(() => _isLoadingHiFiTree = false);
      }
    } catch (_) {
      setState(() => _isLoadingHiFiTree = false);
    }
  }

  Future<void> _loadHiFiPlaylists() async {
    setState(() => _isLoadingPlaylists = true);
    try {
      final res = await http.get(Uri.parse('http://127.0.0.1:8000/api/hifi/playlists')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final list = (data['playlists'] as List? ?? []).cast<Map<String, dynamic>>();
        setState(() {
          _hifiPlaylists = list;
          _isLoadingPlaylists = false;
        });
        return;
      }
    } catch (_) {}
    setState(() => _isLoadingPlaylists = false);
  }

  Future<void> _loadPlaylistDetail(String playlistId, String name) async {
    setState(() {
      _isLoadingPlaylists = true;
      _hifiSelectedPlaylistId = playlistId;
      _hifiSelectedPlaylistName = name;
    });
    try {
      final res = await http.get(Uri.parse('http://127.0.0.1:8000/api/hifi/playlists/$playlistId')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final tracks = (data['tracks'] as List? ?? []).cast<Map<String, dynamic>>();
        setState(() {
          _hifiPlaylistTracks = tracks;
          _isLoadingPlaylists = false;
        });
        return;
      }
    } catch (_) {}
    setState(() => _isLoadingPlaylists = false);
  }

  Future<void> _playPlaylist(String playlistId, {bool shuffle = false}) async {
    try {
      final res = await http.post(
        Uri.parse('http://127.0.0.1:8000/api/hifi/playlists/$playlistId/play'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'shuffle': shuffle}),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final trackId = data['track_id']?.toString() ?? '';
        final cleanId = trackId.replaceFirst('hifi_', '');
        
        final plRes = await http.get(Uri.parse('http://127.0.0.1:8000/api/hifi/playlists/$playlistId'));
        if (plRes.statusCode == 200) {
          final plData = jsonDecode(plRes.body);
          final tracks = (plData['tracks'] as List? ?? []).cast<Map<String, dynamic>>();
          setState(() {
            _currentHiFiPlaylist = tracks;
            _currentHiFiTrackIndex = tracks.indexWhere((t) => (t['track_id']?.toString() ?? '') == cleanId);
            if (_currentHiFiTrackIndex < 0) _currentHiFiTrackIndex = 0;
            _isHiFi = true;
            _isHiFiBrowserOpen = false;
            _currentMode = PlinthMode.audiophileDeck;
          });
        }
        _fetchBeatsAndColor('hifi_$cleanId');
      }
    } catch (e) {
      debugPrint('[Play Playlist Error] $e');
    }
  }

  Future<void> _playSmartMix(String mixType, {String? artist}) async {
    try {
      String url = 'http://127.0.0.1:8000/api/hifi/smart_playlist?type=$mixType&limit=50';
      if (artist != null) {
        url += '&artist=${Uri.encodeComponent(artist)}';
      }
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 6));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final tracks = (data['tracks'] as List? ?? []).cast<Map<String, dynamic>>();
        if (tracks.isNotEmpty) {
          final first = tracks.first;
          final firstId = first['track_id']?.toString() ?? first['id']?.toString() ?? '';
          setState(() {
            _currentHiFiPlaylist = List.from(tracks);
            _currentHiFiTrackIndex = 0;
            _isHiFiBrowserOpen = false;
          });
          await _playHiFiTrack(firstId, playlist: tracks, index: 0);
        }
      }
    } catch (e) {
      debugPrint('[Smart Mix Error] $e');
    }
  }

  Future<void> _addToQueue(Map<String, dynamic> track, {String position = 'end'}) async {
    try {
      final tid = track['track_id']?.toString() ?? track['id']?.toString() ?? '';
      final title = track['title']?.toString() ?? 'Hi-Fi Track';
      final artist = track['artist']?.toString() ?? '';
      final album = track['album']?.toString() ?? '';
      final coverKey = track['cover_key']?.toString() ?? track['key']?.toString() ?? '';
      
      await http.post(
        Uri.parse('http://127.0.0.1:8000/api/queue/add'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'video_id': 'hifi_$tid',
          'title': title,
          'artist': artist,
          'album': album,
          'source': 'hifi',
          'position': position,
          'cover_key': coverKey,
        }),
      );
    } catch (_) {}
  }

  Future<bool> _toggleFavorite(Map<String, dynamic> track) async {
    try {
      final res = await http.post(
        Uri.parse('http://127.0.0.1:8000/api/hifi/favorites/toggle'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'track': track}),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        _loadHiFiPlaylists();
        return data['is_favorite'] == true;
      }
    } catch (_) {}
    return false;
  }

  void _showTrackActionSheet(Map<String, dynamic> track) {
    final title = track['title']?.toString() ?? 'Unknown Track';
    final artist = track['artist']?.toString() ?? '';
    final album = track['album']?.toString() ?? '';
    final trackId = track['track_id']?.toString() ?? track['id']?.toString() ?? '';
    final fmt = track['format']?.toString() ?? 'FLAC';
    final bits = (track['bit_depth'] as num?)?.toInt() ?? 16;
    final sampleRate = (track['sample_rate_hz'] as num?)?.toInt() ?? 44100;
    final khz = (sampleRate / 1000).toStringAsFixed(1);

    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 40, vertical: 30),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 480),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xF80B101D),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: const Color(0xFFF59E0B), width: 1.8),
            boxShadow: const [
              BoxShadow(color: Color(0x66F59E0B), blurRadius: 32, spreadRadius: 2),
              BoxShadow(color: Colors.black, blurRadius: 40),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: const Color(0x33F59E0B),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0x88F59E0B), width: 1.5),
                    ),
                    child: const Icon(Icons.music_note_rounded, color: Color(0xFFFBBF24), size: 30),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          '$artist • $album',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Color(0xBBFFFFFF), fontSize: 13, fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0x33F59E0B),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: const Color(0x88F59E0B), width: 1),
                          ),
                          child: Text(
                            '$bits-BIT / ${khz}kHz $fmt LOSSLESS',
                            style: const TextStyle(color: Color(0xFFFBBF24), fontSize: 10, fontWeight: FontWeight.w800),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Divider(color: Color(0x33FFFFFF), height: 1),
              const SizedBox(height: 16),

              _buildActionSheetButton(
                icon: Icons.play_arrow_rounded,
                label: 'PLAY NOW',
                color: const Color(0xFFF59E0B),
                textColor: Colors.black,
                onTap: () {
                  Navigator.of(ctx).pop();
                  final pl = _hifiTrackList.isNotEmpty
                      ? _hifiTrackList
                      : (_currentHiFiPlaylist.isNotEmpty ? _currentHiFiPlaylist : _hifiFlatTrackIndex);
                  final idx = pl.indexWhere((t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == trackId);
                  _playHiFiTrack(trackId, playlist: pl, index: idx >= 0 ? idx : 0);
                },
              ),
              const SizedBox(height: 10),

              _buildActionSheetButton(
                icon: Icons.playlist_play_rounded,
                label: 'PLAY NEXT IN QUEUE',
                color: const Color(0x2600E5FF),
                borderColor: const Color(0xFF00E5FF),
                textColor: const Color(0xFF67E8F9),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _addToQueue(track, position: 'next');
                },
              ),
              const SizedBox(height: 10),

              _buildActionSheetButton(
                icon: Icons.queue_music_rounded,
                label: 'ADD TO END OF QUEUE',
                color: const Color(0x2610B981),
                borderColor: const Color(0xFF10B981),
                textColor: const Color(0xFF34D399),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _addToQueue(track, position: 'end');
                },
              ),
              const SizedBox(height: 10),

              _buildActionSheetButton(
                icon: Icons.favorite_rounded,
                label: 'TOGGLE FAVORITE ❤️',
                color: const Color(0x26EC4899),
                borderColor: const Color(0xFFEC4899),
                textColor: const Color(0xFFF472B6),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _toggleFavorite(track);
                },
              ),
              const SizedBox(height: 14),

              TactileButton(
                scaleFactor: 0.96,
                onTap: () => Navigator.of(ctx).pop(),
                child: Container(
                  height: 50,
                  width: double.infinity,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: const Color(0x1AFFFFFF),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Text('CANCEL', style: TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionSheetButton({
    required IconData icon,
    required String label,
    required Color color,
    Color? borderColor,
    required Color textColor,
    required VoidCallback onTap,
  }) {
    return TactileButton(
      scaleFactor: 0.96,
      onTap: onTap,
      child: Container(
        height: 56,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: borderColor ?? color, width: 1.5),
        ),
        child: Row(
          children: [
            Icon(icon, size: 24, color: textColor),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: TextStyle(color: textColor, fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 0.6),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _playHiFiTrack(String trackId, {List<Map<String, dynamic>>? playlist, int? index}) async {
    try {
      final cleanId = trackId.replaceFirst('hifi_', '');
      if (playlist != null && playlist.length > 1) {
        _currentHiFiPlaylist = List.from(playlist);
        _currentHiFiTrackIndex = index ?? playlist.indexWhere((t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == cleanId);
        if (_currentHiFiTrackIndex < 0) _currentHiFiTrackIndex = 0;
      } else if (_currentHiFiPlaylist.isEmpty || _currentHiFiPlaylist.length <= 1) {
        if (_hifiTrackList.length > 1 && _hifiTrackList.any((t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == cleanId)) {
          _currentHiFiPlaylist = List.from(_hifiTrackList);
          _currentHiFiTrackIndex = _currentHiFiPlaylist.indexWhere((t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == cleanId);
          if (_currentHiFiTrackIndex < 0) _currentHiFiTrackIndex = 0;
        } else if (_hifiFlatTrackIndex.isNotEmpty) {
          _currentHiFiPlaylist = List.from(_hifiFlatTrackIndex);
          _currentHiFiTrackIndex = _currentHiFiPlaylist.indexWhere((t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == cleanId);
          if (_currentHiFiTrackIndex < 0) _currentHiFiTrackIndex = 0;
        }
      }

      // Optimistic instant UI update
      final pool = _currentHiFiPlaylist.isNotEmpty ? _currentHiFiPlaylist : _hifiFlatTrackIndex;
      final match = pool.firstWhere(
        (t) => (t['track_id']?.toString() ?? t['id']?.toString() ?? '') == cleanId,
        orElse: () => <String, dynamic>{},
      );

      if (mounted) {
        setState(() {
          if (match.isNotEmpty) {
            _currentTrackTitle = match['title']?.toString() ?? _currentTrackTitle;
            _currentArtist = match['artist']?.toString() ?? _currentArtist;
            _currentAlbumName = match['album']?.toString() ?? _currentAlbumName;
          }
          _activeVideoId = 'hifi_$cleanId';
          _lastTelemetryTrackId = 'hifi_$cleanId';
          _isHiFiBrowserOpen = false;
          _isHiFi = true;
          _currentMode = PlinthMode.audiophileDeck;
        });
      }
      _resetInactivityTimer();
      _isPlayingNotifier.value = true;
      _vinylRotationController.repeat();

      // Direct low-latency media playback on local player
      final streamUrl = 'http://127.0.0.1:8000/media/hifi/$cleanId/stream';
      await _player.open(Media(streamUrl), play: true);
      await _player.setVolume(_volumeNotifier.value);
      _resetControlsVisibilityTimer();

      // Background pulse beat & dominant color sync
      _fetchBeatsAndColor('hifi_$cleanId');

      // Backend sync for state broadcast and predictive track N+1 pre-caching
      try {
        final res = await http.post(
          Uri.parse('http://127.0.0.1:8000/api/hifi/play'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'track_id': cleanId}),
        );
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['bit_depth'] != null) _bitDepth = (data['bit_depth'] as num).toInt();
          if (data['sample_rate_hz'] != null) _sampleRateHz = (data['sample_rate_hz'] as num).toInt();
          final hex = data['dominant_color'] as String?;
          if (hex != null && hex.startsWith('#') && hex.length == 7) {
            _smoothTransitionDominantColor(Color(int.parse(hex.replaceFirst('#', '0xFF'))));
          }
          if (mounted) setState(() {});
        }
      } catch (e) {
        debugPrint('Error syncing Hi-Fi play with backend: $e');
      }
    } catch (e) {
      debugPrint('Error playing Hi-Fi track: $e');
    }
  }

  Widget _buildAudiophileTurntableCenterpiece(double size) {
    final turntableDiameter = size * 0.44;
    final coverDiameter = size * 0.22;

    return Center(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onHorizontalDragEnd: (details) {
          final velocity = details.primaryVelocity ?? 0;
          if (velocity < -200) {
            _playNextTrack();
          } else if (velocity > 200) {
            _playPreviousTrack();
          }
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // 1. Radial Reactive Frequency Glow Ring
            AnimatedBuilder(
              animation: Listenable.merge([_beatPulseController, _dominantColorNotifier]),
              builder: (context, _) {
                final kick = math.sin(_beatPulseController.value * math.pi);
                return Container(
                  width: turntableDiameter + 50 + (16 * kick),
                  height: turntableDiameter + 50 + (16 * kick),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _dominantColorNotifier.value.withValues(alpha: 0.35 + 0.25 * kick),
                        blurRadius: 35 + 15 * kick,
                        spreadRadius: 4 + 8 * kick,
                      ),
                      BoxShadow(
                        color: const Color(0xFFF59E0B).withValues(alpha: 0.20 + 0.15 * kick),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                );
              },
            ),

            // 2. Rotating Vinyl Record Body
            RotationTransition(
              turns: _vinylRotationController,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _resetControlsVisibilityTimer,
                onHorizontalDragEnd: (details) {
                  final velocity = details.primaryVelocity ?? 0;
                  if (velocity < -200) {
                    _playNextTrack();
                  } else if (velocity > 200) {
                    _playPreviousTrack();
                  }
                },
                child: Container(
                  width: turntableDiameter,
                  height: turntableDiameter,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(
                      colors: [
                        Color(0xFF0D0E12),
                        Color(0xFF14151C),
                        Color(0xFF0A0B0E),
                        Color(0xFF181922),
                        Color(0xFF060608),
                      ],
                      stops: [0.0, 0.45, 0.70, 0.90, 1.0],
                    ),
                    border: Border.all(color: const Color(0x44F59E0B), width: 1.5),
                    boxShadow: const [
                      BoxShadow(color: Colors.black87, blurRadius: 30, spreadRadius: 4),
                    ],
                  ),
                  child: CustomPaint(
                    painter: VinylGroovesPainter(),
                    child: Center(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: _resetControlsVisibilityTimer,
                        onDoubleTap: _togglePlayPause,
                        onHorizontalDragEnd: (details) {
                          final velocity = details.primaryVelocity ?? 0;
                          if (velocity < -200) {
                            _playNextTrack();
                          } else if (velocity > 200) {
                            _playPreviousTrack();
                          }
                        },
                        child: Container(
                          width: coverDiameter,
                          height: coverDiameter,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xCCF59E0B), width: 2.2),
                            boxShadow: const [
                              BoxShadow(color: Colors.black54, blurRadius: 12),
                            ],
                          ),
                          child: ClipOval(
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                // Always show Album Cover Art
                                Image.network(
                                  'http://127.0.0.1:8000/api/hifi/cover?track_id=$_activeVideoId',
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      decoration: const BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                      ),
                                      child: const Center(
                                        child: Icon(Icons.music_note_rounded, color: Color(0xFFFBBF24), size: 48),
                                      ),
                                    );
                                  },
                                ),

                                // Center Brass Spindle or Subtle Paused Marker (when not loading)
                                if (_preparingVideoId == null)
                                  ValueListenableBuilder<bool>(
                                    valueListenable: _isPlayingNotifier,
                                    builder: (context, isPlaying, _) {
                                      if (!isPlaying) {
                                        return Container(
                                          color: const Color(0x66000000),
                                          child: const Center(
                                            child: Icon(
                                              Icons.pause_rounded,
                                              color: Color(0xCCF59E0B),
                                              size: 40,
                                            ),
                                          ),
                                        );
                                      }
                                      return Center(
                                        child: Container(
                                          width: 22,
                                          height: 22,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: const Color(0xFF050505),
                                            border: Border.all(color: const Color(0xFFD97706), width: 2.5),
                                            boxShadow: const [
                                              BoxShadow(color: Colors.black, blurRadius: 4),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),

                                // Live Lossless FLAC / 1080p Download Progress Overlay
                                if (_preparingVideoId != null)
                                  Container(
                                    color: const Color(0xBB000000),
                                    child: Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: 48,
                                            height: 48,
                                            child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                CircularProgressIndicator(
                                                  value: _preparingProgress > 0 ? _preparingProgress : null,
                                                  strokeWidth: 3.5,
                                                  backgroundColor: const Color(0x33F59E0B),
                                                  color: const Color(0xFFF59E0B),
                                                ),
                                                Text(
                                                  '$_preparingPercent%',
                                                  style: const TextStyle(
                                                    color: Color(0xFFFBBF24),
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.w900,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(height: 6),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 10.0),
                                            child: Text(
                                              _preparingStatus.isNotEmpty ? _preparingStatus : 'Buffering FLAC...',
                                              textAlign: TextAlign.center,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                color: Color(0xFFFDE68A),
                                                fontSize: 9,
                                                fontWeight: FontWeight.w700,
                                                letterSpacing: 0.5,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHiFiBrowserOverlay(double size) {
    return Stack(
      children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => setState(() => _isHiFiBrowserOpen = false),
          child: Container(color: const Color(0xD904070F)),
        ),
        Positioned(
          top: size * 0.14,
          left: size * 0.14,
          right: size * 0.14,
          bottom: size * 0.13,
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xF20B101D),
              borderRadius: BorderRadius.circular(32),
              border: Border.all(color: const Color(0xFFF59E0B), width: 1.6),
              boxShadow: const [
                BoxShadow(color: Color(0x55F59E0B), blurRadius: 28, spreadRadius: 2),
                BoxShadow(color: Colors.black87, blurRadius: 30, offset: Offset(0, 10)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    decoration: const BoxDecoration(
                      color: Color(0x88080C16),
                      border: Border(bottom: BorderSide(color: Color(0x33F59E0B), width: 1)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: const Color(0x22F59E0B),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: const Color(0x66F59E0B), width: 1),
                              ),
                              child: const Icon(Icons.album_rounded, color: Color(0xFFFBBF24), size: 22),
                            ),
                            const SizedBox(width: 12),
                            const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'HI-FI LOSSLESS LIBRARY',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.2,
                                    color: Colors.white,
                                  ),
                                ),
                                Text(
                                  'Master Quality Audio & Google Drive',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Color(0x99FBBF24),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            TactileButton(
                              scaleFactor: 0.90,
                              onTap: () {
                                setState(() {
                                  _isHiFiBrowserOpen = false;
                                  _isSearchOpen = true;
                                  _isSearchHiFiMode = true;
                                  _searchQuery = '';
                                  _searchResults = [];
                                  _hifiSearchResults = [];
                                });
                                if (_hifiFlatTrackIndex.isEmpty) {
                                  _loadHiFiTree();
                                }
                              },
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0x22F59E0B),
                                  border: Border.all(color: const Color(0x88F59E0B), width: 1.2),
                                ),
                                child: const Icon(Icons.search_rounded, size: 20, color: Color(0xFFFBBF24)),
                              ),
                            ),
                            const SizedBox(width: 10),
                            TactileButton(
                              scaleFactor: 0.90,
                              onTap: () => _loadHiFiTree(force: true),
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0x22F59E0B),
                                  border: Border.all(color: const Color(0x88F59E0B), width: 1.2),
                                ),
                                child: _isLoadingHiFiTree
                                    ? const Center(
                                        child: SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFBBF24)),
                                        ),
                                      )
                                    : const Icon(Icons.refresh_rounded, size: 20, color: Color(0xFFFBBF24)),
                              ),
                            ),
                            const SizedBox(width: 10),
                            TactileButton(
                              scaleFactor: 0.90,
                              onTap: () => setState(() => _isHiFiBrowserOpen = false),
                              child: Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0x22FFFFFF),
                                  border: Border.all(color: const Color(0x44F59E0B), width: 1.2),
                                ),
                                child: const Icon(Icons.close, size: 20, color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    color: const Color(0x77060A13),
                    child: Row(
                      children: [
                        // When inside artist or album or playlist, show prominent BACK button
                        if (_hifiNavTab == 1 && _hifiSelectedPlaylistId.isNotEmpty) ...[
                          GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () {
                              setState(() {
                                _hifiSelectedPlaylistId = '';
                                _hifiSelectedPlaylistName = '';
                                _hifiPlaylistTracks = [];
                              });
                            },
                            child: Container(
                              height: 48,
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              margin: const EdgeInsets.only(right: 12),
                              decoration: BoxDecoration(
                                color: const Color(0x33F59E0B),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0xFFF59E0B), width: 1.5),
                                boxShadow: const [
                                  BoxShadow(color: Color(0x44F59E0B), blurRadius: 10),
                                ],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: const [
                                  Icon(Icons.arrow_back_rounded, size: 22, color: Color(0xFFFBBF24)),
                                  SizedBox(width: 6),
                                  Text(
                                    'PLAYLISTS',
                                    style: TextStyle(
                                      color: Color(0xFFFBBF24),
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Flexible(
                            child: Text(
                              _hifiSelectedPlaylistName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800),
                            ),
                          ),
                        ] else if (_hifiBrowserLevel > 0) ...[
                          GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () {
                              setState(() {
                                if (_hifiBrowserLevel == 2) {
                                  _hifiBrowserLevel = 1;
                                  _hifiSelectedAlbum = '';
                                } else if (_hifiBrowserLevel == 1) {
                                  _hifiBrowserLevel = 0;
                                  _hifiSelectedArtist = '';
                                  _hifiSelectedAlbum = '';
                                }
                              });
                            },
                            child: Container(
                              height: 48,
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              margin: const EdgeInsets.only(right: 12),
                              decoration: BoxDecoration(
                                color: const Color(0x33F59E0B),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0xFFF59E0B), width: 1.5),
                                boxShadow: const [
                                  BoxShadow(color: Color(0x44F59E0B), blurRadius: 10),
                                ],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: const [
                                  Icon(Icons.arrow_back_rounded, size: 22, color: Color(0xFFFBBF24)),
                                  SizedBox(width: 6),
                                  Text(
                                    'BACK',
                                    style: TextStyle(
                                      color: Color(0xFFFBBF24),
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Flexible(
                            child: Text(
                              _hifiBrowserLevel == 2 ? '$_hifiSelectedArtist • $_hifiSelectedAlbum' : _hifiSelectedArtist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700),
                            ),
                          ),
                        ] else ...[
                          // Root Nav Segmented Tabs: [ 🧑 ARTISTS ] [ 📑 PLAYLISTS ] [ 🔀 SMART MIXES ]
                          _buildHifiNavTab(0, Icons.person_rounded, 'ARTISTS'),
                          const SizedBox(width: 8),
                          _buildHifiNavTab(1, Icons.playlist_play_rounded, 'PLAYLISTS'),
                          const SizedBox(width: 8),
                          _buildHifiNavTab(2, Icons.auto_awesome_rounded, 'SMART MIXES'),
                        ],

                        const Spacer(),

                        // Search Library Action Button (height 48px, generous finger hit target)
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () {
                            setState(() {
                              _isSearchHiFiMode = true;
                              _isSearchOpen = true;
                              _isHiFiBrowserOpen = false;
                              _searchQuery = '';
                              _searchResults = [];
                              _hifiSearchResults = [];
                            });
                          },
                          child: Container(
                            height: 48,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                              color: const Color(0x33F59E0B),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: const Color(0xFFF59E0B), width: 1.5),
                              boxShadow: const [
                                BoxShadow(color: Color(0x33F59E0B), blurRadius: 8),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Icon(Icons.search_rounded, size: 20, color: Color(0xFFFBBF24)),
                                SizedBox(width: 6),
                                Text(
                                  'SEARCH',
                                  style: TextStyle(
                                    color: Color(0xFFFBBF24),
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                    letterSpacing: 0.6,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: _isLoadingHiFiTree
                        ? const Center(
                            child: CircularProgressIndicator(color: Color(0xFFF59E0B)),
                          )
                        : _buildHiFiBrowserContent(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHifiNavTab(int tabIndex, IconData icon, String label) {
    final isSelected = _hifiNavTab == tabIndex;
    return TactileButton(
      scaleFactor: 0.94,
      onTap: () {
        setState(() {
          _hifiNavTab = tabIndex;
          _hifiSelectedPlaylistId = '';
          _hifiSelectedPlaylistName = '';
        });
        if (tabIndex == 1) {
          _loadHiFiPlaylists();
        }
      },
      child: Container(
        height: 48,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFF59E0B) : const Color(0x1AFFFFFF),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? const Color(0xFFFBBF24) : const Color(0x33FFFFFF),
            width: isSelected ? 1.5 : 1.0,
          ),
          boxShadow: isSelected
              ? const [BoxShadow(color: Color(0x55F59E0B), blurRadius: 10)]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: isSelected ? Colors.black : Colors.white70),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.black : Colors.white,
                fontWeight: isSelected ? FontWeight.w900 : FontWeight.w700,
                fontSize: 13.5,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHiFiBrowserContent() {
    if (_hifiNavTab == 1) {
      return _buildPlaylistsTabContent();
    }
    if (_hifiNavTab == 2) {
      return _buildSmartMixesTabContent();
    }
    return _buildArtistsTabContent();
  }

  Widget _buildArtistsTabContent() {
    if (_hifiTree == null || _hifiArtistList.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.library_music_rounded, size: 48, color: Color(0x66FFFFFF)),
            const SizedBox(height: 12),
            const Text(
              'No Hi-Fi music found in /data/hifi_music.',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            const SizedBox(height: 14),
            ElevatedButton.icon(
              onPressed: _loadHiFiTree,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF59E0B),
                foregroundColor: Colors.black,
              ),
              icon: const Icon(Icons.refresh, size: 18),
              label: const Text('Refresh Library'),
            ),
          ],
        ),
      );
    }

    // LEVEL 0: Artists with Top Quick Bar and A-Z Jump Scrubber
    if (_hifiBrowserLevel == 0) {
      final alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ#'.split('');
      return Column(
        children: [
          // Top Quick Action Bar: Shuffle All & Random 50
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: const Color(0x44080C16),
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => _playSmartMix('random'),
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: const [BoxShadow(color: Color(0x44F59E0B), blurRadius: 10)],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.shuffle_rounded, color: Colors.black, size: 22),
                          SizedBox(width: 8),
                          Text('SHUFFLE LIBRARY', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w900)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _playSmartMix('recently_added'),
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        color: const Color(0x2210B981),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF10B981), width: 1.4),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.new_releases_rounded, color: Color(0xFF34D399), size: 20),
                          SizedBox(width: 8),
                          Text('RECENT UPLOADS', style: TextStyle(color: Color(0xFF34D399), fontSize: 13.5, fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Main Artists List with Right Edge A-Z Scrubber
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: ListView.separated(
                    controller: _hifiArtistScrollController,
                    padding: const EdgeInsets.only(left: 20, right: 8, top: 10, bottom: 20),
                    itemCount: _hifiArtistList.length,
                    separatorBuilder: (context, index) => const SizedBox(height: 6),
                    itemBuilder: (context, idx) {
                      final artist = _hifiArtistList[idx];
                      final name = artist['name']?.toString() ?? 'Unknown Artist';
                      final albumCount = (artist['album_count'] as num?)?.toInt() ?? 0;
                      return Container(
                        height: 72,
                        decoration: BoxDecoration(
                          color: const Color(0x1AFFFFFF),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0x22F59E0B), width: 1.2),
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                          leading: Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0x33F59E0B),
                              border: Border.all(color: const Color(0x66F59E0B), width: 1.5),
                            ),
                            child: const Icon(Icons.person_rounded, color: Color(0xFFFBBF24), size: 28),
                          ),
                          title: Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800),
                          ),
                          subtitle: Text(
                            '$albumCount Albums',
                            style: const TextStyle(color: Color(0xFFFBBF24), fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                          trailing: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0x22FFFFFF),
                              border: Border.all(color: const Color(0x33FFFFFF)),
                            ),
                            child: const Icon(Icons.chevron_right_rounded, color: Colors.white, size: 24),
                          ),
                          onTap: () {
                            final albums = (artist['albums'] as List? ?? []).cast<Map<String, dynamic>>();
                            setState(() {
                              _hifiSelectedArtist = name;
                              _hifiAlbumList = albums;
                              _hifiBrowserLevel = 1;
                            });
                          },
                        ),
                      );
                    },
                  ),
                ),

                // A-Z Quick Scrubber
                Container(
                  width: 32,
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: alphabet.map((letter) {
                        return GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () {
                            final targetIdx = _hifiArtistList.indexWhere((a) {
                              final aname = (a['name']?.toString() ?? '').trim().toUpperCase();
                              if (letter == '#') return aname.isNotEmpty && !aname[0].contains(RegExp(r'[A-Z]'));
                              return aname.startsWith(letter);
                            });
                            if (targetIdx >= 0) {
                              _hifiArtistScrollController.animateTo(
                                targetIdx * 78.0,
                                duration: const Duration(milliseconds: 250),
                                curve: Curves.easeOutCubic,
                              );
                            }
                          },
                          child: Container(
                            width: 30,
                            height: 22,
                            alignment: Alignment.center,
                            child: Text(
                              letter,
                              style: const TextStyle(color: Color(0xCCFBBF24), fontSize: 11, fontWeight: FontWeight.w900),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    // LEVEL 1: Albums inside Selected Artist
    if (_hifiBrowserLevel == 1) {
      return Column(
        children: [
          // Top Quick Action Bar for Artist
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: const Color(0x44080C16),
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => _playSmartMix('artist_mix', artist: _hifiSelectedArtist),
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: const [BoxShadow(color: Color(0x44F59E0B), blurRadius: 10)],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.shuffle_rounded, color: Colors.black, size: 22),
                          SizedBox(width: 8),
                          Text('SHUFFLE ARTIST', style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w900)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              itemCount: _hifiAlbumList.length,
              separatorBuilder: (context, index) => const SizedBox(height: 8),
              itemBuilder: (context, idx) {
                final album = _hifiAlbumList[idx];
                final name = album['name']?.toString() ?? 'Unknown Album';
                final trackCount = (album['track_count'] as num?)?.toInt() ?? 0;
                final coverRel = album['cover_rel']?.toString();
                final coverUrl = coverRel != null
                    ? 'http://127.0.0.1:8000/api/hifi/cover?rel_path=${Uri.encodeComponent(coverRel)}'
                    : null;

                return Container(
                  height: 76,
                  decoration: BoxDecoration(
                    color: const Color(0x1AFFFFFF),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0x33F59E0B), width: 1.2),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    leading: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0x66F59E0B), width: 1.5),
                        color: const Color(0xFF1E293B),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: coverUrl != null
                            ? Image.network(
                                coverUrl,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.album_rounded, color: Color(0xFFFBBF24), size: 30),
                              )
                            : const Icon(Icons.album_rounded, color: Color(0xFFFBBF24), size: 30),
                      ),
                    ),
                    title: Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '$trackCount Tracks',
                      style: const TextStyle(color: Color(0xFFFBBF24), fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    trailing: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0x22FFFFFF),
                        border: Border.all(color: const Color(0x33FFFFFF)),
                      ),
                      child: const Icon(Icons.chevron_right_rounded, color: Colors.white, size: 24),
                    ),
                    onTap: () {
                      final tracks = (album['tracks'] as List? ?? []).cast<Map<String, dynamic>>();
                      setState(() {
                        _hifiSelectedAlbum = name;
                        _hifiTrackList = tracks;
                        _hifiBrowserLevel = 2;
                      });
                    },
                  ),
                );
              },
            ),
          ),
        ],
      );
    }

    // LEVEL 2: Tracks (Finger-friendly list with 66px min-height & direct actions)
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      itemCount: _hifiTrackList.length,
      separatorBuilder: (context, index) => const Divider(color: Color(0x1AFFFFFF), height: 1),
      itemBuilder: (context, idx) {
        final track = _hifiTrackList[idx];
        final title = track['title']?.toString() ?? 'Unknown Track';
        final trackNum = (track['track_num'] as num?)?.toInt() ?? (idx + 1);
        final duration = track['duration']?.toString() ?? '0:00';
        final fmt = track['format']?.toString() ?? 'FLAC';
        final bits = (track['bit_depth'] as num?)?.toInt() ?? 16;
        final trackId = track['track_id']?.toString() ?? '';
        final isPlayingThis = _activeVideoId == 'hifi_$trackId' && _isPlayingNotifier.value;
        final isCached = track['is_cached'] == true;

        return Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _showTrackActionSheet(track),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              constraints: const BoxConstraints(minHeight: 66),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    alignment: Alignment.center,
                    child: isPlayingThis
                        ? const Icon(Icons.equalizer_rounded, color: Color(0xFF10B981), size: 24)
                        : Text(
                            trackNum.toString().padLeft(2, '0'),
                            style: const TextStyle(
                              color: Color(0x88FFFFFF),
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: isPlayingThis ? const Color(0xFF10B981) : Colors.white,
                            fontSize: 15.5,
                            fontWeight: isPlayingThis ? FontWeight.w800 : FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: const Color(0x22F59E0B),
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(color: const Color(0x66F59E0B), width: 0.8),
                              ),
                              child: Text(
                                '$bits-BIT $fmt',
                                style: const TextStyle(color: Color(0xFFFBBF24), fontSize: 10, fontWeight: FontWeight.w700),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                              decoration: BoxDecoration(
                                color: isCached ? const Color(0x2210B981) : const Color(0x2200E5FF),
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(
                                  color: isCached ? const Color(0x6610B981) : const Color(0x6600E5FF),
                                  width: 0.8,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    isCached ? Icons.check_circle_outline_rounded : Icons.cloud_outlined,
                                    size: 11,
                                    color: isCached ? const Color(0xFF34D399) : const Color(0xFF67E8F9),
                                  ),
                                  const SizedBox(width: 3),
                                  Text(
                                    isCached ? 'CACHED' : 'CLOUD',
                                    style: TextStyle(
                                      color: isCached ? const Color(0xFF34D399) : const Color(0xFF67E8F9),
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              duration,
                              style: const TextStyle(color: Color(0x88FFFFFF), fontSize: 11.5),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Direct Play Circle (48x48 touch button)
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => _playHiFiTrack(trackId, playlist: _hifiTrackList, index: idx),
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isPlayingThis ? const Color(0xFF10B981) : const Color(0x22F59E0B),
                        border: Border.all(
                          color: isPlayingThis ? const Color(0xFF10B981) : const Color(0x88F59E0B),
                          width: 1.5,
                        ),
                      ),
                      child: Icon(
                        isPlayingThis ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildPlaylistsTabContent() {
    if (_isLoadingPlaylists) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFF10B981), strokeWidth: 3),
            SizedBox(height: 16),
            Text('Loading Playlists...', style: TextStyle(color: Colors.white70, fontSize: 14)),
          ],
        ),
      );
    }

    if (_hifiSelectedPlaylistId.isNotEmpty) {
      return Column(
        children: [
          // Header / Back navigation
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: const Color(0x22000000),
            child: Row(
              children: [
                InkWell(
                  onTap: () => setState(() => _hifiSelectedPlaylistId = ''),
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    height: 48,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: const Color(0x22FFFFFF),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0x44FFFFFF)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.arrow_back_rounded, color: Colors.white, size: 20),
                        SizedBox(width: 6),
                        Text('ALL PLAYLISTS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _hifiSelectedPlaylistName ?? 'Playlist',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      Text(
                        '${_hifiPlaylistTracks.length} TRACKS',
                        style: const TextStyle(color: Color(0xFFF59E0B), fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                InkWell(
                  onTap: _hifiPlaylistTracks.isEmpty ? null : () => _playPlaylist(_hifiSelectedPlaylistId),
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    height: 48,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(color: const Color(0xFF10B981).withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 2)),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.play_arrow_rounded, color: Colors.white, size: 24),
                        SizedBox(width: 4),
                        Text('PLAY ALL', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(color: Color(0x22FFFFFF), height: 1),
          // Tracks in Playlist
          Expanded(
            child: _hifiPlaylistTracks.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.queue_music_rounded, color: Colors.white30, size: 54),
                          SizedBox(height: 12),
                          Text('This playlist is empty', style: TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.bold)),
                          SizedBox(height: 6),
                          Text('Browse Artists and tap any track to add it here.', style: TextStyle(color: Colors.white38, fontSize: 12), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    itemCount: _hifiPlaylistTracks.length,
                    separatorBuilder: (context, index) => const Divider(color: Color(0x1AFFFFFF), height: 1),
                    itemBuilder: (context, idx) {
                      final track = _hifiPlaylistTracks[idx];
                      final title = track['title']?.toString() ?? 'Unknown Track';
                      final artist = track['artist']?.toString() ?? 'Unknown Artist';
                      final trackId = track['track_id']?.toString() ?? '';
                      final isPlayingThis = _activeVideoId == 'hifi_$trackId' && _isPlayingNotifier.value;
                      final fmt = track['format']?.toString() ?? 'FLAC';
                      final bits = (track['bit_depth'] as num?)?.toInt() ?? 16;

                      return Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => _showTrackActionSheet(track),
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            constraints: const BoxConstraints(minHeight: 64),
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                            child: Row(
                              children: [
                                Container(
                                  width: 32,
                                  alignment: Alignment.center,
                                  child: isPlayingThis
                                      ? const Icon(Icons.equalizer_rounded, color: Color(0xFF10B981), size: 22)
                                      : Text(
                                          '${idx + 1}',
                                          style: const TextStyle(color: Colors.white54, fontSize: 13, fontWeight: FontWeight.bold),
                                        ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        title,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: isPlayingThis ? const Color(0xFF10B981) : Colors.white,
                                          fontSize: 15,
                                          fontWeight: isPlayingThis ? FontWeight.w800 : FontWeight.w600,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '$artist • $bits-bit $fmt',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(color: Colors.white60, fontSize: 12),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: () => _playHiFiTrack(trackId, playlist: _hifiPlaylistTracks, index: idx),
                                  child: Container(
                                    width: 48,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: isPlayingThis ? const Color(0xFF10B981) : const Color(0x22F59E0B),
                                      border: Border.all(
                                        color: isPlayingThis ? const Color(0xFF10B981) : const Color(0x88F59E0B),
                                        width: 1.5,
                                      ),
                                    ),
                                    child: Icon(
                                      isPlayingThis ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                      color: Colors.white,
                                      size: 26,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      );
    }

    // List of all playlists
    return Column(
      children: [
        // Top action bar
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'YOUR PLAYLISTS',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 1.1),
              ),
              InkWell(
                onTap: _loadHiFiPlaylists,
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  height: 44,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: const Color(0x22FFFFFF),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0x44FFFFFF)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.refresh_rounded, color: Colors.white, size: 18),
                      SizedBox(width: 6),
                      Text('REFRESH', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const Divider(color: Color(0x22FFFFFF), height: 1),
        Expanded(
          child: _hifiPlaylists.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.queue_music_rounded, color: Colors.white30, size: 60),
                      SizedBox(height: 12),
                      Text('No Playlists Found', style: TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.bold)),
                      SizedBox(height: 6),
                      Text('Favorites will appear here automatically.', style: TextStyle(color: Colors.white38, fontSize: 12)),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  itemCount: _hifiPlaylists.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 10),
                  itemBuilder: (context, idx) {
                    final pl = _hifiPlaylists[idx];
                    final id = pl['id']?.toString() ?? '';
                    final name = pl['name']?.toString() ?? 'Playlist';
                    final trackCount = (pl['track_count'] as num?)?.toInt() ?? (pl['tracks'] as List?)?.length ?? 0;
                    final isFav = id == 'favorites';

                    return Material(
                      color: const Color(0x15FFFFFF),
                      borderRadius: BorderRadius.circular(14),
                      child: InkWell(
                        onTap: () => _loadPlaylistDetail(id, name),
                        borderRadius: BorderRadius.circular(14),
                        child: Container(
                          constraints: const BoxConstraints(minHeight: 74),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isFav ? const Color(0x55EF4444) : const Color(0x2AFFFFFF),
                              width: 1.2,
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: isFav ? const Color(0x33EF4444) : const Color(0x22F59E0B),
                                ),
                                child: Icon(
                                  isFav ? Icons.favorite_rounded : Icons.playlist_play_rounded,
                                  color: isFav ? const Color(0xFFEF4444) : const Color(0xFFF59E0B),
                                  size: 28,
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: isFav ? const Color(0xFFFCA5A5) : Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      '$trackCount TRACKS',
                                      style: const TextStyle(color: Colors.white54, fontSize: 12, fontWeight: FontWeight.w600),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 10),
                              GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => _playPlaylist(id),
                                child: Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: const Color(0xFF10B981),
                                    boxShadow: [
                                      BoxShadow(color: const Color(0xFF10B981).withOpacity(0.3), blurRadius: 6),
                                    ],
                                  ),
                                  child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 28),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildSmartMixesTabContent() {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      children: [
        const Text(
          'INSTANT SMART MIXES',
          style: TextStyle(color: Color(0xFFF59E0B), fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.2),
        ),
        const SizedBox(height: 4),
        const Text(
          'One-tap dynamic lossless radio queues generated from your high-res library.',
          style: TextStyle(color: Colors.white70, fontSize: 13),
        ),
        const SizedBox(height: 16),
        _buildMixActionCard(
          title: 'LIBRARY SHUFFLE (50)',
          subtitle: 'Instant surprise mix across your entire lossless collection',
          icon: Icons.shuffle_rounded,
          accentColor: const Color(0xFF10B981),
          onTap: () => _playSmartMix('random'),
        ),
        _buildMixActionCard(
          title: 'ARTIST RADIO',
          subtitle: _hifiSelectedArtist != null
              ? 'Continuous mix centered on $_hifiSelectedArtist'
              : 'Continuous shuffle of selected artist (tap an artist first)',
          icon: Icons.radio_rounded,
          accentColor: const Color(0xFFEC4899),
          onTap: _hifiSelectedArtist != null ? () => _playSmartMix('artist_mix', artist: _hifiSelectedArtist) : null,
        ),
        _buildMixActionCard(
          title: 'RECENTLY ADDED',
          subtitle: 'The 50 freshest tracks uploaded to your server',
          icon: Icons.auto_awesome_rounded,
          accentColor: const Color(0xFF3B82F6),
          onTap: () => _playSmartMix('recently_added'),
        ),
        _buildMixActionCard(
          title: 'AUDIOPHILE 24-BIT / DSD',
          subtitle: 'Studio Master quality only (FLAC >= 24-bit, DSD, DXD)',
          icon: Icons.diamond_rounded,
          accentColor: const Color(0xFFF59E0B),
          onTap: () => _playSmartMix('audiophile'),
        ),
      ],
    );
  }

  Widget _buildMixActionCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color accentColor,
    VoidCallback? onTap,
  }) {
    final isEnabled = onTap != null;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      constraints: const BoxConstraints(minHeight: 76),
      decoration: BoxDecoration(
        color: const Color(0x1A1F2937),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isEnabled ? accentColor.withOpacity(0.5) : const Color(0x22FFFFFF),
          width: 1.2,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: accentColor.withOpacity(0.5)),
                  ),
                  child: Icon(icon, color: accentColor, size: 26),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: isEnabled ? Colors.white : Colors.white38,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: isEnabled ? Colors.white70 : Colors.white24,
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  height: 48,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: isEnabled ? accentColor : const Color(0x22FFFFFF),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: isEnabled
                        ? [BoxShadow(color: accentColor.withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 2))]
                        : null,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.play_arrow_rounded,
                        color: isEnabled ? Colors.white : Colors.white38,
                        size: 22,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'PLAY',
                        style: TextStyle(
                          color: isEnabled ? Colors.white : Colors.white38,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class VinylGroovesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2;
    final minRadius = size.width * 0.23;

    final groovePaint = Paint()
      ..color = const Color(0x18FFFFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    for (double r = minRadius + 8; r < maxRadius - 6; r += 7.0) {
      canvas.drawCircle(center, r, groovePaint);
    }

    final sheenPaint = Paint()
      ..shader = SweepGradient(
        colors: [
          Colors.transparent,
          Colors.white.withValues(alpha: 0.08),
          Colors.transparent,
          Colors.white.withValues(alpha: 0.08),
          Colors.transparent,
        ],
        stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: maxRadius));

    canvas.drawCircle(center, maxRadius - 2, sheenPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}


// --- APPLE-GRADE OPTICAL GLOW RIBBON PAINTER (SIRI-STYLE CIRCULAR ADDITIVE BLOOM) ---

class AppleGlowRibbonPainter extends CustomPainter {
  final double flowProgress;
  final double kickPulse;
  final double phaseLock;
  final Color glowColor;

  AppleGlowRibbonPainter({
    required this.flowProgress,
    required this.kickPulse,
    required this.phaseLock,
    required this.glowColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    // Base radius leaves headroom for dramatic harmonic undulations inside the circular bezel
    final baseRadius = size.width * 0.458;
    const segments = 220;
    // Bolder, pronounced wave amplitude with tactile kick transient
    final baseAmp = 16.0 + (kickPulse * 26.0);

    // 0. Caliper Outer Bezel Reference Ring (Tinted with prominent video color)
    final outerBezelRadius = size.width * 0.490;
    final bezelPaint = Paint()
      ..color = glowColor.withValues(alpha: 0.22)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;
    canvas.drawCircle(center, outerBezelRadius, bezelPaint);

    // Harmonic circular wave profiles: [phaseOffset, freqMultiplier, coreAlpha, ampScale]
    // Integer frequencies (2, 3, 4, 5) guarantee smooth 360-degree closed circular continuity
    final harmonics = [
      [0.0, 2.0, 0.95, 1.0],
      [1.3, 3.0, 0.70, 1.3],
      [2.7, 4.0, 0.50, 0.8],
      [4.1, 5.0, 0.35, 1.5],
    ];

    final ambientAuraPaint = Paint()
      ..style = PaintingStyle.stroke
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12)
      ..blendMode = BlendMode.screen;

    final nearBloomPaint = Paint()
      ..style = PaintingStyle.stroke
      ..maskFilter = const MaskFilter.blur(BlurStyle.solid, 4)
      ..blendMode = BlendMode.plus;

    final crispFilamentPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (final harmonic in harmonics) {
      final phaseOffset = harmonic[0] + (phaseLock * 0.5);
      final freqMultiplier = harmonic[1];
      final coreAlpha = harmonic[2];
      final ampScale = harmonic[3];

      final path = Path();
      for (int i = 0; i <= segments; i++) {
        final theta = (i / segments) * 2 * math.pi;

        // Flow phase around the circle with harmonic undulations
        final angle = theta * freqMultiplier + (flowProgress * 2 * math.pi) + phaseOffset;
        final radialWave = math.sin(angle) * 0.75 + math.cos(angle * 2.0) * 0.25;
        final radialOffset = radialWave * baseAmp * ampScale;
        final r = baseRadius + radialOffset;

        final x = center.dx + r * math.cos(theta);
        final y = center.dy + r * math.sin(theta);

        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      path.close();

      // 1. Far Ambient Glow (Soft wide video-tinted mist)
      ambientAuraPaint.color = glowColor.withValues(alpha: (0.16 * coreAlpha + kickPulse * 0.12).clamp(0.0, 1.0));
      ambientAuraPaint.strokeWidth = 22.0 + (kickPulse * 12.0);
      canvas.drawPath(path, ambientAuraPaint);

      // 2. Near Bloom (Sharp additive white/dominant bloom aura)
      nearBloomPaint.color = Color.lerp(glowColor, Colors.white, 0.35)!
          .withValues(alpha: (0.42 * coreAlpha + kickPulse * 0.28).clamp(0.0, 1.0));
      nearBloomPaint.strokeWidth = 5.0 + (kickPulse * 2.5);
      canvas.drawPath(path, nearBloomPaint);

      // 3. Crisp Filament Core (Pure white center fiber)
      crispFilamentPaint.color = Colors.white.withValues(alpha: coreAlpha);
      crispFilamentPaint.strokeWidth = 1.6;
      canvas.drawPath(path, crispFilamentPaint);
    }
  }

  @override
  bool shouldRepaint(covariant AppleGlowRibbonPainter oldDelegate) => true;
}

// --- CINEMATIC BOOT CALIBRATION PAINTER ---

class BootCalibrationPainter extends CustomPainter {
  final double progress;
  final Color primaryColor;

  BootCalibrationPainter({
    required this.progress,
    this.primaryColor = const Color(0xFF00E5FF),
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2;

    // 1. Concentric reference rings
    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..color = primaryColor.withValues(alpha: 0.15);

    canvas.drawCircle(center, maxRadius * 0.94, ringPaint);
    canvas.drawCircle(center, maxRadius * 0.78, ringPaint);
    canvas.drawCircle(center, maxRadius * 0.52, ringPaint);
    canvas.drawCircle(center, maxRadius * 0.26, ringPaint);

    // 2. High-precision measurement ticks (72 ticks around perimeter)
    final tickPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < 72; i++) {
      final angle = (2 * math.pi * i) / 72;
      final isMajor = i % 6 == 0;
      final tickLen = isMajor ? 14.0 : 6.0;
      final alpha = isMajor ? 0.65 : 0.25;

      tickPaint.color = primaryColor.withValues(alpha: alpha);
      tickPaint.strokeWidth = isMajor ? 1.8 : 1.0;

      final p1 = Offset(
        center.dx + (maxRadius * 0.94 - tickLen) * math.cos(angle),
        center.dy + (maxRadius * 0.94 - tickLen) * math.sin(angle),
      );
      final p2 = Offset(
        center.dx + (maxRadius * 0.94) * math.cos(angle),
        center.dy + (maxRadius * 0.94) * math.sin(angle),
      );
      canvas.drawLine(p1, p2, tickPaint);
    }

    // 3. Dynamic rotating calibration arc
    final sweepAngle = 2 * math.pi * progress;
    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        startAngle: 0.0,
        endAngle: 2 * math.pi,
        colors: [
          primaryColor.withValues(alpha: 0.0),
          primaryColor.withValues(alpha: 0.4),
          Colors.white,
        ],
        stops: const [0.0, 0.7, 1.0],
        transform: GradientRotation(sweepAngle - math.pi / 2),
      ).createShader(Rect.fromCircle(center: center, radius: maxRadius * 0.78));

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: maxRadius * 0.78),
      -math.pi / 2,
      sweepAngle,
      false,
      arcPaint,
    );

    // 4. Inner counter-rotating calibration arc
    final innerArcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF38BDF8).withValues(alpha: 0.5);

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: maxRadius * 0.52),
      math.pi / 2 - (sweepAngle * 0.7),
      sweepAngle * 0.7,
      false,
      innerArcPaint,
    );

    // 5. Reticle crosshairs
    final reticlePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..color = primaryColor.withValues(alpha: 0.3);

    const crosshairLen = 22.0;
    canvas.drawLine(
      Offset(center.dx, center.dy - maxRadius * 0.26 - crosshairLen),
      Offset(center.dx, center.dy - maxRadius * 0.26 + crosshairLen),
      reticlePaint,
    );
    canvas.drawLine(
      Offset(center.dx, center.dy + maxRadius * 0.26 - crosshairLen),
      Offset(center.dx, center.dy + maxRadius * 0.26 + crosshairLen),
      reticlePaint,
    );
    canvas.drawLine(
      Offset(center.dx - maxRadius * 0.26 - crosshairLen, center.dy),
      Offset(center.dx - maxRadius * 0.26 + crosshairLen, center.dy),
      reticlePaint,
    );
    canvas.drawLine(
      Offset(center.dx + maxRadius * 0.26 - crosshairLen, center.dy),
      Offset(center.dx + maxRadius * 0.26 + crosshairLen, center.dy),
      reticlePaint,
    );
  }

  @override
  bool shouldRepaint(covariant BootCalibrationPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.primaryColor != primaryColor;
}

// --- CELESTIAL CONSTELLATION STAR MAP PAINTER ---

class CelestialConstellationPainter extends CustomPainter {
  final Color starColor;

  CelestialConstellationPainter({required this.starColor});

  static const List<Offset> _stars = [
    Offset(-0.28, -0.22),
    Offset(-0.16, -0.32),
    Offset(0.00, -0.38),
    Offset(0.24, -0.28),
    Offset(0.36, -0.14),
    Offset(0.38, 0.12),
    Offset(0.26, 0.28),
    Offset(-0.06, 0.36),
    Offset(-0.26, 0.24),
    Offset(-0.36, 0.04),
    Offset(-0.12, -0.06),
    Offset(0.14, 0.02),
  ];

  static const List<List<int>> _connections = [
    [0, 1], [1, 2], [2, 3], [3, 4], [4, 5],
    [5, 6], [6, 7], [7, 8], [8, 9], [9, 0],
    [0, 10], [10, 11], [11, 4], [10, 7], [11, 6],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final scale = size.width * 0.44;

    final linePaint = Paint()
      ..color = starColor.withValues(alpha: 0.08)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;

    for (final pair in _connections) {
      final p1 = center + Offset(_stars[pair[0]].dx * scale, _stars[pair[0]].dy * scale);
      final p2 = center + Offset(_stars[pair[1]].dx * scale, _stars[pair[1]].dy * scale);
      canvas.drawLine(p1, p2, linePaint);
    }

    final starPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.65)
      ..style = PaintingStyle.fill;

    final glowPaint = Paint()
      ..color = starColor.withValues(alpha: 0.35)
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5);

    for (int i = 0; i < _stars.length; i++) {
      final pt = center + Offset(_stars[i].dx * scale, _stars[i].dy * scale);
      final r = (i % 3 == 0) ? 2.2 : 1.3;
      canvas.drawCircle(pt, r * 1.8, glowPaint);
      canvas.drawCircle(pt, r, starPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CelestialConstellationPainter oldDelegate) =>
      oldDelegate.starColor != starColor;
}

// --- PERIMETER DOTTED DIAL & BEZEL PROGRESS ARC PAINTER ---

class PerimeterDottedDialPainter extends CustomPainter {
  final double progress;
  final Color themeColor;

  PerimeterDottedDialPainter({required this.progress, required this.themeColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.415;

    // 60 Concentric Dial Micro-Dots
    final dotPaint = Paint()..style = PaintingStyle.fill;
    for (int i = 0; i < 60; i++) {
      final angle = (i * 6.0) * math.pi / 180.0 - math.pi / 2;
      final isCardinal = (i % 15 == 0);
      final isSubCardinal = (i % 5 == 0);

      final pt = Offset(
        center.dx + radius * math.cos(angle),
        center.dy + radius * math.sin(angle),
      );

      if (isCardinal) {
        dotPaint.color = Colors.white.withValues(alpha: 0.75);
        canvas.drawCircle(pt, 2.2, dotPaint);
      } else if (isSubCardinal) {
        dotPaint.color = Colors.white.withValues(alpha: 0.42);
        canvas.drawCircle(pt, 1.6, dotPaint);
      } else {
        dotPaint.color = Colors.white.withValues(alpha: 0.20);
        canvas.drawCircle(pt, 1.1, dotPaint);
      }
    }

    // Outer Top Bezel Progression Arc
    final outerRadius = size.width * 0.465;
    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..color = Colors.white.withValues(alpha: 0.85);

    const sweepAngle = math.pi * 0.46;
    const startAngle = -math.pi * 0.73;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: outerRadius),
      startAngle,
      sweepAngle,
      false,
      arcPaint,
    );
  }

  @override
  bool shouldRepaint(covariant PerimeterDottedDialPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.themeColor != themeColor;
}

// --- ETHEREAL MULTI-RIBBON SILK HARMONIC WAVE PAINTER ---

class EtherealSilkRibbonPainter extends CustomPainter {
  final double animationProgress;
  final Color ribbonColor;

  EtherealSilkRibbonPainter({
    required this.animationProgress,
    required this.ribbonColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    const int strandCount = 18;
    final t = animationProgress * 2 * math.pi;

    // Draw the 18 harmonic wireframe silk strands
    for (int k = 0; k < strandCount; k++) {
      final kNorm = (k / (strandCount - 1)) - 0.5; // -0.5 to 0.5
      final phaseOffset = k * 0.14;
      final ampOffset = kNorm * 22.0;

      final path = Path();
      bool first = true;

      for (double x = 0; x <= w; x += 5) {
        final normX = x / w;
        final envelope = math.sin(normX * math.pi);

        // Strict integer harmonics (1*t, -1*t, 2*t): guaranteed 100% C-infinity continuous at cycle wrap
        final y = h * 0.69 +
            envelope * (
              ampOffset +
              math.sin(normX * 4.0 + t + phaseOffset) * (32.0 + kNorm * 12.0) +
              math.cos(normX * 6.0 - t + phaseOffset * 1.5) * (16.0 - kNorm * 8.0) +
              math.sin(normX * 8.0 + 2.0 * t) * 5.0
            );

        if (first) {
          path.moveTo(x, y);
          first = false;
        } else {
          path.lineTo(x, y);
        }
      }

      final alpha = ((0.75 - (kNorm.abs() * 0.8)).clamp(0.12, 0.85));
      final strandPaint = Paint()
        ..color = Color.lerp(Colors.white, ribbonColor, 0.45)!
            .withValues(alpha: alpha * 0.75)
        ..style = PaintingStyle.stroke
        ..strokeWidth = (k % 4 == 0) ? 1.3 : 0.85;

      canvas.drawPath(path, strandPaint);
    }
  }

  @override
  bool shouldRepaint(covariant EtherealSilkRibbonPainter oldDelegate) =>
      oldDelegate.animationProgress != animationProgress ||
      oldDelegate.ribbonColor != ribbonColor;
}

// --- CIRCULAR MACHINE VISION HUD & 3D BALL TRACKER PAINTER ---

class CircularVisionHudPainter extends CustomPainter {
  final List<Map<String, dynamic>> trackedBalls;
  final String colorMode;
  final double animationVal;

  CircularVisionHudPainter({
    required this.trackedBalls,
    required this.colorMode,
    required this.animationVal,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);

    // 1. Concentric Metric Calibration Rings (r = 50mm, 100mm, 150mm on paddle)
    final gridPaint = Paint()
      ..color = const Color(0xFF00E5FF).withValues(alpha: 0.18)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    final dashPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.22)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    canvas.drawCircle(center, size.width * 0.14, gridPaint); // ~50mm
    canvas.drawCircle(center, size.width * 0.28, gridPaint); // ~100mm
    canvas.drawCircle(center, size.width * 0.42, dashPaint); // ~150mm

    // Center Crosshairs
    canvas.drawLine(
      Offset(center.dx - 18, center.dy),
      Offset(center.dx + 18, center.dy),
      dashPaint,
    );
    canvas.drawLine(
      Offset(center.dx, center.dy - 18),
      Offset(center.dx, center.dy + 18),
      dashPaint,
    );

    // 2. Render each tracked ball overlay
    for (final b in trackedBalls) {
      final ballId = (b['id'] as num?)?.toInt() ?? 1;
      final u = (b['u'] as num?)?.toDouble() ?? center.dx;
      final v = (b['v'] as num?)?.toDouble() ?? center.dy;
      final radiusPx = (b['radius_px'] as num?)?.toDouble() ?? 24.0;
      final xMm = (b['x_mm'] as num?)?.toDouble() ?? 0.0;
      final yMm = (b['y_mm'] as num?)?.toDouble() ?? 0.0;
      final zMm = (b['z_mm'] as num?)?.toDouble() ?? 380.0;
      final vx = (b['vx_mps'] as num?)?.toDouble() ?? 0.0;
      final vy = (b['vy_mps'] as num?)?.toDouble() ?? 0.0;
      final vz = (b['vz_mps'] as num?)?.toDouble() ?? 0.0;
      final vMag = math.sqrt(vx * vx + vy * vy + vz * vz);

      // Distinct Neon Color Palette per Track ID
      final Color ballColor = _getBallColor(ballId, b['color_hex']);

      // Convert 640x480 frame coords to screen size coords
      final screenX = (u / 640.0) * size.width;
      final screenY = (v / 480.0) * size.height;
      final screenR = (radiusPx / 640.0) * size.width;

      final ballCenter = Offset(screenX, screenY);

      // A. Breadcrumb Motion Trails
      if (b['trail'] != null && b['trail'] is List) {
        final trailList = b['trail'] as List;
        if (trailList.length >= 2) {
          final trailPath = Path();
          bool first = true;
          for (final pt in trailList) {
            if (pt is List && pt.length >= 2) {
              final tx = ((pt[0] as num).toDouble() / 640.0) * size.width;
              final ty = ((pt[1] as num).toDouble() / 480.0) * size.height;
              if (first) {
                trailPath.moveTo(tx, ty);
                first = false;
              } else {
                trailPath.lineTo(tx, ty);
              }
            }
          }
          final trailPaint = Paint()
            ..color = ballColor.withValues(alpha: 0.6)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2.0;
          canvas.drawPath(trailPath, trailPaint);
        }
      }

      // B. Rotating Reticle Ring
      final reticlePaint = Paint()
        ..color = ballColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2;

      canvas.drawCircle(ballCenter, screenR + 6, reticlePaint);
      canvas.drawCircle(ballCenter, 3.5, Paint()..color = ballColor..style = PaintingStyle.fill);

      // Rotating Tick Marks
      final rot = (animationVal * 360.0 * 2.0) % 360.0;
      for (final deg in [0.0, 90.0, 180.0, 270.0]) {
        final rad = (rot + deg) * math.pi / 180.0;
        final pIn = Offset(
          ballCenter.dx + (screenR + 3) * math.cos(rad),
          ballCenter.dy + (screenR + 3) * math.sin(rad),
        );
        final pOut = Offset(
          ballCenter.dx + (screenR + 13) * math.cos(rad),
          ballCenter.dy + (screenR + 13) * math.sin(rad),
        );
        canvas.drawLine(pIn, pOut, reticlePaint);
      }

      // C. Dynamic Velocity Vector Arrow
      final arrowScale = 22.0;
      final arrowEnd = Offset(
        ballCenter.dx + (vx * arrowScale),
        ballCenter.dy + (vy * arrowScale),
      );
      if (vMag > 0.15) {
        final arrowPaint = Paint()
          ..color = ballColor
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4;
        canvas.drawLine(ballCenter, arrowEnd, arrowPaint);
        canvas.drawCircle(arrowEnd, 3.0, Paint()..color = ballColor..style = PaintingStyle.fill);
      }

      // D. Laser Leader Line to Holographic Callout Card
      final cardX = (ballCenter.dx + screenR + 24).clamp(30.0, size.width - 210.0);
      final cardY = (ballCenter.dy - screenR - 35).clamp(80.0, size.height - 180.0);
      final cardAnchor = Offset(cardX, cardY);

      final leaderPaint = Paint()
        ..color = ballColor.withValues(alpha: 0.85)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2;

      canvas.drawLine(
        Offset(ballCenter.dx + screenR + 4, ballCenter.dy),
        Offset(cardAnchor.dx, cardAnchor.dy + 16),
        leaderPaint,
      );
      canvas.drawCircle(Offset(cardAnchor.dx, cardAnchor.dy + 16), 2.5, Paint()..color = ballColor);

      // Card Background
      final cardRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cardAnchor.dx, cardAnchor.dy, 185, 62),
        const Radius.circular(10),
      );
      canvas.drawRRect(
        cardRect,
        Paint()..color = const Color(0xE0050D18)..style = PaintingStyle.fill,
      );
      canvas.drawRRect(
        cardRect,
        Paint()
          ..color = ballColor.withValues(alpha: 0.75)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2,
      );

      // Card Text
      final tpTitle = TextPainter(
        text: TextSpan(
          text: 'BALL #$ballId  |  Ø 40mm',
          style: TextStyle(
            color: ballColor,
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.0,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tpTitle.paint(canvas, Offset(cardAnchor.dx + 8, cardAnchor.dy + 6));

      final tpCoords = TextPainter(
        text: TextSpan(
          text: 'X:${xMm.toStringAsFixed(1)}mm  Y:${yMm.toStringAsFixed(1)}mm',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.4,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tpCoords.paint(canvas, Offset(cardAnchor.dx + 8, cardAnchor.dy + 24));

      final tpDepth = TextPainter(
        text: TextSpan(
          text: 'Z:${zMm.toStringAsFixed(1)}mm  •  V:${vMag.toStringAsFixed(1)}m/s',
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.85),
            fontSize: 11,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.4,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tpDepth.paint(canvas, Offset(cardAnchor.dx + 8, cardAnchor.dy + 42));
    }
  }

  Color _getBallColor(int id, dynamic hexVal) {
    if (hexVal != null && hexVal is String && hexVal.startsWith('#') && hexVal.length == 7) {
      try {
        return Color(int.parse(hexVal.replaceFirst('#', '0xFF')));
      } catch (_) {}
    }
    switch (id) {
      case 1:
        return const Color(0xFF00E5FF); // Cyber Cyan
      case 2:
        return const Color(0xFFF59E0B); // Solar Amber
      case 3:
        return const Color(0xFF10B981); // Acid Emerald
      case 4:
        return const Color(0xFFEC4899); // Electric Magenta
      default:
        return const Color(0xFF8B5CF6); // Ultra Violet
    }
  }

  @override
  bool shouldRepaint(covariant CircularVisionHudPainter oldDelegate) => true;
}


