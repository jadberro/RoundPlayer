import urllib.request
import json

data = json.dumps({"track_id": "8e32cc74e6cc"}).encode("utf-8")
req = urllib.request.Request("http://127.0.0.1:8000/api/hifi/play", data=data, headers={"Content-Type": "application/json"})
with urllib.request.urlopen(req) as resp:
    print(resp.read().decode())
