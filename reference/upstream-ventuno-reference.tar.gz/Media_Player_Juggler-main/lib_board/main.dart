import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BallisticJukeboxApp());
}

class BallisticJukeboxApp extends StatelessWidget {
  const BallisticJukeboxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ventuno Ballistic HUD',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const RoundHudScreen(),
    );
  }
}

class RoundHudScreen extends StatefulWidget {
  const RoundHudScreen({super.key});

  @override
  State<RoundHudScreen> createState() => _RoundHudScreenState();
}

class _RoundHudScreenState extends State<RoundHudScreen>
    with TickerProviderStateMixin {
  // 103 BPM Metronome Engine: 60.0 / 103.0 ~= 0.5825s per beat
  static const Duration beatPeriod = Duration(milliseconds: 583);

  late AnimationController _beatController;
  late AnimationController _waveController;

  // Search & Circular Keyboard State
  bool _isSearchOpen = false;
  String _searchQuery = '';
  final List<String> _searchResults = [];
  bool _isSearching = false;

  // Curated popular tracks for instant responsiveness
  static const List<String> _presetTracks = [
    'Daft Punk - Around the World',
    'Daft Punk - One More Time',
    'Daft Punk - Harder Better Faster',
    'Justice - D.A.N.C.E.',
    'Kraftwerk - Tour de France',
    'Aphex Twin - Selected Ambient Works',
    'The Chemical Brothers - Galvanize',
    'Pendulum - Propane Nightmares',
  ];

  @override
  void initState() {
    super.initState();

    _beatController = AnimationController(
      vsync: this,
      duration: beatPeriod,
    )..repeat();

    _waveController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
  }

  @override
  void dispose() {
    _beatController.dispose();
    _waveController.dispose();
    super.dispose();
  }

  void _onKeyTapped(String char) {
    setState(() {
      if (char == '⌫') {
        if (_searchQuery.isNotEmpty) {
          _searchQuery = _searchQuery.substring(0, _searchQuery.length - 1);
        }
      } else if (char == '␣') {
        _searchQuery += ' ';
      } else if (char == '↵') {
        _performSearch();
      } else {
        _searchQuery += char;
      }
      _updateLiveFilter();
    });
  }

  void _updateLiveFilter() {
    if (_searchQuery.isEmpty) {
      _searchResults.clear();
      return;
    }
    final q = _searchQuery.toLowerCase();
    _searchResults.clear();
    _searchResults.addAll(
      _presetTracks.where((track) => track.toLowerCase().contains(q)),
    );
    if (_searchResults.isEmpty) {
      _searchResults.add('Search YouTube for "$_searchQuery"');
    }
  }

  void _performSearch() {
    setState(() {
      _isSearching = true;
    });
    // Simulating search trigger / ready for mpv/yt-dlp playback integration
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _isSearchOpen = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final size = math.min(constraints.maxWidth, constraints.maxHeight);

          return Center(
            child: SizedBox(
              width: size,
              height: size,
              child: ClipOval(
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // 1. Deep Obsidian Pitch-Black Background
                    Container(color: Colors.black),

                    // Subtle radial depth gradient
                    Container(
                      decoration: const BoxDecoration(
                        gradient: RadialGradient(
                          center: Alignment.center,
                          radius: 0.96,
                          colors: [
                            Color(0xFF04060A),
                            Color(0xFF020306),
                            Colors.black,
                          ],
                          stops: [0.0, 0.70, 1.0],
                        ),
                      ),
                    ),

                    // 2. Liquid 360-Degree Silk Ribbon Loop
                    AnimatedBuilder(
                      animation: Listenable.merge([_beatController, _waveController]),
                      builder: (context, child) {
                        return CustomPaint(
                          painter: FullCircumferenceSilkPainter(
                            beatValue: _beatController.value,
                            wavePhase: _waveController.value * 2 * math.pi,
                          ),
                        );
                      },
                    ),

                    // 3. Top Perimeter Track & Thin Progress Arc
                    CustomPaint(
                      painter: CircumferenceProgressPainter(
                        progress: 0.42,
                      ),
                    ),

                    // 4. MAIN HUD ELEMENTS (when keyboard is closed)
                    if (!_isSearchOpen) ...[
                      // TOP: Enlarged YouTube Search Capsule (Touch to open circular keyboard)
                      Positioned(
                        top: size * 0.125,
                        left: 0,
                        right: 0,
                        child: Center(
                          child: GestureDetector(
                            onTap: () => setState(() => _isSearchOpen = true),
                            child: _buildYouTubeCapsule(),
                          ),
                        ),
                      ),

                      // MID-LEFT: 103 BPM + Phase Lock
                      Positioned(
                        left: size * 0.12,
                        top: size * 0.32,
                        child: _buildBpmTelemetry(),
                      ),

                      // BOTTOM: 3-RRS Ballistic Robot Complication
                      Positioned(
                        bottom: size * 0.11,
                        left: 0,
                        right: 0,
                        child: Center(
                          child: AnimatedBuilder(
                            animation: _beatController,
                            builder: (context, child) {
                              return _buildRobotComplication(_beatController.value);
                            },
                          ),
                        ),
                      ),
                    ],

                    // 5. CIRCULAR KEYBOARD & SEARCH OVERLAY (when search is open)
                    if (_isSearchOpen) _buildCircularSearchOverlay(size),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // --- WIDGET BUILDERS ---

  Widget _buildYouTubeCapsule() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFF0B101D).withOpacity(0.95),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withOpacity(0.25), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.8),
            blurRadius: 18,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: const Color(0xFF3B82F6).withOpacity(0.12),
            blurRadius: 20,
            spreadRadius: -2,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Red YouTube Badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3.5),
            decoration: BoxDecoration(
              color: const Color(0xFFFF0000),
              borderRadius: BorderRadius.circular(5),
            ),
            child: const Icon(Icons.play_arrow, color: Colors.white, size: 12),
          ),
          const SizedBox(width: 8),
          const Text(
            'YouTube',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.2,
              color: Colors.white,
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            width: 1,
            height: 14,
            color: Colors.white24,
          ),
          Text(
            _searchQuery.isEmpty ? 'Search music, video...' : _searchQuery,
            style: TextStyle(
              fontSize: 13,
              color: _searchQuery.isEmpty
                  ? Colors.white.withOpacity(0.45)
                  : Colors.white,
              fontWeight: _searchQuery.isEmpty ? FontWeight.normal : FontWeight.w600,
            ),
          ),
          const SizedBox(width: 10),
          Icon(Icons.search, size: 16, color: Colors.white.withOpacity(0.60)),
          const SizedBox(width: 8),
          Icon(Icons.mic, size: 16, color: Colors.white.withOpacity(0.60)),
        ],
      ),
    );
  }

  Widget _buildBpmTelemetry() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            const Text(
              '103',
              style: TextStyle(
                fontSize: 44,
                fontWeight: FontWeight.w300,
                letterSpacing: -1.0,
                color: Colors.white,
                shadows: [
                  Shadow(color: Colors.white24, blurRadius: 18),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Text(
              'BPM',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
                color: Colors.white.withOpacity(0.85),
              ),
            ),
          ],
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 7,
              height: 7,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF34D399),
                boxShadow: [
                  BoxShadow(color: Color(0xFF34D399), blurRadius: 8),
                ],
              ),
            ),
            const SizedBox(width: 7),
            Text(
              'PHASE LOCK',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
                color: Colors.white.withOpacity(0.65),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRobotComplication(double beatFraction) {
    final double ballOffset = -math.sin(beatFraction * math.pi) * 18.0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 56,
          height: 44,
          child: CustomPaint(
            painter: RobotPlatformPainter(ballOffset: ballOffset),
          ),
        ),
        const SizedBox(height: 3),
        RichText(
          text: TextSpan(
            style: TextStyle(
              fontSize: 12.5,
              letterSpacing: 1.2,
              color: Colors.white.withOpacity(0.75),
            ),
            children: const [
              TextSpan(text: 'Precision Impact: '),
              TextSpan(
                text: '41.6 CM',
                style: TextStyle(fontWeight: FontWeight.w700, color: Colors.white),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // --- CIRCULAR KEYBOARD & SEARCH OVERLAY ---
  Widget _buildCircularSearchOverlay(double size) {
    final center = size / 2;

    // Keys distributed radially along an ergonomic bottom-arc and side-arcs
    const row1 = ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'];
    const row2 = ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'];
    const row3 = ['Z', 'X', 'C', 'V', 'B', 'N', 'M'];

    return Stack(
      children: [
        // Frosted Dimmer
        Container(
          color: Colors.black.withOpacity(0.75),
        ),

        // Search Input Bar at upper center
        Positioned(
          top: size * 0.12,
          left: size * 0.15,
          right: size * 0.15,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF131929),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: Colors.white.withOpacity(0.3), width: 1.2),
            ),
            child: Row(
              children: [
                const Icon(Icons.search, color: Color(0xFFFF0000), size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _searchQuery.isEmpty ? 'Type to search...' : _searchQuery,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: _searchQuery.isEmpty ? Colors.white38 : Colors.white,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                GestureDetector(
                  onTap: () => setState(() => _isSearchOpen = false),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.12),
                    ),
                    child: const Icon(Icons.close, size: 16, color: Colors.white70),
                  ),
                ),
              ],
            ),
          ),
        ),

        // Live Suggestions List in center
        Positioned(
          top: size * 0.22,
          bottom: size * 0.44,
          left: size * 0.18,
          right: size * 0.18,
          child: _searchResults.isEmpty
              ? Center(
                  child: Text(
                    'Touch letters below to search YouTube',
                    style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 13),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  itemCount: _searchResults.length,
                  itemBuilder: (context, index) {
                    final item = _searchResults[index];
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _searchQuery = item;
                          _performSearch();
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.music_note, color: Colors.white54, size: 16),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                item,
                                style: const TextStyle(color: Colors.white, fontSize: 13),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),

        // Circular Radial Arc Keyboard placed along concentric circular tiers
        // Tier 1 (Outer Arc): QWERTYUIOP (from angle 145° down to 35°)
        ..._buildRadialArcRow(
          keys: row1,
          radius: size * 0.42,
          startAngleDeg: 148,
          endAngleDeg: 32,
          center: center,
          keySize: 34,
        ),

        // Tier 2 (Middle Arc): ASDFGHJKL (from angle 144° down to 36°)
        ..._buildRadialArcRow(
          keys: row2,
          radius: size * 0.34,
          startAngleDeg: 145,
          endAngleDeg: 35,
          center: center,
          keySize: 32,
        ),

        // Tier 3 (Inner Arc): ZXCVBNM + Backspace + Space + Enter
        ..._buildRadialArcRow(
          keys: ['⌫', ...row3, '␣', '↵'],
          radius: size * 0.26,
          startAngleDeg: 148,
          endAngleDeg: 32,
          center: center,
          keySize: 30,
        ),
      ],
    );
  }

  List<Widget> _buildRadialArcRow({
    required List<String> keys,
    required double radius,
    required double startAngleDeg,
    required double endAngleDeg,
    required double center,
    required double keySize,
  }) {
    final widgets = <Widget>[];
    final count = keys.length;
    final startRad = startAngleDeg * math.pi / 180.0;
    final endRad = endAngleDeg * math.pi / 180.0;
    final angleStep = count > 1 ? (endRad - startRad) / (count - 1) : 0.0;

    for (int i = 0; i < count; i++) {
      final angle = startRad + i * angleStep;
      // Screen coordinates: x = center + r * cos, y = center + r * sin
      final x = center + radius * math.cos(angle) - keySize / 2;
      final y = center + radius * math.sin(angle) - keySize / 2;
      final keyChar = keys[i];

      final isAction = keyChar == '⌫' || keyChar == '↵' || keyChar == '␣';

      widgets.add(
        Positioned(
          left: x,
          top: y,
          child: GestureDetector(
            onTap: () => _onKeyTapped(keyChar),
            child: Container(
              width: keySize,
              height: keySize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isAction
                    ? const Color(0xFF253350).withOpacity(0.95)
                    : const Color(0xFF141C2E).withOpacity(0.90),
                border: Border.all(
                  color: isAction
                      ? const Color(0xFF60A5FA).withOpacity(0.6)
                      : Colors.white.withOpacity(0.20),
                  width: 1.0,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 4,
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: Text(
                keyChar,
                style: TextStyle(
                  color: isAction ? const Color(0xFF93C5FD) : Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: keySize * 0.42,
                ),
              ),
            ),
          ),
        ),
      );
    }
    return widgets;
  }
}

// =============================================================================
// CUSTOM PAINTER 1: 360-Degree Continuous Silk Ribbon Loop
// =============================================================================
class FullCircumferenceSilkPainter extends CustomPainter {
  final double beatValue;
  final double wavePhase;

  FullCircumferenceSilkPainter({
    required this.beatValue,
    required this.wavePhase,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final baseRadius = size.width * 0.425;

    // Metronome beat impulse
    final beatPulse = math.exp(-beatValue * 4.5);

    const int strandCount = 38;
    const int steps = 180; // Smooth 2-degree step angular sweep

    for (int s = 0; s < strandCount; s++) {
      final double strandT = s / (strandCount - 1); // 0.0 to 1.0
      // Silk strands brightest near center of bundle, softer at margins
      final double strandWeight = math.sin(strandT * math.pi);
      final double alpha = (strandWeight * 0.52 + 0.08 + beatPulse * 0.12).clamp(0.0, 1.0);

      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.05
        ..isAntiAlias = true
        ..color = Color.lerp(
          Colors.white,
          const Color(0xFFBCE0FD),
          strandT * 0.45,
        )!.withOpacity(alpha);

      final path = Path();

      for (int i = 0; i <= steps; i++) {
        final double theta = (i / steps) * 2 * math.pi;

        // Billowing envelope: thicker billowing veil on the right (theta ~ 0)
        // smoother tighter band at top and bottom
        final double envelope = 1.0 + 0.45 * math.cos(theta);

        // Radial offset of each individual strand within the ribbon width
        final double ribbonSpan = (24.0 + 38.0 * envelope);
        final double rStrand = (strandT - 0.5) * ribbonSpan;

        // Multi-frequency harmonic silk undulating folds
        // Integer multipliers ensure perfect C2 periodic loop around 360 degrees
        final double fold1 = math.sin(4 * theta + wavePhase + strandT * 3.0) * (9.0 * envelope);
        final double fold2 = math.cos(8 * theta - wavePhase * 1.2 - strandT * 2.0) * (4.5 * envelope);
        final double fold3 = math.sin(12 * theta + wavePhase * 0.7) * (2.2 * envelope);

        final double r = baseRadius + rStrand + fold1 + fold2 + fold3;
        final double px = cx + r * math.cos(theta);
        final double py = cy + r * math.sin(theta);

        if (i == 0) {
          path.moveTo(px, py);
        } else {
          path.lineTo(px, py);
        }
      }

      path.close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant FullCircumferenceSilkPainter oldDelegate) {
    return oldDelegate.beatValue != beatValue || oldDelegate.wavePhase != wavePhase;
  }
}

// =============================================================================
// CUSTOM PAINTER 2: Circumference Outer Progress Arc
// =============================================================================
class CircumferenceProgressPainter extends CustomPainter {
  final double progress;
  CircumferenceProgressPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r = size.width * 0.485;

    // Outer Track
    final trackPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..color = Colors.white.withOpacity(0.08);
    canvas.drawCircle(Offset(cx, cy), r, trackPaint);

    // Glowing Top Arc (-135° to -45°)
    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..color = Colors.white.withOpacity(0.85);

    canvas.drawArc(
      Rect.fromCircle(center: Offset(cx, cy), radius: r),
      -math.pi * 0.75,
      math.pi * 0.50 * progress,
      false,
      arcPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CircumferenceProgressPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// =============================================================================
// CUSTOM PAINTER 3: 3-RRS Ballistic Robot Kinematic Platform
// =============================================================================
class RobotPlatformPainter extends CustomPainter {
  final double ballOffset;
  RobotPlatformPainter({required this.ballOffset});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height - 10;

    final linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round
      ..color = Colors.white.withOpacity(0.88);

    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.white.withOpacity(0.92);

    // Platform Base
    final baseRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(cx, cy), width: 28, height: 6.5),
      const Radius.circular(2),
    );
    canvas.drawRRect(baseRect, linePaint);
    canvas.drawCircle(Offset(cx, cy), 1.6, fillPaint);

    // Linkage Arms
    canvas.drawLine(Offset(cx - 9, cy - 3), Offset(cx - 17, cy - 14), linePaint);
    canvas.drawLine(Offset(cx + 9, cy - 3), Offset(cx + 17, cy - 14), linePaint);

    // Radiating trajectory dots
    final pipPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.white.withOpacity(0.40);
    canvas.drawCircle(Offset(cx - 10, cy - 18), 1.2, pipPaint);
    canvas.drawCircle(Offset(cx + 10, cy - 18), 1.2, pipPaint);
    canvas.drawCircle(Offset(cx, cy - 24), 1.4, pipPaint);

    // Bouncing Ball with Soft Glow
    final ballCenter = Offset(cx, cy - 20 + ballOffset);
    final ballGlow = Paint()
      ..color = Colors.white.withOpacity(0.40)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.5);
    canvas.drawCircle(ballCenter, 4.0, ballGlow);
    canvas.drawCircle(ballCenter, 3.2, fillPaint);
  }

  @override
  bool shouldRepaint(covariant RobotPlatformPainter oldDelegate) =>
      oldDelegate.ballOffset != ballOffset;
}
