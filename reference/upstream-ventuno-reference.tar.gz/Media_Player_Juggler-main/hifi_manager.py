#!/usr/bin/env python3
"""
3-RRS Ballistic Juggler - Hi-Fi Lossless Music Manager & On-Demand LRU Cache
Expanded 10 GB cache ceiling with 8 GB pruning trigger threshold.
Permanent local album artwork caching in /data/hifi_music/covers/.
Re-entrant lock (RLock) to prevent deadlocks.
Auto-locates local files on disk for instant zero-delay playback.
"""

import os
import sys
import json
import time
import shutil
import hashlib
import requests
import subprocess
import threading
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict
import numpy as np

# Storage & Directory Constants
HIFI_DIR = "/data/hifi_music"
CACHE_DIR = "/data/hifi_cache"
COVERS_DIR = os.path.join(HIFI_DIR, "covers")
MANIFEST_FILE = os.path.join(CACHE_DIR, "manifest.json")
CATALOG_FILE = os.path.join(HIFI_DIR, "remote_library.json")
LOCAL_LEGACY_CACHE = os.path.join(HIFI_DIR, "library_cache.json")

# Cache Limits (10 GB Maximum, 8 GB Pruning Trigger Watermark)
CACHE_MAX_BYTES = 10 * 1024 * 1024 * 1024       # 10.0 GB
PRUNE_TRIGGER_BYTES = 8 * 1024 * 1024 * 1024    # 8.0 GB High Watermark
PRUNE_TARGET_BYTES = int(6.5 * 1024 * 1024 * 1024)  # 6.5 GB Safe Headroom

GOOGLE_DRIVE_FOLDER_ID = "YOUR_PUBLIC_FOLDER_ID"
AUDIO_EXTS = {".flac", ".wav", ".alac", ".aiff", ".m4a", ".mp3", ".ogg", ".dsf", ".dff"}
COVER_NAMES = ["cover.jpg", "cover.png", "folder.jpg", "folder.png", "front.jpg", "front.png"]

_lock = threading.RLock()

def init_dirs():
    """Ensure directory hierarchy exists."""
    os.makedirs(HIFI_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)
    os.makedirs(COVERS_DIR, exist_ok=True)

def load_manifest() -> Dict[str, Any]:
    """Loads cache manifest tracking file access and sizes."""
    if os.path.isfile(MANIFEST_FILE):
        try:
            with open(MANIFEST_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_manifest(manifest: Dict[str, Any]):
    """Saves cache manifest atomically."""
    temp_file = MANIFEST_FILE + ".tmp"
    try:
        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)
        shutil.move(temp_file, MANIFEST_FILE)
    except Exception as e:
        print(f"[Manifest Write Error] {e}")

def get_cache_stats() -> Dict[str, Any]:
    """Returns current cache disk metrics."""
    with _lock:
        manifest = load_manifest()
        total_bytes = 0
        file_count = 0
        
        if os.path.isdir(CACHE_DIR):
            for root, _, files in os.walk(CACHE_DIR):
                for f in files:
                    if f.endswith(".json") or f.endswith(".tmp"):
                        continue
                    fp = os.path.join(root, f)
                    try:
                        total_bytes += os.path.getsize(fp)
                        file_count += 1
                    except Exception:
                        pass

        return {
            "total_bytes": total_bytes,
            "total_mb": round(total_bytes / (1024 * 1024), 2),
            "total_gb": round(total_bytes / (1024 * 1024 * 1024), 3),
            "max_gb": round(CACHE_MAX_BYTES / (1024 * 1024 * 1024), 1),
            "trigger_gb": round(PRUNE_TRIGGER_BYTES / (1024 * 1024 * 1024), 1),
            "target_gb": round(PRUNE_TARGET_BYTES / (1024 * 1024 * 1024), 1),
            "cached_tracks": len([k for k in manifest.keys() if not k.startswith("_")]),
            "file_count": file_count,
        }

def check_and_prune_cache(exclude_track_id: Optional[str] = None):
    """
    LRU Eviction: If total cache >= 8.0 GB, prunes least recently accessed
    files until cache drops below 6.5 GB. Currently active track is preserved.
    """
    with _lock:
        stats = get_cache_stats()
        current_bytes = stats["total_bytes"]
        if current_bytes < PRUNE_TRIGGER_BYTES:
            return

        print(f"[Cache Prune] Cache is {stats['total_gb']:.2f} GB >= 8.0 GB limit. Pruning oldest tracks...")
        manifest = load_manifest()
        
        items = []
        for tid, data in manifest.items():
            if tid == exclude_track_id or not isinstance(data, dict):
                continue
            items.append((tid, data.get("last_accessed", 0), data.get("file_path"), data.get("beats_path")))
        
        items.sort(key=lambda x: x[1])
        
        bytes_freed = 0
        for tid, _, fpath, bpath in items:
            if current_bytes - bytes_freed <= PRUNE_TARGET_BYTES:
                break
            
            if fpath and os.path.isfile(fpath) and fpath.startswith(CACHE_DIR):
                try:
                    fsize = os.path.getsize(fpath)
                    os.remove(fpath)
                    bytes_freed += fsize
                    print(f"  [Pruned] {os.path.basename(fpath)} ({fsize / (1024*1024):.1f} MB)")
                except Exception as e:
                    print(f"  [Prune Error] {fpath}: {e}")
                    
            if bpath and os.path.isfile(bpath) and bpath.startswith(CACHE_DIR):
                try:
                    os.remove(bpath)
                except Exception:
                    pass
                    
            del manifest[tid]

        save_manifest(manifest)
        print(f"[Cache Prune] Freed {bytes_freed / (1024*1024):.1f} MB.")

def locate_local_track_file(track: Dict[str, Any]) -> Optional[str]:
    """Finds if this track exists locally in /data/hifi_cache or /data/hifi_music."""
    clean_id = track.get("track_id", "")
    # 1. Direct cache check
    for ext in AUDIO_EXTS:
        target = os.path.join(CACHE_DIR, f"{clean_id}{ext}")
        if os.path.isfile(target) and os.path.getsize(target) > 1000:
            return target

    # 2. Check track's stored file_path
    fp = track.get("file_path")
    if fp and os.path.isfile(fp) and os.path.getsize(fp) > 1000:
        return fp

    # 3. Check relative path in HIFI_DIR and HIFI_DIR/HIFI
    rel = track.get("rel_path")
    if rel:
        for prefix in [HIFI_DIR, os.path.join(HIFI_DIR, "HIFI")]:
            c = os.path.join(prefix, rel)
            if os.path.isfile(c) and os.path.getsize(c) > 1000:
                return c

    # 4. Match by file_name inside artist/album folder
    fname = track.get("file_name")
    artist = track.get("artist")
    album = track.get("album")
    if fname and artist and album:
        for base in [HIFI_DIR, os.path.join(HIFI_DIR, "HIFI")]:
            for album_folder in [album, album.split(" - ")[-1] if " - " in album else album]:
                candidate = os.path.join(base, artist, album_folder, fname)
                if os.path.isfile(candidate) and os.path.getsize(candidate) > 1000:
                    return candidate

    return None

def is_track_cached(track_id: str) -> bool:
    """Checks if audio file exists locally and is non-empty."""
    clean_id = track_id.replace("hifi_", "")
    track = find_track_by_id(clean_id)
    if track:
        local = locate_local_track_file(track)
        if local:
            return True
    return False

def get_track_file_path(track_id: str) -> Optional[str]:
    """Returns local path to audio file if available."""
    clean_id = track_id.replace("hifi_", "")
    track = find_track_by_id(clean_id)
    if track:
        return locate_local_track_file(track)
    return None

def fetch_cover_from_itunes(artist: str, album: str, dest_path: str) -> bool:
    """Queries iTunes Search API to fetch 600x600 album artwork."""
    try:
        clean_album = album.split(" - ")[-1] if " - " in album else album
        clean_album = clean_album.replace("(deluxe edition)", "").replace("(Deluxe)", "").strip()
        query = f"{artist} {clean_album}"
        url = f"https://itunes.apple.com/search?term={requests.utils.quote(query)}&entity=album&limit=3"
        resp = requests.get(url, timeout=8)
        if resp.status_code == 200:
            data = resp.json()
            results = data.get("results", [])
            if results:
                art_url = results[0].get("artworkUrl100", "").replace("100x100bb.jpg", "600x600bb.jpg")
                if art_url:
                    img_resp = requests.get(art_url, timeout=10)
                    if img_resp.status_code == 200 and len(img_resp.content) > 1024:
                        with open(dest_path, "wb") as f:
                            f.write(img_resp.content)
                        return True
    except Exception as e:
        print(f"  [Art Fetch Error] {artist} - {album}: {e}")
    return False

def sync_album_art():
    """Permanent local collection of all album covers into COVERS_DIR."""
    init_dirs()
    print("[Album Art] Scanning and permanently indexing album artwork...")
    
    for root, dirs, files in os.walk(HIFI_DIR):
        if root.startswith(COVERS_DIR) or root.startswith(CACHE_DIR):
            continue
        rel = os.path.relpath(root, HIFI_DIR)
        parts = [p for p in rel.split(os.sep) if p and p != "HIFI"]
        if len(parts) >= 2:
            artist = parts[0]
            album = " - ".join(parts[1:])
            key = f"{artist}_{album}".replace("/", "_").replace("\\", "_")
            dest = os.path.join(COVERS_DIR, f"{key}.jpg")
            
            if not os.path.isfile(dest):
                for f in files:
                    if f.lower() in COVER_NAMES:
                        src = os.path.join(root, f)
                        try:
                            shutil.copy2(src, dest)
                            break
                        except Exception:
                            pass
                            
def find_cover_gdrive_id_by_key(key: str) -> Optional[str]:
    """Finds Google Drive file ID for an album cover by artist_album key."""
    catalog = load_raw_catalog()
    for a in catalog.get("artists", []):
        artist = a["name"]
        for alb in a.get("albums", []):
            album = alb["name"]
            curr_key = f"{artist}_{album}".replace("/", "_").replace("\\", "_")
            if curr_key == key:
                return alb.get("cover_gdrive_id")
    return None


def get_or_create_beats(filepath: str) -> Dict[str, Any]:
    """Generates Aubio beat onset timestamps and BPM for rhythmic synchronization."""
    beats_path = filepath + ".beats.npy"
    if os.path.isfile(beats_path):
        try:
            beats = np.load(beats_path).tolist()
            if len(beats) > 1:
                diffs = np.diff(beats)
                median_interval = np.median(diffs)
                bpm = round(60.0 / median_interval, 1) if median_interval > 0 else 120.0
            else:
                bpm = 120.0
            return {"beats": beats, "bpm": bpm, "count": len(beats)}
        except Exception:
            pass

    try:
        cmd = ["aubioonset", "-i", filepath, "-t", "0.3"]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if res.returncode == 0:
            lines = res.stdout.strip().splitlines()
            beats = [float(line.strip()) for line in lines if line.strip()]
            np.save(beats_path, np.array(beats, dtype=np.float32))
            if len(beats) > 1:
                diffs = np.diff(beats)
                median_interval = np.median(diffs)
                bpm = round(60.0 / median_interval, 1) if median_interval > 0 else 120.0
            else:
                bpm = 120.0
            return {"beats": beats, "bpm": bpm, "count": len(beats)}
    except Exception as e:
        print(f"[Aubio Error] {filepath}: {e}")

    return {"beats": [], "bpm": 120.0, "count": 0}

def ensure_track_cached(track_id: str, progress_callback=None) -> Dict[str, Any]:
    """
    Ensures track is downloaded and ready to play.
    First checks if file already exists anywhere locally on disk.
    If not, downloads on-demand from Google Drive direct download URL.
    """
    track = find_track_by_id(track_id)
    if not track:
        raise ValueError(f"Track {track_id} not found in catalog")

    clean_id = track["track_id"]
    local_file = locate_local_track_file(track)

    # 1. If already locally present on disk, use it immediately
    if local_file and os.path.isfile(local_file) and os.path.getsize(local_file) > 1000:
        with _lock:
            manifest = load_manifest()
            manifest[clean_id] = {
                "last_accessed": time.time(),
                "size_bytes": os.path.getsize(local_file),
                "file_path": local_file,
                "beats_path": local_file + ".beats.npy"
            }
            save_manifest(manifest)
        return {
            "cached": True,
            "file_path": local_file,
            "track_id": clean_id,
            "beats": get_or_create_beats(local_file)
        }

    # 2. Download on-demand from Google Drive
    ext = os.path.splitext(track.get("file_name") or track.get("rel_path") or ".flac")[1].lower()
    if ext not in AUDIO_EXTS:
        ext = ".flac"
    cached_dest = os.path.join(CACHE_DIR, f"{clean_id}{ext}")
    part_dest = cached_dest + ".part"

    file_id = track.get("gdrive_file_id") or track.get("file_id")
    if not file_id:
        raise ValueError(f"No Google Drive file ID available for track {track_id}")

    download_url = f"https://drive.usercontent.google.com/download?id={file_id}&export=download"
    print(f"[On-Demand Download] Downloading {track['title']} ({track['artist']}) from {download_url}...")

    sess = requests.Session()
    sess.headers.update({
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    })

    with sess.get(download_url, stream=True, timeout=60) as resp:
        resp.raise_for_status()
        total_len = int(resp.headers.get("content-length", 0))
        downloaded = 0
        with open(part_dest, "wb") as f:
            for chunk in resp.iter_content(chunk_size=512 * 1024):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback:
                        progress_callback(downloaded, total_len)

    if os.path.isfile(part_dest) and os.path.getsize(part_dest) > 1000:
        shutil.move(part_dest, cached_dest)
        print(f"[On-Demand Download] Saved {cached_dest} ({os.path.getsize(cached_dest)/(1024*1024):.1f} MB)")
    else:
        raise RuntimeError(f"Download failed or empty file for {track_id}")

    beats = get_or_create_beats(cached_dest)

    with _lock:
        manifest = load_manifest()
        manifest[clean_id] = {
            "last_accessed": time.time(),
            "size_bytes": os.path.getsize(cached_dest),
            "file_path": cached_dest,
            "beats_path": cached_dest + ".beats.npy"
        }
        save_manifest(manifest)

    # Prune if over watermark
    check_and_prune_cache(exclude_track_id=clean_id)

    return {
        "cached": True,
        "file_path": cached_dest,
        "track_id": clean_id,
        "beats": beats
    }

def trigger_background_precache(track_id: str):
    """Asynchronously pre-downloads upcoming track in low-priority background thread."""
    if not track_id:
        return
    clean_id = track_id.replace("hifi_", "")
    if is_track_cached(clean_id):
        return
    def _worker():
        try:
            print(f"[HiFi Preloader] Pre-caching upcoming track: {clean_id}")
            ensure_track_cached(clean_id)
            print(f"[HiFi Preloader] Successfully pre-cached: {clean_id}")
        except Exception as e:
            print(f"[HiFi Preloader] Pre-cache error for {clean_id}: {e}")
    t = threading.Thread(target=_worker, daemon=True, name=f"precache_{clean_id}")
    t.start()

def load_raw_catalog() -> Dict[str, Any]:
    """Loads either remote_library.json or library_cache.json."""
    for p in [CATALOG_FILE, LOCAL_LEGACY_CACHE]:
        if os.path.isfile(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    return {"artists": [], "total_tracks": 0, "total_albums": 0, "total_artists": 0}

def scan_library(force: bool = False) -> Dict[str, Any]:
    """
    Returns the full hierarchical catalog with `is_cached` status annotated on each track
    and guaranteed permanent local album covers.
    """
    catalog = load_raw_catalog()
    
    for artist in catalog.get("artists", []):
        for album in artist.get("albums", []):
            artist_name = artist["name"]
            album_name = album["name"]
            key = f"{artist_name}_{album_name}".replace("/", "_").replace("\\", "_")
            album["cover_rel"] = f"covers/{key}.jpg"
            
            for track in album.get("tracks", []):
                local = locate_local_track_file(track)
                track["is_cached"] = bool(local is not None)
                if local:
                    track["file_path"] = local

    return catalog

def find_track_by_id(track_id: str) -> Optional[Dict[str, Any]]:
    """Looks up track metadata by track_id from cached catalog."""
    clean_id = track_id.replace("hifi_", "")
    catalog = load_raw_catalog()
    for artist in catalog.get("artists", []):
        for album in artist.get("albums", []):
            for track in album.get("tracks", []):
                if track.get("track_id") == clean_id or track.get("id") == clean_id:
                    artist_name = artist["name"]
                    album_name = album["name"]
                    key = f"{artist_name}_{album_name}".replace("/", "_").replace("\\", "_")
                    track["cover_rel"] = f"covers/{key}.jpg"
                    track["cover_path"] = os.path.join(COVERS_DIR, f"{key}.jpg")
                    local = locate_local_track_file(track)
                    if local:
                        track["file_path"] = local
                        track["is_cached"] = True
                    else:
                        track["is_cached"] = False
                    return track
    return None

def get_flat_tracks() -> List[Dict[str, Any]]:
    """Returns a flattened list of all tracks across artists and albums."""
    catalog = load_raw_catalog()
    flat = []
    for artist in catalog.get("artists", []):
        artist_name = artist.get("name", "Unknown Artist")
        for album in artist.get("albums", []):
            album_name = album.get("name", "Unknown Album")
            for track in album.get("tracks", []):
                t = dict(track)
                t["artist"] = artist_name
                t["album"] = album_name
                flat.append(t)
    return flat

def get_album_tracks_for_track(track_id: str) -> Tuple[List[Dict[str, Any]], int]:
    """
    Finds the album that contains track_id and returns:
    (album_tracks, current_track_index_in_album)
    """
    clean_id = track_id.replace("hifi_", "")
    catalog = load_raw_catalog()
    for artist in catalog.get("artists", []):
        artist_name = artist.get("name", "Unknown Artist")
        for album in artist.get("albums", []):
            album_name = album.get("name", "Unknown Album")
            tracks = album.get("tracks", [])
            for idx, t in enumerate(tracks):
                if t.get("track_id") == clean_id or t.get("id") == clean_id:
                    enriched = []
                    for item in tracks:
                        c = dict(item)
                        c["artist"] = artist_name
                        c["album"] = album_name
                        c["cover_key"] = f"{artist_name}_{album_name}".replace("/", "_").replace("\\", "_")
                        enriched.append(c)
                    return enriched, idx
    return [], -1

def search_library(query: str, limit: int = 50) -> List[Dict[str, Any]]:
    """
    Fast ranked search across all Hi-Fi artists, albums, and track titles.
    Returns enriched track items with cover art URLs and cache status.
    """
    catalog = scan_library()
    q = (query or "").strip().lower()
    matches = []

    for artist in catalog.get("artists", []):
        artist_name = artist.get("name", "")
        a_low = artist_name.lower()
        for album in artist.get("albums", []):
            album_name = album.get("name", "")
            alb_low = album_name.lower()
            key = f"{artist_name}_{album_name}".replace("/", "_").replace("\\", "_")
            cover_url = f"/api/hifi/cover?key={key}"
            cover_rel = f"covers/{key}.jpg"

            for track in album.get("tracks", []):
                t_title = track.get("title", "")
                t_low = t_title.lower()
                f_name = track.get("file_name", "").lower()

                # If query is empty, return initial catalog tracks
                if not q:
                    item = dict(track)
                    item["artist"] = artist_name
                    item["album"] = album_name
                    item["key"] = key
                    item["cover_rel"] = cover_rel
                    item["cover_url"] = cover_url
                    matches.append(item)
                    if len(matches) >= limit:
                        return matches
                    continue

                # Check match priority
                priority = None
                if q == t_low:
                    priority = 1
                elif t_low.startswith(q):
                    priority = 2
                elif q in t_low:
                    priority = 3
                elif q == a_low or a_low.startswith(q):
                    priority = 4
                elif q in a_low:
                    priority = 5
                elif q in alb_low:
                    priority = 6
                elif q in f_name:
                    priority = 7

                if priority is not None:
                    item = dict(track)
                    item["artist"] = artist_name
                    item["album"] = album_name
                    item["key"] = key
                    item["cover_rel"] = cover_rel
                    item["cover_url"] = cover_url
                    item["_priority"] = priority
                    matches.append(item)

    if q:
        matches.sort(key=lambda x: (x.get("_priority", 99), x.get("artist", "").lower(), x.get("title", "").lower()))
        for m in matches:
            m.pop("_priority", None)

    return matches[:limit]

if __name__ == "__main__":
    init_dirs()
    print("[Hi-Fi Manager] Synchronizing permanent covers...")
    sync_album_art()
    stats = get_cache_stats()
    print(f"[Hi-Fi Manager] Cache Status: {stats['total_mb']} MB / {stats['max_gb']} GB (Prune Trigger: {stats['trigger_gb']} GB)")
