import os
import json
import asyncio
import subprocess
import time
from datetime import datetime
from typing import List, Dict, Optional

import numpy as np
import aubio
import yt_dlp
import ytmusicapi
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import threading
import colorsys
from PIL import Image
from pydantic import BaseModel

app = FastAPI(title="Ballistic Music Juggler Media Daemon")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

CACHE_DIR = "/data/juggler_cache"
TEMP_DIR = "/tmp/juggler_temp"
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)

class Track(BaseModel):
    video_id: str
    title: str
    artist: str
    duration: Optional[str] = "0:00"
    thumbnail_url: str
    is_cached: bool

class CacheStatus(BaseModel):
    status: str
    progress: Optional[float] = None
    percent: Optional[int] = 0
    title: Optional[str] = None
    artist: Optional[str] = None
    error: Optional[str] = None

class BeatInfo(BaseModel):
    bpm: float
    beat_count: int
    beats: List[float]

cache_tasks: Dict[str, Dict] = {}
caching_lock = threading.Lock()
current_state = {
    "active_video_id": None,
    "current_bpm": 103.0,
    "beat_period_s": 60.0 / 103.0,
    "beats": np.array([])
}

def is_h264_aac(file_path: str):
    try:
        p = subprocess.run([
            'ffprobe', '-v', 'error', '-show_entries', 'stream=codec_name',
            '-of', 'default=noprint_wrappers=1:nokey=1', file_path
        ], capture_output=True, text=True, timeout=10)
        codecs = p.stdout.split()
        has_h264 = 'h264' in codecs
        has_audio = any(c in codecs for c in ['aac', 'mp3', 'm4a', 'flac'])
        return has_h264, has_audio
    except Exception:
        return False, False

def extract_dominant_color(video_path: str) -> str:
    tmp_img = os.path.join(TEMP_DIR, f"thumb_{int(time.time()*1000)}.jpg")
    try:
        subprocess.run([
            'ffmpeg', '-y', '-ss', '00:00:08', '-i', video_path,
            '-vframes', '1', '-vf', 'scale=64:64', tmp_img
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        if not os.path.exists(tmp_img):
            return '#00E5FF'
        im = Image.open(tmp_img).convert('RGB')
        colors = im.getcolors(64 * 64) or []
        vibrant_candidates = []
        for count, (r, g, b) in colors:
            h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            if v > 0.20 and s > 0.15:
                score = count * (s ** 1.5) * v
                vibrant_candidates.append((score, h, s, v))
        if os.path.exists(tmp_img):
            os.remove(tmp_img)
        if vibrant_candidates:
            vibrant_candidates.sort(reverse=True, key=lambda x: x[0])
            _, h, s, v = vibrant_candidates[0]
            # Boost to vivid neon glow for circular LCD HUD
            s = max(s, 0.70)
            v = max(v, 0.85)
            r, g, b = colorsys.hsv_to_rgb(h, s, v)
            return f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
    except Exception as e:
        print(f"Color extract error: {e}")
        if os.path.exists(tmp_img):
            os.remove(tmp_img)
    return '#00E5FF'

def get_track_dir(video_id: str) -> str:
    return os.path.join(CACHE_DIR, video_id)

def get_metadata_path(video_id: str) -> str:
    return os.path.join(get_track_dir(video_id), "metadata.json")

def get_video_path(video_id: str) -> str:
    return os.path.join(get_track_dir(video_id), "video.mp4")

def get_audio_path(video_id: str) -> str:
    return os.path.join(get_track_dir(video_id), "audio.wav")

def get_beats_path(video_id: str) -> str:
    return os.path.join(get_track_dir(video_id), "beats.npy")

def compute_beats_aubio(audio_path: str, win_s: int = 1024, hop_s: int = 512, samplerate: int = 48000):
    s = aubio.source(audio_path, samplerate, hop_s)
    tempo = aubio.tempo("default", win_s, hop_s, samplerate)
    beats = []
    total_frames = 0
    while True:
        samples, read = s()
        is_beat = tempo(samples)
        if is_beat:
            this_beat = tempo.get_last_s()
            beats.append(float(this_beat))
        total_frames += read
        if read < hop_s:
            break
    
    bpm = float(tempo.get_bpm())
    if bpm <= 0 and len(beats) > 1:
        diffs = np.diff(beats)
        median_interval = np.median(diffs)
        bpm = 60.0 / median_interval if median_interval > 0 else 103.0
    return beats, round(bpm, 1)

def make_progress_hook(video_id: str):
    def progress_hook(d):
        if d.get('status') == 'downloading':
            total = d.get('total_bytes') or d.get('total_bytes_estimate') or 0
            downloaded = d.get('downloaded_bytes') or 0
            if total > 0:
                fraction = min(max(downloaded / total, 0.0), 1.0)
                # Downloading accounts for 5% to 70% of total processing
                p = 0.05 + 0.65 * fraction
                pct = int(p * 100)
                if video_id in cache_tasks:
                    cache_tasks[video_id]["progress"] = round(p, 2)
                    cache_tasks[video_id]["percent"] = pct
                    cache_tasks[video_id]["status"] = "downloading"
    return progress_hook

def run_caching_worker(video_id: str):
    if os.path.exists(get_metadata_path(video_id)):
        cache_tasks[video_id] = {
            "status": "ready",
            "progress": 1.0,
            "percent": 100,
            "error": None
        }
        return

    with caching_lock:
        if os.path.exists(get_metadata_path(video_id)):
            cache_tasks[video_id] = {
                "status": "ready",
                "progress": 1.0,
                "percent": 100,
                "error": None
            }
            return

        track_dir = get_track_dir(video_id)
        os.makedirs(track_dir, exist_ok=True)
        temp_template = os.path.join(TEMP_DIR, f"{video_id}.%(ext)s")

        try:
            cache_tasks[video_id] = {
                "status": "downloading",
                "progress": 0.05,
                "percent": 5,
                "title": None,
                "artist": None,
                "error": None
            }
            ydl_opts = {
                'format': 'bestvideo[height<=1080][vcodec^=avc]+bestaudio[acodec^=mp4a]/bestvideo[height<=1080][vcodec^=avc]+bestaudio[ext=m4a]/bestvideo[height<=1080][vcodec^=avc]+bestaudio/bestvideo[height<=1080]+bestaudio/best[height<=1080]/best',
                'outtmpl': temp_template,
                'quiet': True,
                'no_warnings': True,
                'progress_hooks': [make_progress_hook(video_id)],
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=True)
                downloaded_ext = info.get('ext', 'mp4')
                raw_file = os.path.join(TEMP_DIR, f"{video_id}.{downloaded_ext}")
                title = info.get('title', 'Unknown Title')
                artist = info.get('artist') or info.get('uploader', 'Unknown Artist')
                duration = int(info.get('duration') or 0)
                cache_tasks[video_id]["title"] = title
                cache_tasks[video_id]["artist"] = artist

            cache_tasks[video_id]["status"] = "processing_1080p"
            cache_tasks[video_id]["progress"] = 0.75
            cache_tasks[video_id]["percent"] = 75

            video_out = get_video_path(video_id)
            audio_out = get_audio_path(video_id)
            beats_out = get_beats_path(video_id)
            meta_out = get_metadata_path(video_id)

            # 1. Instant lossless copy remux with faststart (takes <2 seconds at 160x speed)
            remux_cmd = ['ffmpeg', '-y', '-i', raw_file, '-c', 'copy', '-movflags', '+faststart', video_out]
            res = subprocess.run(remux_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if res.returncode != 0:
                # Fallback to fast transcode only if direct container copy fails
                subprocess.run([
                    'ffmpeg', '-y', '-i', raw_file,
                    '-vf', 'scale=-2:1080',
                    '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '23',
                    '-pix_fmt', 'yuv420p',
                    '-c:a', 'aac', '-b:a', '192k',
                    '-movflags', '+faststart', video_out
                ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

            # 2. Extract clean uncompressed 48kHz 16-bit PCM WAV for aubio / beat analysis
            extract_cmd = ['ffmpeg', '-y', '-i', raw_file]
            if duration > 240:
                extract_cmd += ['-t', '180']
            extract_cmd += ['-vn', '-acodec', 'pcm_s16le', '-ar', '48000', '-ac', '2', audio_out]
            subprocess.run(extract_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

            # 3. Beat analysis via aubio
            cache_tasks[video_id]["status"] = "analyzing_beats"
            cache_tasks[video_id]["progress"] = 0.88
            cache_tasks[video_id]["percent"] = 88
            beats, bpm = compute_beats_aubio(audio_out)
            np.save(beats_out, np.array(beats, dtype=np.float32))

            # 4. Extract prominent video neon color & save metadata JSON
            cache_tasks[video_id]["status"] = "color_and_metadata"
            cache_tasks[video_id]["progress"] = 0.96
            cache_tasks[video_id]["percent"] = 96
            dominant_color = extract_dominant_color(video_out)
            metadata = {
                "video_id": video_id,
                "title": title,
                "artist": artist,
                "duration_seconds": duration,
                "bpm": bpm,
                "beat_count": len(beats),
                "dominant_color": dominant_color,
                "cached_at": datetime.utcnow().isoformat(),
            }
            with open(meta_out, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2)

            # Clean up temporary raw download file
            if os.path.exists(raw_file):
                os.remove(raw_file)

            cache_tasks[video_id]["status"] = "ready"
            cache_tasks[video_id]["progress"] = 1.0
            cache_tasks[video_id]["percent"] = 100

        except Exception as e:
            print(f"Caching error for {video_id}: {e}")
            cache_tasks[video_id] = {"status": "error", "progress": 0.0, "percent": 0, "error": str(e)}

@app.get("/search", response_model=List[Track])
async def search(q: str):
    if not q.strip():
        return []
    try:
        yt = ytmusicapi.YTMusic()
        # Search for MUSIC VIDEOS first to guarantee real video footage instead of static album art
        video_results = yt.search(q, filter="videos")
        output = []
        for res in video_results[:8]:
            vid = res.get('videoId')
            if not vid:
                continue
            is_cached = os.path.exists(get_metadata_path(vid))
            thumbnails = res.get('thumbnails', [])
            thumb = thumbnails[-1]['url'] if thumbnails else ''
            artists = res.get('artists', [])
            artist_name = artists[0]['name'] if artists else 'Unknown'
            
            output.append(Track(
                video_id=vid,
                title=res.get('title', 'Unknown'),
                artist=artist_name,
                duration=res.get('duration', '0:00'),
                thumbnail_url=thumb,
                is_cached=is_cached
            ))

        # If videos is empty, fallback to songs
        if not output:
            song_results = yt.search(q, filter="songs")
            for res in song_results[:8]:
                vid = res.get('videoId')
                if not vid:
                    continue
                is_cached = os.path.exists(get_metadata_path(vid))
                thumbnails = res.get('thumbnails', [])
                thumb = thumbnails[-1]['url'] if thumbnails else ''
                artists = res.get('artists', [])
                artist_name = artists[0]['name'] if artists else 'Unknown'
                output.append(Track(
                    video_id=vid,
                    title=res.get('title', 'Unknown'),
                    artist=artist_name,
                    duration=res.get('duration', '0:00'),
                    thumbnail_url=thumb,
                    is_cached=is_cached
                ))
        return output
    except Exception as e:
        print(f"Error in ytmusicapi search: {e}")
        return []

@app.get("/tracks")
async def list_tracks():
    tracks = []
    if not os.path.exists(CACHE_DIR):
        return tracks
    for item in os.listdir(CACHE_DIR):
        meta_file = get_metadata_path(item)
        if os.path.isfile(meta_file):
            try:
                with open(meta_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    tracks.append(data)
            except Exception:
                continue
    return tracks

@app.post("/cache/{video_id}")
async def trigger_cache(video_id: str):
    if os.path.exists(get_metadata_path(video_id)):
        return {"status": "ready", "video_id": video_id}
    
    if video_id in cache_tasks and cache_tasks[video_id]["status"] not in ["error", "ready"]:
        return {"status": cache_tasks[video_id]["status"], "video_id": video_id}

    asyncio.get_event_loop().run_in_executor(None, run_caching_worker, video_id)
    return {"status": "downloading", "video_id": video_id}

@app.get("/cache/status/{video_id}", response_model=CacheStatus)
async def get_cache_status(video_id: str):
    if os.path.exists(get_metadata_path(video_id)):
        return CacheStatus(status="ready", progress=1.0, percent=100)
    if video_id in cache_tasks:
        task = cache_tasks[video_id]
        p = task.get("progress", 0.0)
        pct = task.get("percent")
        if pct is None and p is not None:
            pct = int(p * 100)
        return CacheStatus(
            status=task.get("status", "downloading"),
            progress=p,
            percent=pct,
            title=task.get("title"),
            artist=task.get("artist"),
            error=task.get("error")
        )
    return CacheStatus(status="missing", error="Track not cached", progress=0.0, percent=0)

@app.get("/media/{video_id}/video.mp4")
async def serve_video(video_id: str):
    path = get_video_path(video_id)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Video file not found")
    return FileResponse(path, media_type="video/mp4")

@app.get("/media/{video_id}/audio.wav")
async def serve_audio(video_id: str):
    path = get_audio_path(video_id)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Audio file not found")
    return FileResponse(path, media_type="audio/wav")

@app.get("/media/{video_id}/beats", response_model=BeatInfo)
async def serve_beats(video_id: str):
    beats_path = get_beats_path(video_id)
    meta_path = get_metadata_path(video_id)
    if not os.path.exists(beats_path) or not os.path.exists(meta_path):
        raise HTTPException(status_code=404, detail="Beats not found")
    
    beats_arr = np.load(beats_path).tolist()
    with open(meta_path, 'r', encoding='utf-8') as f:
        meta = json.load(f)
    return BeatInfo(bpm=meta.get("bpm", 103.0), beat_count=len(beats_arr), beats=beats_arr)

@app.get("/media/{video_id}/dominant_color")
async def get_color(video_id: str):
    meta_path = get_metadata_path(video_id)
    if os.path.exists(meta_path):
        with open(meta_path, 'r', encoding='utf-8') as f:
            meta = json.load(f)
        if "dominant_color" in meta:
            return {"color": meta["dominant_color"]}
        c = extract_dominant_color(get_video_path(video_id))
        meta["dominant_color"] = c
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(meta, f, indent=2)
        return {"color": c}
    return {"color": "#00E5FF"}

@app.post("/play/{video_id}")
async def set_active_track(video_id: str):
    meta_path = get_metadata_path(video_id)
    if os.path.exists(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                meta = json.load(f)
            
            # If dominant color not yet in metadata, compute and save it
            if "dominant_color" not in meta:
                meta["dominant_color"] = extract_dominant_color(get_video_path(video_id))
                with open(meta_path, 'w', encoding='utf-8') as f:
                    json.dump(meta, f, indent=2)

            bpm = float(meta.get("bpm", 103.0))
            current_state["active_video_id"] = video_id
            current_state["current_bpm"] = bpm
            current_state["beat_period_s"] = 60.0 / bpm if bpm > 0 else 60.0 / 103.0
            
            beats_path = get_beats_path(video_id)
            if os.path.exists(beats_path):
                current_state["beats"] = np.load(beats_path)
            else:
                current_state["beats"] = np.array([])
            
            return {
                "status": "playing",
                "video_id": video_id,
                "bpm": bpm,
                "dominant_color": meta.get("dominant_color", "#00E5FF"),
                "title": meta.get("title"),
                "artist": meta.get("artist")
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}
    return {"status": "not_cached", "video_id": video_id}

@app.websocket("/ws/telemetry")
async def websocket_telemetry(websocket: WebSocket):
    await websocket.accept()
    phase = 0.0
    try:
        while True:
            t_now = time.time()
            timestamp_us = int(t_now * 1e6)
            
            live_bpm = current_state.get("current_bpm", 103.0)
            beat_freq = live_bpm / 60.0
            phase = (t_now * beat_freq * 2.0 * np.pi) % (2.0 * np.pi)
            
            apex_height = 416.2 + 8.5 * np.sin(phase)
            phase_error = 0.4 * np.sin(phase * 0.75)
            pitch_deg = 1.2 * np.cos(phase * 0.5)
            roll_deg = -0.8 * np.sin(phase * 0.5)
            ball_state = "airborne" if np.sin(phase) > -0.6 else "contact"

            telemetry = {
                "timestamp_us": timestamp_us,
                "bpm": round(live_bpm),
                "phase_error_ms": round(phase_error, 2),
                "apex_height_mm": round(apex_height, 1),
                "ball_state": ball_state,
                "paddle_pitch_deg": round(pitch_deg, 2),
                "paddle_roll_deg": round(roll_deg, 2),
                "is_frozen": False
            }
            await websocket.send_json(telemetry)
            await asyncio.sleep(1.0 / 60.0)
    except (WebSocketDisconnect, Exception):
        pass

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
