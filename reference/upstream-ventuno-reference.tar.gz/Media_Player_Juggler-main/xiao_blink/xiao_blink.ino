#include <Arduino.h>

#ifndef LED_BUILTIN
#define LED_BUILTIN 27
#endif

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
}

void loop() {
  // Explicit state toggle (active-low onboard LED)
  digitalWrite(LED_BUILTIN, LOW);   // LED ON
  delay(250);
  digitalWrite(LED_BUILTIN, HIGH);  // LED OFF
  delay(250);
}
