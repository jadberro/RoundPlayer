param (
    [string]$Action = "sync-and-build"
)

$VentunoIP = "192.168.0.214"
$User = "arduino"
$RemoteDir = "/home/arduino/ball_bouncer/round_hud_app"
$LocalDir = "c:\Users\berro\Desktop\Projects\bouncer\round_hud_app"

Write-Host ">>> Synchronizing local lib/ to Ventuno Q..." -ForegroundColor Cyan
scp -r "$LocalDir\lib" "${User}@${VentunoIP}:${RemoteDir}/"

if ($Action -eq "sync-and-run") {
    Write-Host ">>> Building and restarting round_hud.service on Ventuno..." -ForegroundColor Yellow
    ssh "${User}@${VentunoIP}" "cd $RemoteDir && flutter build linux --release && systemctl --user restart round_hud.service && sleep 2; ps aux | grep round_hud_app"
} elseif ($Action -eq "sync-and-web") {
    Write-Host ">>> Rebuilding Web build on board..." -ForegroundColor Green
    ssh "${User}@${VentunoIP}" "cd $RemoteDir && flutter build web --release"
    scp -r "${User}@${VentunoIP}:${RemoteDir}/build/web" "c:\Users\berro\Desktop\Projects\bouncer\web_build\"
    Write-Host ">>> Web build synced to local!" -ForegroundColor Green
}
