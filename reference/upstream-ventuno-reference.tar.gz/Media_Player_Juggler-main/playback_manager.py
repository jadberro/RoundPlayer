#!/usr/bin/env python3
"""
3-RRS Ballistic Juggler - Master Playback Manager & Ingestion Engine
Decoupled media orchestration, deterministic caching, 60 Hz Unix domain telemetry, and ALSA coordination.
"""

import os
import sys
import json
import time
import re
import math
import asyncio
import subprocess
import threading
import shutil
import colorsys
import urllib.request
import glob
from datetime import datetime, timezone
from typing import List, Dict, Optional, Set, Any
from collections import OrderedDict

import numpy as np
import aubio
import yt_dlp
import ytmusicapi
import hifi_manager
import hifi_playlists
from PIL import Image
from pydantic import BaseModel
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

try:
    import vision_manager
    HAS_VISION = True
except Exception as _e:
    print("Vision manager load warning:", _e)
    HAS_VISION = False


# Directories & Sockets
CACHE_DIR = "/data/juggler_cache"
TEMP_DIR = "/tmp/juggler_temp"
TELEMETRY_SOCK_PATH = "/tmp/juggler_telemetry.sock"
MAX_CACHE_TRACKS = 35
MAX_CACHE_BYTES = 25 * 1024 * 1024 * 1024  # 25 GB

os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)

app = FastAPI(title="Ballistic Music Juggler - Playback Manager")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class TrackInfo(BaseModel):
    video_id: str
    title: str
    artist: str
    duration: Optional[str] = "0:00"
    duration_seconds: Optional[int] = 0
    bpm: Optional[float] = 103.0
    beat_count: Optional[int] = 0
    dominant_color: Optional[str] = "#00E5FF"
    source: Optional[str] = "youtube"
    thumbnail_url: Optional[str] = ""
    is_cached: bool = False
    cached_at: Optional[str] = None
    last_accessed_at: Optional[str] = None

class CacheStatus(BaseModel):
    status: str
    progress: Optional[float] = 0.0
    percent: Optional[int] = 0
    step: Optional[str] = ""
    title: Optional[str] = None
    artist: Optional[str] = None
    error: Optional[str] = None

class ControlCommand(BaseModel):
    action: str  # "play", "pause", "stall", "seek", "volume", "apex_height"
    value: Optional[float] = None
    seek_seconds: Optional[float] = None

class SystemState(BaseModel):
    active_video_id: Optional[str]
    title: Optional[str]
    artist: Optional[str]
    is_playing: bool
    is_frozen: bool
    apex_height_mm: float
    volume: float
    current_bpm: float
    playback_position_s: float
    duration_seconds: Optional[int] = 240
    dominant_color: str
    caching_video_id: Optional[str] = None
    caching_title: Optional[str] = None
    caching_artist: Optional[str] = None
    caching_progress: Optional[str] = None
    caching_percent: Optional[int] = 0
    is_hifi: Optional[bool] = False
    format: Optional[str] = None
    bit_depth: Optional[int] = None
    sample_rate_hz: Optional[int] = None
    shuffle: Optional[bool] = False
    repeat: Optional[str] = "all"

# Global State
state_lock = threading.Lock()
cache_tasks: Dict[str, Dict] = {}
caching_lock = threading.Lock()
target_track_id: Optional[str] = None

# Queue & History State
queue_lock = threading.Lock()
playback_queue: List[Dict[str, Any]] = []
playback_history: List[str] = []

class QueueItem(BaseModel):
    video_id: str
    title: Optional[str] = None
    artist: Optional[str] = None
    album: Optional[str] = None
    duration: Optional[str] = None
    thumbnail_url: Optional[str] = None
    source: Optional[str] = "youtube"
    position: Optional[str] = "end"
    cover_key: Optional[str] = None

    class Config:
        extra = "allow"

runtime_state = {
    "active_video_id": "DBHipNYuAZk",
    "title": "Daft Punk - Burnin' (Official Music Video)",
    "artist": "Daft Punk",
    "album": "",
    "is_playing": False,
    "is_frozen": False,
    "is_hifi": False,
    "audio_format": "AAC",
    "bit_depth": 16,
    "sample_rate_hz": 48000,
    "hifi_catalog_version": 1,
    "hifi_sync_status": "idle",
    "hifi_sync_message": "Ready",
    "shuffle": False,
    "repeat": "all",
    "apex_height_mm": 416.2,
    "volume": 100.0,
    "current_bpm": 126.2,
    "beat_period_s": 60.0 / 126.2,
    "dominant_color": "#d89c31",
    "start_time": time.time(),
    "pause_time": time.time(),
    "position_offset_s": 0.0,
    "beats": np.array([], dtype=np.float32),
}

# --- Track Directory Helpers ---

def get_track_dir(track_id: str) -> str:
    return os.path.join(CACHE_DIR, track_id)

def get_meta_path(track_id: str) -> str:
    return os.path.join(get_track_dir(track_id), "metadata.json")

def get_video_path(track_id: str) -> str:
    return os.path.join(get_track_dir(track_id), "video.mp4")

def get_audio_path(track_id: str) -> str:
    return os.path.join(get_track_dir(track_id), "audio.wav")

def get_cover_path(track_id: str) -> str:
    return os.path.join(get_track_dir(track_id), "cover.jpg")

def get_beats_path(track_id: str) -> str:
    return os.path.join(get_track_dir(track_id), "beats.npy")

def get_flag_path(track_id: str) -> str:
    return os.path.join(get_track_dir(track_id), "complete.flag")

def is_track_ready(track_id: str) -> bool:
    v_path = get_video_path(track_id)
    f_path = get_flag_path(track_id)
    return os.path.isfile(f_path) and os.path.isfile(v_path) and os.path.getsize(v_path) > 1024

def activate_track_sync(video_id: str) -> dict:
    meta_path = get_meta_path(video_id)
    try:
        with open(meta_path, 'r', encoding='utf-8') as f:
            meta = json.load(f)
        
        # Update last_accessed_at for LRU
        meta["last_accessed_at"] = datetime.now(timezone.utc).isoformat()
        try:
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(meta, f, indent=2)
        except Exception:
            pass

        bpm = float(meta.get("bpm", 126.2))
        color = meta.get("dominant_color", "#00E5FF")
        title = meta.get("title", "Unknown")
        artist = meta.get("artist", "Unknown")

        beats_path = get_beats_path(video_id)
        if os.path.exists(beats_path):
            try:
                beats_arr = np.load(beats_path)
            except Exception:
                beats_arr = np.array([], dtype=np.float32)
        else:
            beats_arr = np.array([], dtype=np.float32)

        with state_lock:
            runtime_state["active_video_id"] = video_id
            runtime_state["current_bpm"] = bpm
            runtime_state["beat_period_s"] = 60.0 / bpm if bpm > 0 else 60.0 / 103.0
            runtime_state["dominant_color"] = color
            runtime_state["title"] = title
            runtime_state["artist"] = artist
            runtime_state["album"] = ""
            runtime_state["is_playing"] = True
            runtime_state["is_frozen"] = False
            runtime_state["is_hifi"] = False
            runtime_state["audio_format"] = "AAC"
            runtime_state["bit_depth"] = 16
            runtime_state["sample_rate_hz"] = 48000
            runtime_state["start_time"] = time.time()
            runtime_state["pause_time"] = None
            runtime_state["position_offset_s"] = 0.0
            runtime_state["beats"] = beats_arr

        print(f"[PlaybackManager] Activated track: {video_id} ('{title}' by {artist}, BPM {bpm})")

        with queue_lock:
            if not playback_history or playback_history[-1] != video_id:
                playback_history.append(video_id)
            if playback_queue and playback_queue[0].get("video_id") == video_id:
                playback_queue.pop(0)
            if playback_queue:
                next_vid = playback_queue[0].get("video_id")
                if next_vid and not is_track_ready(next_vid):
                    threading.Thread(target=run_caching_pipeline, args=(next_vid,), daemon=True).start()

        return {
            "status": "playing",
            "video_id": video_id,
            "bpm": bpm,
            "dominant_color": color,
            "title": title,
            "artist": artist
        }
    except Exception as e:
        print(f"[PlaybackManager] Error activating track {video_id}: {e}")
        return {"status": "error", "message": str(e)}

def activate_hifi_track(track_id: str) -> dict:
    """Activates lossless Hi-Fi audio track with on-demand cache assurance."""
    import hifi_manager
    clean_id = track_id.replace("hifi_", "")
    track = hifi_manager.find_track_by_id(clean_id)
    if not track:
        return {"status": "error", "message": f"Track {clean_id} not found in Hi-Fi library"}

    # Signal HUD buffering progress if uncached
    if not hifi_manager.is_track_cached(clean_id):
        with state_lock:
            runtime_state["caching_video_id"] = f"hifi_{clean_id}"
            runtime_state["caching_title"] = track.get("title", "Hi-Fi Audio")
            runtime_state["caching_artist"] = track.get("artist", "")
            runtime_state["caching_percent"] = 30
            runtime_state["caching_progress"] = "Buffering Lossless FLAC..."

    def _on_dl_progress(downloaded, total):
        if total > 0:
            pct = int((downloaded / total) * 90)
            with state_lock:
                runtime_state["caching_percent"] = max(10, min(95, pct))

    try:
        cached_info = hifi_manager.ensure_track_cached(clean_id, progress_callback=_on_dl_progress)
        beats_info = cached_info.get("beats") or {}
    except Exception as e:
        print(f"[Hi-Fi Cache Error] {e}")
        with state_lock:
            runtime_state["caching_video_id"] = None
        return {"status": "error", "message": str(e)}

    beats_arr = np.array(beats_info.get("beats", []), dtype=np.float32)
    bpm = float(beats_info.get("bpm", 120.0))

    dominant_color = "#F59E0B"
    if track.get("cover_path") and os.path.isfile(track["cover_path"]):
        try:
            dominant_color = extract_dominant_color(track["cover_path"])
        except Exception:
            pass

    full_id = f"hifi_{clean_id}"
    track_title = track.get("title", "Unknown Title")
    track_artist = track.get("artist", "Unknown Artist")
    track_album = track.get("album", "Unknown Album")
    audio_format = track.get("format") or "FLAC"
    bit_depth = track.get("bit_depth", 16) or 16
    sample_rate_hz = track.get("sample_rate_hz", 44100) or 44100

    with state_lock:
        runtime_state["active_video_id"] = full_id
        runtime_state["title"] = track_title
        runtime_state["artist"] = track_artist
        runtime_state["album"] = track_album
        runtime_state["is_playing"] = True
        runtime_state["is_frozen"] = False
        runtime_state["is_hifi"] = True
        runtime_state["audio_format"] = audio_format
        runtime_state["bit_depth"] = bit_depth
        runtime_state["sample_rate_hz"] = sample_rate_hz
        runtime_state["current_bpm"] = bpm
        runtime_state["beat_period_s"] = 60.0 / bpm if bpm > 0 else 60.0 / 120.0
        runtime_state["dominant_color"] = dominant_color
        runtime_state["start_time"] = time.time()
        runtime_state["pause_time"] = None
        runtime_state["position_offset_s"] = 0.0
        runtime_state["beats"] = beats_arr
        runtime_state["caching_video_id"] = None

    print(f"[Hi-Fi Playback] Activated: {track_title} by {track_artist} [{audio_format} {bit_depth}b/{sample_rate_hz}Hz, BPM {bpm}]")

    with queue_lock:
        if not playback_history or playback_history[-1] != full_id:
            playback_history.append(full_id)

    # Predictive Zero-Lag Pre-cache: Download next track in background while current plays
    preload_upcoming_hifi_track(clean_id)

    return {
        "status": "playing",
        "track_id": full_id,
        "title": track_title,
        "artist": track_artist,
        "album": track_album,
        "bpm": bpm,
        "is_hifi": True,
        "format": audio_format,
        "bit_depth": bit_depth,
        "sample_rate_hz": sample_rate_hz,
        "dominant_color": dominant_color,
        "stream_url": f"/media/hifi/{clean_id}/stream"
    }

def preload_upcoming_hifi_track(current_clean_id: str):
    """Predicts and pre-caches next track in queue or active album in background."""
    import hifi_manager
    try:
        # 1. Check queue first
        with queue_lock:
            if playback_queue:
                next_q = playback_queue[0]
                q_id = str(next_q.get("video_id") or next_q.get("track_id") or "")
                if q_id.startswith("hifi_") or next_q.get("source") == "hifi":
                    hifi_manager.trigger_background_precache(q_id.replace("hifi_", ""))
                    return

        # 2. Check current track's album
        album_tracks, idx = hifi_manager.get_album_tracks_for_track(current_clean_id)
        if album_tracks and idx >= 0:
            if idx + 1 < len(album_tracks):
                next_track = album_tracks[idx + 1]
            elif runtime_state.get("repeat") == "all":
                next_track = album_tracks[0]
            else:
                return
            next_id = next_track.get("track_id")
            if next_id and not next_track.get("is_cached", False):
                hifi_manager.trigger_background_precache(next_id)
    except Exception as e:
        logger.warning(f"[HiFi Preloader] Error during preload: {e}")


# --- Cache Initialization & Migration ---

def init_existing_cache():
    """Scan /data/juggler_cache/ and ensure existing tracks have complete.flag and cover.jpg."""
    if not os.path.exists(CACHE_DIR):
        return
    for item in os.listdir(CACHE_DIR):
        item_path = os.path.join(CACHE_DIR, item)
        if not os.path.isdir(item_path):
            continue
        v_path = get_video_path(item)
        m_path = get_meta_path(item)
        c_path = get_cover_path(item)
        f_path = get_flag_path(item)

        if os.path.isfile(v_path) and os.path.isfile(m_path):
            # Extract cover if missing
            if not os.path.isfile(c_path):
                try:
                    subprocess.run([
                        'ffmpeg', '-y', '-ss', '00:00:05', '-i', v_path,
                        '-vframes', '1', '-vf', 'scale=512:512', c_path
                    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
                except Exception:
                    pass
            # Mark complete if missing
            if not os.path.isfile(f_path):
                try:
                    with open(f_path, 'w') as f:
                        f.write(datetime.now(timezone.utc).isoformat())
                except Exception:
                    pass

init_existing_cache()

# --- LRU Cache Eviction ---

def get_dir_size(path: str) -> int:
    total = 0
    try:
        for entry in os.scandir(path):
            if entry.is_file():
                total += entry.stat().st_size
    except Exception:
        pass
    return total

def evict_lru_cache():
    """Evict oldest tracks by last_accessed_at if limit exceeded."""
    if not os.path.exists(CACHE_DIR):
        return
    track_dirs = []
    total_size = 0
    for item in os.listdir(CACHE_DIR):
        dir_path = get_track_dir(item)
        if not os.path.isdir(dir_path):
            continue
        m_path = get_meta_path(item)
        last_accessed = 0.0
        if os.path.isfile(m_path):
            try:
                with open(m_path, 'r', encoding='utf-8') as f:
                    meta = json.load(f)
                    ts = meta.get('last_accessed_at') or meta.get('cached_at')
                    if ts:
                        last_accessed = datetime.fromisoformat(ts).timestamp()
            except Exception:
                pass
        if last_accessed == 0.0:
            last_accessed = os.path.getmtime(dir_path)
        
        sz = get_dir_size(dir_path)
        total_size += sz
        track_dirs.append((item, last_accessed, sz))

    # Sort oldest first
    track_dirs.sort(key=lambda x: x[1])

    while len(track_dirs) > MAX_CACHE_TRACKS or total_size > MAX_CACHE_BYTES:
        oldest_id, _, sz = track_dirs.pop(0)
        with state_lock:
            if oldest_id == runtime_state.get("active_video_id"):
                continue  # Never evict currently playing track
        print(f"[LRU] Evicting cached track: {oldest_id} ({sz / (1024*1024):.1f} MB)")
        try:
            shutil.rmtree(get_track_dir(oldest_id))
            total_size -= sz
        except Exception as e:
            print(f"[LRU] Error removing {oldest_id}: {e}")

# --- Beat Detection & Color Extraction ---

def compute_beats_aubio(audio_path: str, win_s: int = 1024, hop_s: int = 512, samplerate: int = 48000):
    s = aubio.source(audio_path, samplerate, hop_s)
    tempo = aubio.tempo("default", win_s, hop_s, samplerate)
    beats = []
    total_frames = 0
    while True:
        samples, read = s()
        is_beat = tempo(samples)
        if is_beat:
            this_beat = tempo.get_last_s()
            beats.append(float(this_beat))
        total_frames += read
        if read < hop_s:
            break
    
    bpm = float(tempo.get_bpm())
    if bpm <= 0 and len(beats) > 1:
        diffs = np.diff(beats)
        median_interval = np.median(diffs)
        bpm = 60.0 / median_interval if median_interval > 0 else 103.0
    return beats, round(bpm, 1)

def extract_dominant_color(video_path: str) -> str:
    tmp_img = os.path.join(TEMP_DIR, f"thumb_{int(time.time()*1000)}.jpg")
    try:
        subprocess.run([
            'ffmpeg', '-y', '-ss', '00:00:08', '-i', video_path,
            '-vframes', '1', '-vf', 'scale=64:64', tmp_img
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        if not os.path.exists(tmp_img):
            return '#00E5FF'
        im = Image.open(tmp_img).convert('RGB')
        colors = im.getcolors(64 * 64) or []
        vibrant_candidates = []
        for count, (r, g, b) in colors:
            h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            if v > 0.20 and s > 0.15:
                score = count * (s ** 1.5) * v
                vibrant_candidates.append((score, h, s, v))
        if os.path.exists(tmp_img):
            os.remove(tmp_img)
        if vibrant_candidates:
            vibrant_candidates.sort(reverse=True, key=lambda x: x[0])
            _, h, s, v = vibrant_candidates[0]
            s = max(s, 0.70)
            v = max(v, 0.85)
            r, g, b = colorsys.hsv_to_rgb(h, s, v)
            return f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
    except Exception as e:
        if os.path.exists(tmp_img):
            os.remove(tmp_img)
    return '#00E5FF'

# --- Ingestion Pipeline Worker ---

def run_caching_pipeline(video_id: str):
    global target_track_id
    if is_track_ready(video_id):
        cache_tasks[video_id] = {
            "status": "ready", "progress": 1.0, "percent": 100, "step": "Ready", "error": None
        }
        with state_lock:
            should_play = (target_track_id == video_id)
        if should_play:
            activate_track_sync(video_id)
        return

    with caching_lock:
        if is_track_ready(video_id):
            cache_tasks[video_id] = {
                "status": "ready", "progress": 1.0, "percent": 100, "step": "Ready", "error": None
            }
            with state_lock:
                should_play = (target_track_id == video_id)
            if should_play:
                activate_track_sync(video_id)
            return

        track_dir = get_track_dir(video_id)
        os.makedirs(track_dir, exist_ok=True)
        temp_template = os.path.join(TEMP_DIR, f"{video_id}.%(ext)s")

        try:
            cache_tasks[video_id] = {
                "status": "downloading",
                "progress": 0.05,
                "percent": 5,
                "step": "Downloading 1080p HD stream...",
                "title": None,
                "artist": None,
                "error": None
            }

            def progress_hook(d):
                if d.get('status') == 'downloading':
                    total = d.get('total_bytes') or d.get('total_bytes_estimate') or 0
                    downloaded = d.get('downloaded_bytes') or 0
                    if total > 0:
                        fraction = min(max(downloaded / total, 0.0), 1.0)
                        p = 0.05 + 0.65 * fraction
                        pct = int(p * 100)
                        cache_tasks[video_id]["progress"] = round(p, 2)
                        cache_tasks[video_id]["percent"] = pct
                        cache_tasks[video_id]["step"] = f"Downloading 1080p stream ({pct}%)"

            ydl_opts = {
                'format': 'bestvideo[height<=1080][vcodec^=avc]+bestaudio[acodec^=mp4a]/bestvideo[height<=1080][vcodec^=avc]+bestaudio[ext=m4a]/bestvideo[height<=1080]+bestaudio/best[height<=1080]/bestaudio/best',
                'outtmpl': temp_template,
                'quiet': True,
                'no_warnings': True,
                'noplaylist': True,
                'progress_hooks': [progress_hook],
                'extractor_args': {
                    'youtube': {
                        'player_client': ['ios', 'android', 'mweb', 'web']
                    }
                },
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=True)
                downloaded_ext = info.get('ext', 'mp4')
                raw_file = os.path.join(TEMP_DIR, f"{video_id}.{downloaded_ext}")
                title = info.get('title', 'Unknown Title')
                artist = info.get('artist') or info.get('uploader', 'Unknown Artist')
                duration = int(info.get('duration') or 0)
                cache_tasks[video_id]["title"] = title
                cache_tasks[video_id]["artist"] = artist

            if not os.path.exists(raw_file):
                matches = [f for f in glob.glob(os.path.join(TEMP_DIR, f"{video_id}.*")) if not f.endswith('.part')]
                if matches:
                    raw_file = matches[0]
                else:
                    raise FileNotFoundError(f"Downloaded raw file for {video_id} not found in {TEMP_DIR}")

            # Check if video stream exists
            has_video = False
            try:
                probe = subprocess.run([
                    'ffprobe', '-v', 'error', '-select_streams', 'v:0',
                    '-show_entries', 'stream=codec_name',
                    '-of', 'default=noprint_wrappers=1:nokey=1', raw_file
                ], capture_output=True, text=True, timeout=8)
                if probe.stdout.strip():
                    has_video = True
            except Exception:
                has_video = False

            video_out = get_video_path(video_id)
            audio_out = get_audio_path(video_id)
            cover_out = get_cover_path(video_id)
            beats_out = get_beats_path(video_id)
            meta_out = get_meta_path(video_id)
            flag_out = get_flag_path(video_id)

            # 1. Audio extraction (48kHz 24-bit uncompressed stereo PCM for DAC Pro)
            cache_tasks[video_id]["progress"] = 0.70
            cache_tasks[video_id]["percent"] = 70
            cache_tasks[video_id]["step"] = "Extracting uncompressed 24-bit 48kHz PCM audio"
            extract_cmd = ['ffmpeg', '-y', '-i', raw_file]
            if duration > 240:
                extract_cmd += ['-t', '180']
            extract_cmd += ['-vn', '-acodec', 'pcm_s24le', '-ar', '48000', '-ac', '2', audio_out]
            subprocess.run(extract_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

            # 2. Extract Cover Art
            cover_extracted = False
            if has_video:
                try:
                    subprocess.run([
                        'ffmpeg', '-y', '-ss', '00:00:06', '-i', raw_file,
                        '-vframes', '1', '-vf', 'scale=512:512', cover_out
                    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8)
                    if os.path.exists(cover_out) and os.path.getsize(cover_out) > 1024:
                        cover_extracted = True
                except Exception:
                    pass

            if not cover_extracted:
                thumb_url = info.get('thumbnail')
                if not thumb_url and info.get('thumbnails'):
                    thumb_url = info['thumbnails'][-1].get('url')
                if thumb_url:
                    try:
                        urllib.request.urlretrieve(thumb_url, cover_out)
                        if os.path.exists(cover_out) and os.path.getsize(cover_out) > 1024:
                            cover_extracted = True
                    except Exception:
                        pass

            if not cover_extracted or not os.path.exists(cover_out):
                im = Image.new('RGB', (512, 512), color=(14, 20, 36))
                im.save(cover_out, 'JPEG')

            # 3. Video Stream Creation
            cache_tasks[video_id]["status"] = "processing"
            cache_tasks[video_id]["progress"] = 0.80
            cache_tasks[video_id]["percent"] = 80
            cache_tasks[video_id]["step"] = "Preparing clean 1080p video stream"

            if has_video:
                remux_cmd = ['ffmpeg', '-y', '-i', raw_file, '-c', 'copy', '-movflags', '+faststart', video_out]
                res = subprocess.run(remux_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if res.returncode != 0 or not os.path.exists(video_out) or os.path.getsize(video_out) < 1024:
                    subprocess.run([
                        'ffmpeg', '-y', '-i', raw_file,
                        '-vf', 'scale=-2:1080',
                        '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '23',
                        '-pix_fmt', 'yuv420p',
                        '-c:a', 'aac', '-b:a', '192k',
                        '-movflags', '+faststart', video_out
                    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            else:
                # Audio-only track (e.g. YouTube Music): generate clean 1080x1080 video from cover.jpg
                vid_duration = min(duration, 180) if duration > 0 else 180
                subprocess.run([
                    'ffmpeg', '-y', '-loop', '1', '-i', cover_out,
                    '-c:v', 'libx264', '-tune', 'stillimage', '-preset', 'ultrafast',
                    '-pix_fmt', 'yuv420p', '-t', str(vid_duration),
                    '-vf', 'scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2:color=black',
                    '-movflags', '+faststart', video_out
                ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

            # 4. Aubio Beat & Tempo Analysis
            cache_tasks[video_id]["progress"] = 0.88
            cache_tasks[video_id]["percent"] = 88
            cache_tasks[video_id]["step"] = "Computing Aubio beat markers & tempo"
            beats, bpm = compute_beats_aubio(audio_out)
            np.save(beats_out, np.array(beats, dtype=np.float32))

            # 5. Dominant Neon Color Extraction
            cache_tasks[video_id]["progress"] = 0.95
            cache_tasks[video_id]["percent"] = 95
            cache_tasks[video_id]["step"] = "Extracting neon dominant palette"
            dominant_color = extract_dominant_color(video_out)

            # 6. Metadata JSON Commit
            now_iso = datetime.now(timezone.utc).isoformat()
            duration_str = f"{duration // 60}:{duration % 60:02d}"
            metadata = {
                "video_id": video_id,
                "title": title,
                "artist": artist,
                "duration": duration_str,
                "duration_seconds": duration,
                "bpm": bpm,
                "beat_count": len(beats),
                "dominant_color": dominant_color,
                "source": "youtube",
                "cached_at": now_iso,
                "last_accessed_at": now_iso
            }
            with open(meta_out, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2)

            # 7. Atomic Complete Flag
            with open(flag_out, 'w') as f:
                f.write(now_iso)

            # Clean raw download
            if os.path.exists(raw_file):
                os.remove(raw_file)

            cache_tasks[video_id]["status"] = "ready"
            cache_tasks[video_id]["progress"] = 1.0
            cache_tasks[video_id]["percent"] = 100
            cache_tasks[video_id]["step"] = "Ready"

            # Auto-activate if target track matches
            with state_lock:
                if runtime_state.get("caching_video_id") == video_id:
                    runtime_state["caching_video_id"] = None
                should_auto_play = (target_track_id == video_id)
            if should_auto_play:
                print(f"[Ingestion Engine] Target track ready, auto-activating: {video_id}")
                activate_track_sync(video_id)

            # Check LRU cache limit
            evict_lru_cache()

        except Exception as e:
            print(f"[Ingestion Error] {video_id}: {e}")
            cache_tasks[video_id] = {
                "status": "error", "progress": 0.0, "percent": 0, "step": "Failed", "error": str(e)
            }
            with state_lock:
                if runtime_state.get("caching_video_id") == video_id:
                    runtime_state["caching_video_id"] = None

# --- 60 Hz Unix Domain Socket Telemetry Server ---

unix_clients: Set[asyncio.StreamWriter] = set()

async def unix_socket_client_handler(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    unix_clients.add(writer)
    try:
        while True:
            line = await reader.readline()
            if not line:
                break
            # Handle incoming IPC command if any
            try:
                cmd = json.loads(line.decode().strip())
                action = cmd.get("action")
                val = cmd.get("value")
                with state_lock:
                    if action == "play":
                        runtime_state["is_playing"] = True
                    elif action == "pause":
                        runtime_state["is_playing"] = False
                    elif action == "stall":
                        runtime_state["is_frozen"] = not runtime_state["is_frozen"]
                    elif action == "apex_height" and val is not None:
                        runtime_state["apex_height_mm"] = float(val)
                    elif action == "volume" and val is not None:
                        runtime_state["volume"] = float(val)
            except Exception:
                pass
    except Exception:
        pass
    finally:
        unix_clients.discard(writer)
        writer.close()

async def start_unix_telemetry_server():
    if os.path.exists(TELEMETRY_SOCK_PATH):
        try:
            os.remove(TELEMETRY_SOCK_PATH)
        except Exception:
            pass
    server = await asyncio.start_unix_server(unix_socket_client_handler, path=TELEMETRY_SOCK_PATH)
    # Set generous socket permissions for local processes
    try:
        os.chmod(TELEMETRY_SOCK_PATH, 0o666)
    except Exception:
        pass
    print(f"[Telemetry] Unix domain socket server listening at {TELEMETRY_SOCK_PATH}")
    return server

async def telemetry_broadcaster_loop():
    """Broadcasts 60 Hz telemetry packets over Unix domain socket and WebSockets."""
    while True:
        t_now = time.time()
        timestamp_us = int(t_now * 1e6)

        with state_lock:
            live_bpm = runtime_state.get("current_bpm", 126.2)
            is_playing = runtime_state.get("is_playing", False)
            is_frozen = runtime_state.get("is_frozen", False)
            apex_base = runtime_state.get("apex_height_mm", 416.2)
            active_id = runtime_state.get("active_video_id", "DBHipNYuAZk")
            caching_id = runtime_state.get("caching_video_id")
            caching_title = runtime_state.get("caching_title")
            caching_artist = runtime_state.get("caching_artist")
            is_hifi = runtime_state.get("is_hifi", False)
            audio_format = runtime_state.get("audio_format", "AAC")
            bit_depth = runtime_state.get("bit_depth", 16)
            sample_rate_hz = runtime_state.get("sample_rate_hz", 48000)
            dominant_color = runtime_state.get("dominant_color", "#00E5FF")
            current_title = runtime_state.get("title", "")
            current_artist = runtime_state.get("artist", "")
            current_album = runtime_state.get("album", "")

        c_task = cache_tasks.get(caching_id) if caching_id else None
        c_progress = c_task.get("progress", 0.05) if c_task else 0.0
        c_percent = c_task.get("percent", 5) if c_task else 0
        if c_task and c_task.get("title") and not caching_title:
            caching_title = c_task.get("title")
        if c_task and c_task.get("artist") and not caching_artist:
            caching_artist = c_task.get("artist")

        beat_freq = (live_bpm / 60.0) if live_bpm > 0 else (103.0 / 60.0)
        phase = (t_now * beat_freq * 2.0 * np.pi) % (2.0 * np.pi) if is_playing else 0.0

        apex_height = (apex_base + 8.5 * math.sin(phase)) if (is_playing and not is_frozen) else apex_base
        phase_error = (0.4 * math.sin(phase * 0.75)) if is_playing else 0.0
        pitch_deg = (1.2 * math.cos(phase * 0.5)) if is_playing else 0.0
        roll_deg = (-0.8 * math.sin(phase * 0.5)) if is_playing else 0.0
        ball_state = "STANDBY" if not is_playing else ("AIRBORNE" if math.sin(phase) > -0.6 else "CONTACT")

        packet = {
            "timestamp_us": timestamp_us,
            "track_id": active_id,
            "bpm": round(live_bpm, 1),
            "phase_error_ms": round(phase_error, 2),
            "beat_phase": round(phase / (2.0 * np.pi), 3),
            "apex_height_mm": round(apex_height, 1),
            "ball_state": ball_state,
            "paddle_pitch_deg": round(pitch_deg, 2),
            "paddle_roll_deg": round(roll_deg, 2),
            "is_frozen": is_frozen,
            "is_playing": is_playing,
            "is_hifi": is_hifi,
            "audio_format": audio_format,
            "bit_depth": bit_depth,
            "sample_rate_hz": sample_rate_hz,
            "color": dominant_color,
            "title": current_title,
            "artist": current_artist,
            "album": current_album,
            "caching_video_id": caching_id,
            "caching_progress": round(c_progress, 2),
            "caching_percent": c_percent,
            "caching_title": caching_title,
            "caching_artist": caching_artist,
            "hifi_catalog_version": runtime_state.get("hifi_catalog_version", 1),
            "hifi_sync_status": runtime_state.get("hifi_sync_status", "idle"),
            "shuffle": runtime_state.get("shuffle", False),
            "repeat": runtime_state.get("repeat", "all"),
        }

        if HAS_VISION:
            packet["vision"] = vision_manager.get_vision_manager().get_telemetry_dict()


        # Broadcast to Unix Socket clients
        data_bytes = (json.dumps(packet) + "\n").encode()
        dead_clients = set()
        for w in list(unix_clients):
            try:
                w.write(data_bytes)
            except Exception:
                dead_clients.add(w)
        for d in dead_clients:
            unix_clients.discard(d)

        await asyncio.sleep(1.0 / 60.0)

# --- Network Geolocation & Real-Time Open-Meteo Weather Engine ---

weather_state: Dict[str, Any] = {
    "city": "Unknown",
    "temperature": 15.0,
    "weather_code": 0,
    "is_day": 1,
    "condition": "Clear",
    "circadian_color": "#38BDF8",
    "updated_at": None
}

def compute_circadian_weather_color(hour: int, weather_code: int, is_day: int) -> str:
    # 1. Base Circadian Color by solar hour
    if 0 <= hour < 5:
        base_color = "#38BDF8"  # Deep midnight starlight sapphire
    elif 5 <= hour < 7:
        base_color = "#FB7185"  # Soft dawn rose
    elif 7 <= hour < 11:
        base_color = "#38BDF8"  # Morning crisp sky azure
    elif 11 <= hour < 16:
        base_color = "#00E5FF"  # High noon radiant solar cyan
    elif 16 <= hour < 19:
        base_color = "#F59E0B"  # Golden hour amber
    elif 19 <= hour < 22:
        base_color = "#818CF8"  # Twilight velvet indigo
    else:
        base_color = "#0284C7"  # Deep night ocean blue

    # 2. Weather Condition Modulation
    if weather_code in [95, 96, 99]:
        return "#A855F7"  # Electric thunderstorm violet
    elif 51 <= weather_code <= 67 or 80 <= weather_code <= 82:
        return "#06B6D4"  # Cool oceanic rain cyan
    elif 71 <= weather_code <= 77 or 85 <= weather_code <= 86:
        return "#BAE6FD"  # Glacial diamond snow frost
    elif weather_code in [3, 45, 48]:
        return "#94A3B8"  # Misty silver overcast vapor
    elif weather_code in [0, 1] and is_day:
        if 16 <= hour < 19:
            return "#F59E0B"  # Sunlit amber sunset
        return "#38BDF8"      # Clear azure sun

    return base_color

async def fetch_weather_now():
    global weather_state
    try:
        settings = load_settings()
        custom_city = settings.get("selected_city")
        custom_lat = settings.get("custom_lat")
        custom_lon = settings.get("custom_lon")

        if custom_city and custom_lat is not None and custom_lon is not None:
            lat = float(custom_lat)
            lon = float(custom_lon)
            city = str(custom_city)
        else:
            # Step 1: Network IP Geolocation
            req = urllib.request.Request("http://ip-api.com/json", headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=6) as resp:
                geo = json.loads(resp.read().decode())
            if geo.get("status") == "success":
                lat = geo["lat"]
                lon = geo["lon"]
                city = geo.get("city", "Unknown")
            else:
                lat = 53.383
                lon = -1.466
                city = "Sheffield"

        # Step 2: Open-Meteo Current & Daily Forecast Weather
        weather_url = (
            f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
            "&current=temperature_2m,relative_humidity_2m,is_day,weather_code"
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset"
            "&timezone=auto&forecast_days=4"
        )
        w_req = urllib.request.Request(weather_url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(w_req, timeout=6) as w_resp:
            w_data = json.loads(w_resp.read().decode())
            current = w_data.get("current", {})
            temp = float(current.get("temperature_2m", 15.0))
            code = int(current.get("weather_code", 0))
            is_day = int(current.get("is_day", 1))

            conditions = {
                0: "Clear Sky", 1: "Mainly Clear", 2: "Partly Cloudy", 3: "Overcast",
                45: "Fog", 48: "Rime Fog",
                51: "Light Drizzle", 53: "Drizzle", 55: "Dense Drizzle",
                61: "Slight Rain", 63: "Moderate Rain", 65: "Heavy Rain",
                71: "Slight Snow", 73: "Moderate Snow", 75: "Heavy Snow",
                80: "Rain Showers", 81: "Heavy Showers", 82: "Violent Showers",
                95: "Thunderstorm", 96: "Hail Thunderstorm", 99: "Severe Thunderstorm"
            }
            cond_name = conditions.get(code, "Clear" if is_day else "Starry")
            now_hour = datetime.now().hour
            circadian_color = compute_circadian_weather_color(now_hour, code, is_day)

            # Step 3: Parse 3-day forecast & astronomical sunrise/sunset
            daily = w_data.get("daily", {})
            d_times = daily.get("time", [])
            d_codes = daily.get("weather_code", [])
            d_max = daily.get("temperature_2m_max", [])
            d_min = daily.get("temperature_2m_min", [])
            d_pop = daily.get("precipitation_probability_max", [])
            d_sunrises = daily.get("sunrise", [])
            d_sunsets = daily.get("sunset", [])

            forecast_list = []
            for i in range(1, min(4, len(d_times))):
                try:
                    dt = datetime.strptime(d_times[i], "%Y-%m-%d")
                    day_name = dt.strftime("%a").upper()
                except Exception:
                    day_name = f"D+{i}"
                forecast_list.append({
                    "day": day_name,
                    "date": d_times[i],
                    "weather_code": int(d_codes[i]) if i < len(d_codes) else code,
                    "temp_max": round(float(d_max[i])) if i < len(d_max) else round(temp),
                    "temp_min": round(float(d_min[i])) if i < len(d_min) else round(temp - 5),
                    "rain_pop": int(d_pop[i]) if (i < len(d_pop) and d_pop[i] is not None) else 0
                })

            today_sunrise_iso = d_sunrises[0] if d_sunrises else ""
            today_sunset_iso = d_sunsets[0] if d_sunsets else ""
            today_sunrise_str = today_sunrise_iso.split("T")[1] if "T" in today_sunrise_iso else "06:30"
            today_sunset_str = today_sunset_iso.split("T")[1] if "T" in today_sunset_iso else "18:30"

            weather_state = {
                "city": city,
                "lat": lat,
                "lon": lon,
                "temperature": temp,
                "weather_code": code,
                "is_day": is_day,
                "condition": cond_name,
                "circadian_color": circadian_color,
                "sunrise": today_sunrise_str,
                "sunset": today_sunset_str,
                "sunrise_iso": today_sunrise_iso,
                "sunset_iso": today_sunset_iso,
                "forecast": forecast_list,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
            print(f"[Weather] Updated: {city}, {temp}°C, {cond_name}, Sun: {today_sunrise_str}-{today_sunset_str}, Forecast: {len(forecast_list)} days")
            return weather_state
    except Exception as e:
        print(f"[Weather Error] Failed to fetch weather: {e}")
        return weather_state

async def weather_updater_task():
    while True:
        await fetch_weather_now()
        await asyncio.sleep(900)  # Refresh every 15 minutes

class CitySelectRequest(BaseModel):
    city: str
    lat: Optional[float] = None
    lon: Optional[float] = None

# --- REST Endpoints ---

@app.on_event("startup")
async def startup_event():
    if HAS_VISION:
        vision_manager.get_vision_manager().start()
    asyncio.create_task(start_unix_telemetry_server())
    asyncio.create_task(telemetry_broadcaster_loop())
    asyncio.create_task(weather_updater_task())

@app.get("/api/weather")
async def get_weather():
    if not weather_state.get("updated_at"):
        await fetch_weather_now()
    return weather_state

@app.get("/api/weather/search")
async def search_weather_city(q: str):
    if not q or len(q.strip()) < 2:
        return {"results": []}
    try:
        encoded_q = urllib.parse.quote(q.strip())
        url = f"https://geocoding-api.open-meteo.com/v1/search?name={encoded_q}&count=8&language=en&format=json"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            results = []
            for r in data.get("results", []):
                results.append({
                    "name": r.get("name"),
                    "country": r.get("country", ""),
                    "admin1": r.get("admin1", ""),
                    "latitude": r.get("latitude"),
                    "longitude": r.get("longitude")
                })
            return {"results": results}
    except Exception as e:
        print(f"[City Search Error] {e}")
        return {"results": [], "error": str(e)}

@app.post("/api/weather/city")
async def set_weather_city(req: CitySelectRequest):
    settings = load_settings()
    if req.city.lower() in ["auto", "automatic", "ip"]:
        settings["selected_city"] = None
        settings["custom_lat"] = None
        settings["custom_lon"] = None
        save_settings(settings)
        w = await fetch_weather_now()
        return {"status": "ok", "mode": "auto", "weather": w}

    lat = req.lat
    lon = req.lon
    if lat is None or lon is None:
        try:
            geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={urllib.parse.quote(req.city)}&count=1&language=en&format=json"
            g_req = urllib.request.Request(geo_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(g_req, timeout=5) as g_resp:
                g_data = json.loads(g_resp.read().decode())
                if g_data.get("results"):
                    lat = g_data["results"][0]["latitude"]
                    lon = g_data["results"][0]["longitude"]
                    req.city = g_data["results"][0]["name"]
        except Exception as e:
            print(f"[Geocode Error] {e}")

    settings["selected_city"] = req.city
    settings["custom_lat"] = lat
    settings["custom_lon"] = lon
    save_settings(settings)
    w = await fetch_weather_now()
    return {"status": "ok", "city": req.city, "weather": w}

@app.get("/api/state", response_model=SystemState)
async def get_system_state():
    with state_lock:
        pos = 0.0
        if runtime_state.get("is_playing", False) and runtime_state.get("start_time"):
            pos = (time.time() - runtime_state["start_time"]) + runtime_state.get("position_offset_s", 0.0)
        elif runtime_state.get("pause_time") and runtime_state.get("start_time"):
            pos = (runtime_state["pause_time"] - runtime_state["start_time"]) + runtime_state.get("position_offset_s", 0.0)
        pos = max(0.0, round(pos, 1))

        return SystemState(
            active_video_id=runtime_state.get("active_video_id"),
            title=runtime_state.get("title"),
            artist=runtime_state.get("artist"),
            is_playing=runtime_state.get("is_playing", False),
            is_frozen=runtime_state.get("is_frozen", False),
            apex_height_mm=runtime_state.get("apex_height_mm", 416.2),
            volume=runtime_state.get("volume", 100.0),
            current_bpm=runtime_state.get("current_bpm", 126.2),
            playback_position_s=pos,
            duration_seconds=runtime_state.get("duration_seconds", 240),
            dominant_color=runtime_state.get("dominant_color", "#00E5FF"),
            caching_video_id=runtime_state.get("caching_video_id"),
            caching_title=runtime_state.get("caching_title"),
            caching_artist=runtime_state.get("caching_artist"),
            caching_progress=runtime_state.get("caching_progress"),
            caching_percent=runtime_state.get("caching_percent", 0),
            is_hifi=runtime_state.get("is_hifi", False),
            format=runtime_state.get("audio_format"),
            bit_depth=runtime_state.get("bit_depth"),
            sample_rate_hz=runtime_state.get("sample_rate_hz"),
        )

@app.get("/api/tracks")
@app.get("/tracks")
async def list_tracks():
    tracks = []
    if not os.path.exists(CACHE_DIR):
        return tracks
    for item in os.listdir(CACHE_DIR):
        if not is_track_ready(item):
            continue
        meta_file = get_meta_path(item)
        if os.path.isfile(meta_file):
            try:
                with open(meta_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    data["is_cached"] = True
                    tracks.append(data)
            except Exception:
                continue
    return tracks

JUNK_SEARCH_REGEX = re.compile(
    r'\b(karaoke|piano tutorial|how to play|slowed|reverb|sped up|speed up|8d audio|bass boosted|loop|10 hours?|1 hour|parody|reaction|tutorial|lesson)\b',
    re.IGNORECASE
)

@app.get("/api/search")
@app.get("/search")
async def search(q: str):
    if not q.strip():
        return []
    try:
        yt = ytmusicapi.YTMusic()
        # 1. Search official studio tracks / master songs first (highest audio fidelity & official release)
        try:
            song_results = yt.search(q, filter="songs")
        except Exception:
            song_results = []

        # 2. Search official videos to capture genuine music videos
        try:
            video_results = yt.search(q, filter="videos")
        except Exception:
            video_results = []

        output = []
        seen_ids = set()

        # Prioritize official studio master tracks
        for res in song_results:
            vid = res.get('videoId')
            if not vid or vid in seen_ids:
                continue
            title = res.get('title', '')
            if JUNK_SEARCH_REGEX.search(title):
                continue
            seen_ids.add(vid)
            thumbnails = res.get('thumbnails', [])
            thumb = thumbnails[-1]['url'] if thumbnails else ''
            artists = res.get('artists', [])
            artist_name = artists[0]['name'] if artists else 'Unknown'
            output.append({
                "video_id": vid,
                "title": title or 'Unknown',
                "artist": artist_name,
                "duration": res.get('duration', '0:00'),
                "thumbnail_url": thumb,
                "is_cached": is_track_ready(vid)
            })
            if len(output) >= 8:
                break

        # Supplement with verified music videos (filtering out tutorials, covers, karaoke, etc.)
        if len(output) < 8:
            for res in video_results:
                vid = res.get('videoId')
                if not vid or vid in seen_ids:
                    continue
                title = res.get('title', '')
                if JUNK_SEARCH_REGEX.search(title):
                    continue
                seen_ids.add(vid)
                thumbnails = res.get('thumbnails', [])
                thumb = thumbnails[-1]['url'] if thumbnails else ''
                artists = res.get('artists', [])
                artist_name = artists[0]['name'] if artists else 'Unknown'
                output.append({
                    "video_id": vid,
                    "title": title or 'Unknown',
                    "artist": artist_name,
                    "duration": res.get('duration', '0:00'),
                    "thumbnail_url": thumb,
                    "is_cached": is_track_ready(vid)
                })
                if len(output) >= 8:
                    break

        return output
    except Exception as e:
        print(f"[Search Error] {e}")
        return []

@app.post("/api/cache/clear")
@app.post("/cache/clear")
async def clear_cached_music():
    current_active = runtime_state.get("active_video_id")
    cleared_count = 0
    try:
        if os.path.exists(CACHE_DIR):
            for entry in os.listdir(CACHE_DIR):
                entry_path = os.path.join(CACHE_DIR, entry)
                if os.path.isdir(entry_path) and entry != current_active:
                    import shutil
                    shutil.rmtree(entry_path, ignore_errors=True)
                    cleared_count += 1
        with state_lock:
            cache_tasks.clear()
        return {"status": "ok", "cleared_tracks": cleared_count}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/cache/{video_id}")
@app.post("/cache/{video_id}")
async def trigger_cache(video_id: str):
    if is_track_ready(video_id):
        return {"status": "ready", "video_id": video_id}
    if video_id in cache_tasks and cache_tasks[video_id]["status"] not in ["error", "ready"]:
        return {"status": cache_tasks[video_id]["status"], "video_id": video_id}
    
    asyncio.get_event_loop().run_in_executor(None, run_caching_pipeline, video_id)
    return {"status": "downloading", "video_id": video_id}

@app.get("/api/cache/status/{video_id}", response_model=CacheStatus)
@app.get("/cache/status/{video_id}", response_model=CacheStatus)
async def get_cache_status(video_id: str):
    if is_track_ready(video_id):
        return CacheStatus(status="ready", progress=1.0, percent=100, step="Ready")
    if video_id in cache_tasks:
        task = cache_tasks[video_id]
        p = task.get("progress", 0.0)
        pct = task.get("percent") or int(p * 100)
        return CacheStatus(
            status=task.get("status", "downloading"),
            progress=p,
            percent=pct,
            step=task.get("step", ""),
            title=task.get("title"),
            artist=task.get("artist"),
            error=task.get("error")
        )
    return CacheStatus(status="missing", error="Track not cached", progress=0.0, percent=0, step="Not in queue")

@app.post("/api/play/{video_id}")
@app.post("/play/{video_id}")
async def set_active_track(video_id: str, request: Request = None):
    meta_hint = {}
    if request:
        try:
            body = await request.body()
            if body:
                meta_hint = json.loads(body.decode())
        except Exception:
            pass

    global target_track_id
    with state_lock:
        target_track_id = video_id
        runtime_state["is_playing"] = True
        runtime_state["is_frozen"] = False

    if is_track_ready(video_id):
        with state_lock:
            runtime_state["caching_video_id"] = None
        return activate_track_sync(video_id)

    # Set caching state immediately so HUD and phone remote know this track is being prepared!
    c_title = meta_hint.get("title") or "Incoming Cast"
    c_artist = meta_hint.get("artist") or "Preparing 1080p Video..."
    with state_lock:
        runtime_state["caching_video_id"] = video_id
        runtime_state["caching_title"] = c_title
        runtime_state["caching_artist"] = c_artist
        runtime_state["active_video_id"] = video_id
        runtime_state["title"] = c_title
        runtime_state["artist"] = c_artist
        runtime_state["is_playing"] = True
        runtime_state["is_frozen"] = False

    # Trigger background download if not ready
    if video_id not in cache_tasks or cache_tasks[video_id].get("status") in ["error", "ready"]:
        asyncio.get_event_loop().run_in_executor(None, run_caching_pipeline, video_id)

    return {
        "status": "caching",
        "video_id": video_id,
        "title": c_title,
        "artist": c_artist
    }

@app.post("/api/control")
@app.post("/control")
async def handle_control(cmd: ControlCommand):
    with state_lock:
        if cmd.action == "play":
            runtime_state["is_playing"] = True
            if runtime_state.get("pause_time") and runtime_state.get("start_time"):
                paused_duration = time.time() - runtime_state["pause_time"]
                runtime_state["start_time"] += paused_duration
                runtime_state["pause_time"] = None
        elif cmd.action == "pause":
            runtime_state["is_playing"] = False
            runtime_state["pause_time"] = time.time()
        elif cmd.action in ["stop", "idle", "sleep"]:
            runtime_state["is_playing"] = False
            runtime_state["pause_time"] = time.time()
            runtime_state["active_video_id"] = "standby"
            runtime_state["title"] = "Standby"
            runtime_state["artist"] = "Idle Centerpiece"
            runtime_state["caching_video_id"] = None
            runtime_state["caching_title"] = None
            runtime_state["caching_artist"] = None
            with caching_lock:
                for tid, tinfo in cache_tasks.items():
                    if isinstance(tinfo, dict) and tinfo.get("status") not in ["ready", "error"]:
                        tinfo["status"] = "canceled"
        elif cmd.action == "stop_cast":
            # 1. Cleanly cancel incoming cast
            caching_id = runtime_state.get("caching_video_id")
            if caching_id:
                with caching_lock:
                    if caching_id in cache_tasks:
                        cache_tasks[caching_id]["status"] = "canceled"
            runtime_state["caching_video_id"] = None
            runtime_state["caching_title"] = None
            runtime_state["caching_artist"] = None
            runtime_state["is_playing"] = False
            runtime_state["pause_time"] = time.time()

            # 2. Revert to previous track from history in paused state
            prev_track_id = None
            with queue_lock:
                if len(playback_history) >= 2:
                    playback_history.pop()  # discard current cast
                    prev_track_id = playback_history[-1]
                elif len(playback_history) == 1:
                    prev_track_id = playback_history[0]

            if prev_track_id and prev_track_id != "standby":
                if prev_track_id.startswith("hifi_"):
                    clean_id = prev_track_id.replace("hifi_", "")
                    t = hifi_manager.find_track_by_id(clean_id)
                    if t:
                        runtime_state["active_video_id"] = prev_track_id
                        runtime_state["title"] = t.get("title", "Hi-Fi Track")
                        runtime_state["artist"] = t.get("artist", "")
                        runtime_state["album"] = t.get("album", "")
                        runtime_state["is_hifi"] = True
                        runtime_state["audio_format"] = t.get("format", "FLAC")
                    else:
                        runtime_state["active_video_id"] = prev_track_id
                else:
                    meta_path = os.path.join(CACHE_DIR, prev_track_id, "metadata.json")
                    if os.path.isfile(meta_path):
                        try:
                            with open(meta_path, "r", encoding="utf-8") as f:
                                meta = json.load(f)
                            runtime_state["active_video_id"] = prev_track_id
                            runtime_state["title"] = meta.get("title", "")
                            runtime_state["artist"] = meta.get("artist", "")
                            runtime_state["is_hifi"] = False
                        except Exception:
                            runtime_state["active_video_id"] = prev_track_id
                    else:
                        runtime_state["active_video_id"] = prev_track_id
            else:
                runtime_state["active_video_id"] = "standby"
                runtime_state["title"] = "Standby"
                runtime_state["artist"] = "Idle Centerpiece"
        elif cmd.action == "seek" and cmd.seek_seconds is not None:
            runtime_state["position_offset_s"] = float(cmd.seek_seconds)
            runtime_state["start_time"] = time.time()
        elif cmd.action == "stall":
            runtime_state["is_frozen"] = not runtime_state["is_frozen"]
        elif cmd.action == "volume" and cmd.value is not None:
            runtime_state["volume"] = float(cmd.value)
        elif cmd.action == "apex_height" and cmd.value is not None:
            runtime_state["apex_height_mm"] = float(cmd.value)
    return {"status": "ok", "action": cmd.action, "value": cmd.value, "is_playing": runtime_state.get("is_playing", False)}

# --- Queue & Playlist Endpoints ---

@app.get("/api/queue")
async def get_queue():
    with queue_lock:
        return {"queue": list(playback_queue), "history": list(playback_history)}

@app.post("/api/queue/add")
async def add_to_queue(item: QueueItem):
    with queue_lock:
        is_hifi = item.video_id.startswith("hifi_") or item.source == "hifi"
        clean_id = item.video_id.replace("hifi_", "")
        full_id = f"hifi_{clean_id}" if is_hifi else item.video_id
        
        is_ready = hifi_manager.is_track_cached(clean_id) if is_hifi else is_track_ready(full_id)
        
        queue_entry = {
            "video_id": full_id,
            "title": item.title or "Queued Track",
            "artist": item.artist or "Unknown",
            "album": item.album or "",
            "duration": item.duration or "",
            "thumbnail_url": item.thumbnail_url or "",
            "source": "hifi" if is_hifi else (item.source or "youtube"),
            "cover_key": item.cover_key or "",
            "is_cached": is_ready
        }
        
        if getattr(item, "position", "end") == "next":
            playback_queue.insert(0, queue_entry)
        else:
            playback_queue.append(queue_entry)
            
        if not is_hifi and not is_ready:
            threading.Thread(target=run_caching_pipeline, args=(full_id,), daemon=True).start()
    return {"status": "ok", "queue_length": len(playback_queue)}

@app.post("/api/queue/remove/{index}")
async def remove_from_queue(index: int):
    with queue_lock:
        if 0 <= index < len(playback_queue):
            removed = playback_queue.pop(index)
            return {"status": "ok", "removed": removed}
    raise HTTPException(status_code=400, detail="Index out of range")

@app.post("/api/queue/clear")
async def clear_queue():
    with queue_lock:
        playback_queue.clear()
    return {"status": "ok"}

@app.post("/api/queue/next")
async def play_next_in_queue():
    next_id = None
    with queue_lock:
        if playback_queue:
            next_item = playback_queue.pop(0)
            next_id = next_item.get("video_id") or next_item.get("track_id")
        elif runtime_state.get("is_hifi"):
            curr_clean = runtime_state.get("active_video_id", "").replace("hifi_", "")
            album_tracks, idx = hifi_manager.get_album_tracks_for_track(curr_clean)
            if album_tracks and idx >= 0:
                if runtime_state.get("shuffle") and len(album_tracks) > 1:
                    import random
                    pool = [i for i in range(len(album_tracks)) if i != idx]
                    next_idx = random.choice(pool) if pool else 0
                    next_id = "hifi_" + str(album_tracks[next_idx].get("track_id", ""))
                elif idx + 1 < len(album_tracks):
                    next_id = "hifi_" + str(album_tracks[idx + 1].get("track_id", ""))
                elif runtime_state.get("repeat") == "all":
                    next_id = "hifi_" + str(album_tracks[0].get("track_id", ""))
                else:
                    runtime_state["is_playing"] = False
                    runtime_state["pause_time"] = time.time()
                    return {"status": "ended", "message": "Album finished"}
            else:
                flat = hifi_manager.get_flat_tracks()
                if flat:
                    next_id = "hifi_" + str(flat[0].get("track_id", ""))
        else:
            return {"status": "empty"}
    if next_id and next_id.startswith("hifi_"):
        return activate_hifi_track(next_id)
    if next_id:
        return await set_active_track(next_id)
    return {"status": "empty"}

@app.post("/api/queue/prev")
async def play_prev_in_history():
    prev_id = None
    with queue_lock:
        if len(playback_history) >= 2:
            playback_history.pop()  # Pop current
            prev_id = playback_history.pop()
        elif runtime_state.get("is_hifi"):
            curr_clean = runtime_state.get("active_video_id", "").replace("hifi_", "")
            album_tracks, idx = hifi_manager.get_album_tracks_for_track(curr_clean)
            if album_tracks and idx >= 0:
                if runtime_state.get("shuffle") and len(album_tracks) > 1:
                    import random
                    pool = [i for i in range(len(album_tracks)) if i != idx]
                    prev_idx = random.choice(pool) if pool else 0
                    prev_id = "hifi_" + str(album_tracks[prev_idx].get("track_id", ""))
                elif idx - 1 >= 0:
                    prev_id = "hifi_" + str(album_tracks[idx - 1].get("track_id", ""))
                elif runtime_state.get("repeat") == "all":
                    prev_id = "hifi_" + str(album_tracks[-1].get("track_id", ""))
                else:
                    prev_id = "hifi_" + str(album_tracks[0].get("track_id", ""))
        elif len(playback_history) == 1:
            prev_id = playback_history[0]
        else:
            return {"status": "empty"}
    if prev_id and prev_id.startswith("hifi_"):
        return activate_hifi_track(prev_id)
    if prev_id:
        return await set_active_track(prev_id)
    return {"status": "empty"}

# --- Persistent Settings & System Endpoints ---

SETTINGS_FILE = "/data/juggler_settings.json" if os.path.isdir("/data") else os.path.join(os.path.dirname(__file__), "juggler_settings.json")
DEFAULT_SETTINGS = {
    "centerpiece_style": "chronometer",
    "idle_timeout_seconds": 120,
    "ambient_brightness": 100,
    "volume_ceiling": 100,
    "loudnorm_enabled": True,
    "apex_height_baseline": 416.2,
    "paddle_tilt_limit": 12.0,
    "selected_city": None,
    "custom_lat": None,
    "custom_lon": None
}

def load_settings() -> dict:
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                res = DEFAULT_SETTINGS.copy()
                res.update(data)
                return res
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()

def save_settings(data: dict) -> dict:
    current = load_settings()
    current.update(data)
    try:
        os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(current, f, indent=2)
    except Exception as e:
        print(f"[Settings Save Error] {e}")
    return current

def get_lan_ip() -> str:
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

@app.get("/api/settings")
async def get_settings():
    return load_settings()

@app.post("/api/settings")
async def update_settings(new_settings: Dict[str, Any]):
    return {"status": "ok", "settings": save_settings(new_settings)}

# --- Audiophile DAC & PipeWire Settings Endpoints ---

VENTUDAC_CTL = "/usr/local/bin/ventudac-ctl"
VENTUDAC_CONF = "/etc/ventudac.json"

@app.get("/api/audio/settings")
async def get_audio_settings():
    """Returns saved settings from /etc/ventudac.json and live DAC telemetry."""
    saved = {}
    if os.path.exists(VENTUDAC_CONF):
        try:
            with open(VENTUDAC_CONF, "r", encoding="utf-8") as f:
                saved = json.load(f)
        except Exception as e:
            pass
    
    live_readback = {}
    try:
        res = subprocess.run(
            ["sudo", VENTUDAC_CTL, "show"],
            capture_output=True, text=True, timeout=3
        )
        if res.returncode == 0:
            lines = res.stdout.splitlines()
            in_live = False
            for line in lines:
                if "Live DAC readback:" in line:
                    in_live = True
                    continue
                if in_live and line.strip():
                    parts = line.strip().split(maxsplit=1)
                    if len(parts) == 2:
                        live_readback[parts[0]] = parts[1]
    except Exception:
        pass
        
    return {
        "status": "ok",
        "settings": saved,
        "live": live_readback,
        "options": {
            "filter": ["ringless", "fir", "iir", "high-atten", "fixed"],
            "analog-gain": ["0", "-6"],
            "boost": ["on", "off"],
            "deemphasis": ["on", "off"],
            "channels": ["stereo", "swap", "mono-left", "mono-right", "left-only", "right-only"],
            "ramp": ["1/0.5dB", "1/1dB", "1/2dB", "1/4dB", "instant"],
            "auto-mute": ["off", "21ms", "106ms", "213ms", "533ms", "1.07s", "2.13s", "5.33s", "10.66s"],
            "pw-resample-quality": [4, 10, 12, 14],
            "pw-dither": ["none", "rectangular", "triangular", "triangular-hf", "wannamaker3", "lipshitz5"],
            "pw-hires": ["on", "off"],
            "pw-keep-awake": ["on", "off"],
            "mute": ["on", "off"],
            "balance": {"min": -12.0, "max": 12.0, "step": 0.5}
        }
    }

@app.post("/api/audio/settings")
async def update_audio_settings(payload: Dict[str, Any]):
    """Updates one or more audio settings and persists them via ventudac-ctl without dropping playback."""
    results = {}
    errors = {}
    is_playing = False
    with state_lock:
        is_playing = bool(runtime_state.get("is_playing"))
        
    for opt, val in payload.items():
        try:
            cmd = ["sudo", VENTUDAC_CTL, "set", str(opt), str(val)]
            if str(opt).startswith("pw-") and is_playing:
                cmd.append("--no-restart")
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=6)
            if res.returncode == 0:
                results[opt] = val
            else:
                errors[opt] = res.stderr.strip() or res.stdout.strip()
        except Exception as e:
            errors[opt] = str(e)
            
    return {"status": "ok" if not errors else "partial", "updated": results, "errors": errors}

@app.post("/api/audio/reset")
async def reset_audio_settings():
    """Resets all DAC Pro and PipeWire audio parameters to factory defaults."""
    is_playing = False
    with state_lock:
        is_playing = bool(runtime_state.get("is_playing"))
    cmd = ["sudo", VENTUDAC_CTL, "reset"]
    if is_playing:
        cmd.append("--no-restart")
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=6)
    return {"status": "ok" if res.returncode == 0 else "error", "message": res.stdout.strip() or res.stderr.strip()}

@app.post("/api/audio/preset/best-quality")
async def apply_best_quality_preset():
    """Applies reference audiophile preset across all 14 parameters without restarting during playback."""
    is_playing = False
    with state_lock:
        is_playing = bool(runtime_state.get("is_playing"))
    preset = {
        "filter": "ringless",
        "pw-resample-quality": "14",
        "pw-keep-awake": "on",
        "pw-hires": "on",
        "pw-dither": "lipshitz5",
        "ramp": "1/0.5dB",
        "analog-gain": "0",
        "boost": "off",
        "channels": "stereo",
        "balance": "0.0",
        "auto-mute": "off",
        "deemphasis": "off",
        "mute": "off"
    }
    for opt, val in preset.items():
        try:
            cmd = ["sudo", VENTUDAC_CTL, "set", opt, str(val)]
            if opt.startswith("pw-") and is_playing:
                cmd.append("--no-restart")
            subprocess.run(cmd, check=True, timeout=6)
        except Exception:
            pass
    return {"status": "ok", "preset": preset}

@app.post("/api/audio/volume")
async def set_hardware_dac_volume(payload: Dict[str, Any]):
    """Sets DAC digital volume directly (-103.5 to 0.0 dB). Lossless 32-bit path."""
    vol_db = payload.get("volume_db")
    if vol_db is None:
        vol_pct = payload.get("volume_pct")
        if vol_pct is not None:
            pct = max(0.0, min(100.0, float(vol_pct)))
            vol_db = 0.0 if pct >= 100.0 else (-60.0 + (pct / 100.0) * 60.0)
    if vol_db is not None:
        vol_db = max(-103.5, min(0.0, float(vol_db)))
        formatted = f"{vol_db:.1f}"
        subprocess.run(["sudo", VENTUDAC_CTL, "set", "volume", formatted], capture_output=True, text=True, timeout=2)
        return {"status": "ok", "volume_db": vol_db}
    raise HTTPException(status_code=400, detail="Missing volume_db or volume_pct")


@app.get("/api/system/ip")
async def get_system_ip():
    ip = get_lan_ip()
    return {"ip": ip, "web_url": f"http://{ip}:8080"}

@app.get("/api/system/qr.png")
async def get_system_qr():
    import io
    from fastapi.responses import Response
    ip = get_lan_ip()
    url = f"http://{ip}:8080"
    try:
        import qrcode
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=8,
            border=2,
        )
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#00E5FF", back_color="#080D1A")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return Response(content=buf.getvalue(), media_type="image/png")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/system/restart-services")
async def restart_services():
    subprocess.Popen(["sudo", "systemctl", "restart", "juggler_dial", "juggler_web"])
    return {"status": "restarting"}

@app.post("/api/search/history/clear")
async def clear_search_history():
    return {"status": "ok", "message": "Search history cleared"}

# --- Media Serving Endpoints ---

@app.get("/media/{video_id}/video.mp4")
async def serve_video(video_id: str):
    path = get_video_path(video_id)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Video file not found")
    return FileResponse(path, media_type="video/mp4")

@app.get("/media/{video_id}/audio.wav")
async def serve_audio(video_id: str):
    path = get_audio_path(video_id)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Audio file not found")
    return FileResponse(path, media_type="audio/wav")

@app.get("/media/{video_id}/cover.jpg")
async def serve_cover(video_id: str):
    path = get_cover_path(video_id)
    if not os.path.exists(path):
        # Fallback to generating cover on the fly
        v_path = get_video_path(video_id)
        if os.path.exists(v_path):
            subprocess.run([
                'ffmpeg', '-y', '-ss', '00:00:05', '-i', v_path,
                '-vframes', '1', '-vf', 'scale=512:512', path
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if os.path.exists(path):
        return FileResponse(path, media_type="image/jpeg")
    raise HTTPException(status_code=404, detail="Cover not found")

@app.get("/media/{video_id}/beats")
async def serve_beats(video_id: str):
    beats_path = get_beats_path(video_id)
    meta_path = get_meta_path(video_id)
    if not os.path.exists(beats_path) or not os.path.exists(meta_path):
        raise HTTPException(status_code=404, detail="Beats not found")
    beats_arr = np.load(beats_path).tolist()
    with open(meta_path, 'r', encoding='utf-8') as f:
        meta = json.load(f)
    return {
        "bpm": meta.get("bpm", 126.2),
        "beat_count": len(beats_arr),
        "beats": beats_arr
    }

@app.get("/media/{video_id}/dominant_color")
async def get_color(video_id: str):
    meta_path = get_meta_path(video_id)
    if os.path.exists(meta_path):
        with open(meta_path, 'r', encoding='utf-8') as f:
            meta = json.load(f)
        if "dominant_color" in meta:
            return {"color": meta["dominant_color"]}
        c = extract_dominant_color(get_video_path(video_id))
        meta["dominant_color"] = c
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(meta, f, indent=2)
        return {"color": c}
@app.get("/api/vision/stream")
async def stream_vision():
    if not HAS_VISION:
        raise HTTPException(status_code=503, detail="Vision manager unavailable")
    vm = vision_manager.get_vision_manager()
    if not vm.running:
        vm.start()
    return StreamingResponse(
        vm.gen_mjpeg_stream(),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )

@app.get("/api/vision/state")
async def get_vision_state():
    if not HAS_VISION:
        return {"status": "UNAVAILABLE", "balls": []}
    return vision_manager.get_vision_manager().get_telemetry_dict()

@app.post("/api/vision/control")
async def control_vision(request: Request):
    if not HAS_VISION:
        return {"status": "UNAVAILABLE"}
    data = await request.json()
    mode = data.get("color_mode")
    if mode:
        vision_manager.get_vision_manager().set_color_mode(mode)
    action = data.get("action")
    if action == "start":
        vision_manager.get_vision_manager().start()
    elif action == "stop":
        vision_manager.get_vision_manager().stop()
    return {"status": "ok", "state": vision_manager.get_vision_manager().get_telemetry_dict()}

@app.websocket("/ws/telemetry")
async def websocket_telemetry(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            t_now = time.time()
            timestamp_us = int(t_now * 1e6)
            with state_lock:
                live_bpm = runtime_state.get("current_bpm", 126.2)
                is_playing = runtime_state.get("is_playing", True)
                is_frozen = runtime_state.get("is_frozen", False)
                apex_base = runtime_state.get("apex_height_mm", 416.2)
                active_id = runtime_state.get("active_video_id", "DBHipNYuAZk")
                title = runtime_state.get("title", "")
                artist = runtime_state.get("artist", "")
                color = runtime_state.get("dominant_color", "#00E5FF")
                vol = runtime_state.get("volume", 80.0)

            beat_freq = (live_bpm / 60.0) if live_bpm > 0 else (103.0 / 60.0)
            phase = (t_now * beat_freq * 2.0 * np.pi) % (2.0 * np.pi) if is_playing else 0.0
            apex_height = (apex_base + 8.5 * math.sin(phase)) if not is_frozen else apex_base
            phase_error = 0.4 * math.sin(phase * 0.75)
            ball_state = "AIRBORNE" if math.sin(phase) > -0.6 else "CONTACT"

            telemetry = {
                "timestamp_us": timestamp_us,
                "track_id": active_id,
                "title": title,
                "artist": artist,
                "bpm": round(live_bpm, 1),
                "phase_error_ms": round(phase_error, 2),
                "beat_phase": round(phase / (2.0 * np.pi), 3),
                "apex_height_mm": round(apex_height, 1),
                "ball_state": ball_state,
                "is_frozen": is_frozen,
                "is_playing": is_playing,
                "dominant_color": color,
                "volume": vol,
                "hifi_catalog_version": runtime_state.get("hifi_catalog_version", 1),
                "hifi_sync_status": runtime_state.get("hifi_sync_status", "idle")
            }
            await websocket.send_json(telemetry)
            await asyncio.sleep(1.0 / 60.0)
    except (WebSocketDisconnect, Exception):
        pass

# --- Hi-Fi Lossless API & Google Drive Ingestion Endpoints ---

@app.get("/api/hifi/tree")
async def get_hifi_tree():
    import hifi_manager
    return hifi_manager.scan_library()

@app.get("/api/hifi/search")
async def search_hifi_endpoint(q: str = "", limit: int = 50):
    import hifi_manager
    return hifi_manager.search_library(query=q, limit=limit)

def run_background_sync(folder_url: Optional[str] = None):
    import sync_gdrive
    with state_lock:
        if runtime_state.get("hifi_sync_status") == "syncing":
            return
        runtime_state["hifi_sync_status"] = "syncing"
        runtime_state["hifi_sync_message"] = "Scanning Google Drive folders in parallel..."
    try:
        print(f"[Drive Sync] Starting background sync (url: {folder_url or 'default/saved'})...")
        sync_gdrive.sync(new_folder_url=folder_url)
        with state_lock:
            runtime_state["hifi_sync_status"] = "ready"
            runtime_state["hifi_sync_message"] = "Library updated successfully."
        trigger_catalog_update_broadcast()
        print("[Drive Sync] Successfully synced and updated library.")
    except Exception as e:
        print(f"[Drive Sync Error] {e}")
        with state_lock:
            runtime_state["hifi_sync_status"] = "error"
            runtime_state["hifi_sync_message"] = str(e)

@app.post("/api/hifi/scan")
async def trigger_hifi_scan():
    import hifi_manager
    threading.Thread(target=run_background_sync, daemon=True).start()
    return hifi_manager.scan_library(force=True)

@app.get("/api/hifi/cover")
async def get_hifi_cover(track_id: Optional[str] = None, rel_path: Optional[str] = None, key: Optional[str] = None):
    import hifi_manager
    if key:
        full = os.path.join(hifi_manager.COVERS_DIR, f"{key}.jpg")
        if os.path.isfile(full):
            return FileResponse(full, media_type="image/jpeg")
        # Try on-demand download if album has cover_gdrive_id in catalog
        cover_id = hifi_manager.find_cover_gdrive_id_by_key(key)
        if cover_id:
            try:
                url = f"https://drive.usercontent.google.com/download?id={cover_id}&export=download"
                r = requests.get(url, timeout=5)
                if r.status_code == 200 and len(r.content) > 1024:
                    with open(full, "wb") as f:
                        f.write(r.content)
                    return FileResponse(full, media_type="image/jpeg")
            except Exception:
                pass
    if rel_path:
        # Handles rel_path="covers/ABBA_1976 - Arrival.jpg"
        full = os.path.join(hifi_manager.HIFI_DIR, rel_path)
        if os.path.isfile(full):
            return FileResponse(full, media_type="image/jpeg")
    if track_id:
        clean_id = track_id.replace("hifi_", "")
        t = hifi_manager.find_track_by_id(clean_id)
        if t and t.get("cover_path") and os.path.isfile(t["cover_path"]):
            return FileResponse(t["cover_path"], media_type="image/jpeg")
    # Fallback to default vinyl placeholder or 404
    raise HTTPException(status_code=404, detail="Cover not found")

@app.get("/media/hifi/{track_id}/stream")
async def stream_hifi_track(track_id: str):
    import hifi_manager
    clean_id = track_id.replace("hifi_", "")
    fpath = hifi_manager.get_track_file_path(clean_id)
    if not fpath or not os.path.isfile(fpath):
        def _on_prog(downloaded, total):
            if total > 0:
                pct = int(downloaded / total * 100)
                with state_lock:
                    runtime_state["caching_video_id"] = f"hifi_{clean_id}"
                    runtime_state["caching_percent"] = pct
                    runtime_state["caching_progress"] = float(downloaded / total)
        cached = hifi_manager.ensure_track_cached(clean_id, progress_callback=_on_prog)
        fpath = cached.get("file_path")
        with state_lock:
            runtime_state["caching_video_id"] = None
            runtime_state["caching_percent"] = 100
            runtime_state["caching_progress"] = 1.0
    if not fpath or not os.path.isfile(fpath):
        raise HTTPException(status_code=404, detail="Audio file not found")
    media_type = "audio/flac" if fpath.endswith(".flac") else ("audio/x-dsf" if fpath.endswith(".dsf") else "audio/mpeg")
    return FileResponse(fpath, media_type=media_type)

@app.get("/media/hifi/{track_id}/beats")
async def get_hifi_beats(track_id: str):
    import hifi_manager
    clean_id = track_id.replace("hifi_", "")
    fpath = hifi_manager.get_track_file_path(clean_id)
    if not fpath:
        raise HTTPException(status_code=404, detail="Track not found")
    return hifi_manager.get_or_create_beats(fpath)

@app.get("/api/hifi/cache/stats")
async def get_hifi_cache_stats():
    import hifi_manager
    return hifi_manager.get_cache_stats()

@app.post("/api/hifi/cache/prune")
async def post_hifi_cache_prune():
    import hifi_manager
    hifi_manager.check_and_prune_cache()
    return hifi_manager.get_cache_stats()

class HiFiPlayRequest(BaseModel):
    track_id: str

@app.post("/api/hifi/play")
async def play_hifi_endpoint(req: HiFiPlayRequest):
    return activate_hifi_track(req.track_id)

class DriveSyncRequest(BaseModel):
    folder_url: Optional[str] = None

def trigger_catalog_update_broadcast():
    """Bumps hifi_catalog_version and triggers catalog reload across all listeners."""
    with state_lock:
        runtime_state["hifi_catalog_version"] = int(time.time() * 1000)
    print(f"[Library] Bumped hifi_catalog_version to {runtime_state['hifi_catalog_version']}")

@app.post("/api/hifi/notify_library_update")
async def notify_library_update():
    trigger_catalog_update_broadcast()
    return {"status": "ok", "version": runtime_state.get("hifi_catalog_version")}

@app.get("/api/hifi/drive_folders")
async def get_drive_folders():
    import sync_gdrive
    return {"folders": sync_gdrive.load_drive_folders()}

@app.post("/api/hifi/sync_drive")
async def sync_drive_endpoint(req: Optional[DriveSyncRequest] = None):
    target_url = req.folder_url if (req and req.folder_url and req.folder_url.strip()) else None
    threading.Thread(target=run_background_sync, args=(target_url,), daemon=True).start()
    return {"status": "started", "message": "Google Drive indexing started in background"}


@app.get("/api/hifi/sync_status")
async def get_hifi_sync_status():
    with state_lock:
        return {
            "status": runtime_state.get("hifi_sync_status", "idle"),
            "message": runtime_state.get("hifi_sync_message", "Ready"),
            "catalog_version": runtime_state.get("hifi_catalog_version", 1),
        }

class PlaybackModeRequest(BaseModel):
    shuffle: Optional[bool] = None
    repeat: Optional[str] = None  # "off", "all", "one"

@app.get("/api/playback/modes")
async def get_playback_modes():
    with state_lock:
        return {
            "shuffle": runtime_state.get("shuffle", False),
            "repeat": runtime_state.get("repeat", "all")
        }

@app.post("/api/playback/modes")
async def set_playback_modes(req: PlaybackModeRequest):
    with state_lock:
        if req.shuffle is not None:
            runtime_state["shuffle"] = req.shuffle
        if req.repeat is not None and req.repeat in ("off", "all", "one"):
            runtime_state["repeat"] = req.repeat
        return {
            "status": "ok",
            "shuffle": runtime_state.get("shuffle", False),
            "repeat": runtime_state.get("repeat", "all")
        }

class PlaylistCreateRequest(BaseModel):
    name: str
    tracks: Optional[List[Dict[str, Any]]] = None

class PlaylistAddRequest(BaseModel):
    tracks: Optional[List[Dict[str, Any]]] = None
    track: Optional[Dict[str, Any]] = None
    track_id: Optional[str] = None
    position: Optional[str] = "end"

class PlaylistRemoveRequest(BaseModel):
    track_id: Optional[str] = None
    index: Optional[int] = None

class PlaylistPlayRequest(BaseModel):
    shuffle: Optional[bool] = False

class FavoriteToggleRequest(BaseModel):
    track: Optional[Dict[str, Any]] = None
    track_id: Optional[str] = None

@app.get("/api/hifi/playlists")
async def list_playlists_endpoint():
    return {"playlists": hifi_playlists.get_all_playlists()}

@app.get("/api/hifi/playlists/{playlist_id}")
async def get_playlist_endpoint(playlist_id: str):
    pl = hifi_playlists.get_playlist(playlist_id)
    if not pl:
        raise HTTPException(status_code=404, detail="Playlist not found")
    return pl

@app.post("/api/hifi/playlists")
async def create_playlist_endpoint(req: PlaylistCreateRequest):
    return hifi_playlists.create_playlist(req.name, req.tracks)

@app.post("/api/hifi/playlists/{playlist_id}/add")
async def add_to_playlist_endpoint(playlist_id: str, req: PlaylistAddRequest):
    track_list = list(req.tracks) if req.tracks else []
    if req.track:
        track_list.append(req.track)
    elif req.track_id:
        t = hifi_manager.find_track_by_id(req.track_id)
        if t:
            track_list.append(t)
        else:
            track_list.append({"track_id": req.track_id, "title": "Track", "artist": "HiFi"})
    return hifi_playlists.add_to_playlist(playlist_id, track_list, req.position or "end")

@app.post("/api/hifi/playlists/{playlist_id}/remove")
async def remove_from_playlist_endpoint(playlist_id: str, req: PlaylistRemoveRequest):
    return hifi_playlists.remove_from_playlist(playlist_id, track_id=req.track_id, index=req.index)

@app.delete("/api/hifi/playlists/{playlist_id}")
async def delete_playlist_endpoint(playlist_id: str):
    if hifi_playlists.delete_playlist(playlist_id):
        return {"status": "ok"}
    raise HTTPException(status_code=400, detail="Cannot delete this playlist")

@app.post("/api/hifi/playlists/{playlist_id}/play")
async def play_playlist_endpoint(playlist_id: str, req: PlaylistPlayRequest = PlaylistPlayRequest()):
    pl = hifi_playlists.get_playlist(playlist_id)
    if not pl or not pl.get("tracks"):
        raise HTTPException(status_code=404, detail="Playlist is empty or not found")
    
    tracks = list(pl["tracks"])
    if req.shuffle:
        import random
        random.shuffle(tracks)
        
    first_track = tracks[0]
    first_id = str(first_track.get("track_id") or first_track.get("id"))
    
    with queue_lock:
        playback_queue.clear()
        for t in tracks[1:]:
            tid = str(t.get("track_id") or t.get("id"))
            playback_queue.append({
                "video_id": f"hifi_{tid}",
                "title": t.get("title", "Lossless Audio"),
                "artist": t.get("artist", "Unknown Artist"),
                "album": t.get("album", ""),
                "duration": t.get("duration", ""),
                "source": "hifi",
                "cover_key": t.get("key") or (f"{t.get('artist')}_{t.get('album')}".replace("/", "_").replace("\\", "_") if t.get("artist") and t.get("album") else ""),
                "is_cached": hifi_manager.is_track_cached(tid)
            })
            
    return activate_hifi_track(first_id)

@app.post("/api/hifi/favorites/toggle")
async def toggle_favorite_endpoint(req: FavoriteToggleRequest):
    tr = req.track
    if not tr and req.track_id:
        tr = hifi_manager.find_track_by_id(req.track_id) or {"track_id": req.track_id, "title": "Track"}
    if not tr:
        raise HTTPException(status_code=400, detail="Missing track or track_id")
    return {"is_favorite": hifi_playlists.toggle_favorite(tr)}

@app.get("/api/hifi/favorites/check")
async def check_favorite_endpoint(track_id: str):
    return {"track_id": track_id, "is_favorite": hifi_playlists.is_favorite(track_id)}

@app.get("/api/hifi/smart_playlist")
async def smart_playlist_endpoint(type: str = "random", artist: Optional[str] = None, limit: int = 50):
    flat_tracks = hifi_manager.search_library("", limit=5000)
    return hifi_playlists.generate_smart_playlist(type, flat_tracks, artist=artist, limit=limit)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

