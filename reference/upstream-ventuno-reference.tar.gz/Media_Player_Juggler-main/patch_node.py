import os

root_dir = '/home/arduino/ball_bouncer/yt_receiver/node_modules'
count = 0
for root, dirs, files in os.walk(root_dir):
    for f in files:
        if f.endswith('.js') or f.endswith('.mjs'):
            p = os.path.join(root, f)
            try:
                with open(p, 'r', encoding='utf-8') as fp:
                    content = fp.read()
                if "with { type: 'json' }" in content or 'with { type: "json" }' in content:
                    content = content.replace("with { type: 'json' }", "assert { type: 'json' }")
                    content = content.replace('with { type: "json" }', 'assert { type: "json" }')
                    with open(p, 'w', encoding='utf-8') as fp:
                        fp.write(content)
                    count += 1
            except Exception:
                pass

print(f"PATCHED_{count}_FILES")
