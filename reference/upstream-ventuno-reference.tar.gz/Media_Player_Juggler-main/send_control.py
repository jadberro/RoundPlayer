import urllib.request
import json
import sys

action = sys.argv[1] if len(sys.argv) > 1 else "stop_cast"
payload = {"action": action}
data = json.dumps(payload).encode("utf-8")
req = urllib.request.Request("http://127.0.0.1:8000/api/control", data=data, headers={"Content-Type": "application/json"})
with urllib.request.urlopen(req) as resp:
    print(resp.read().decode())
