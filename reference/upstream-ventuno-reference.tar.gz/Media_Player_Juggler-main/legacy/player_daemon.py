#!/usr/bin/env python3
"""Hardware MPV Player Controller & Ballistic Synchronizer.

Controls mpv over Unix IPC socket (/tmp/mpv.sock), routing video to DRM/KMS
and audio to ALSA plughw:0,0. Runs a 100 Hz phase-lock loop matching playback
position against the beat grid.
"""

import json
import os
import socket
import subprocess
import threading
import time

IPC_SOCKET = "/tmp/mpv.sock"


class MPVController:

  def __init__(
      self,
      video_output="drm",
      audio_output="alsa/plughw:0,0",
      use_fullscreen=True,
  ):
    self.video_output = video_output
    self.audio_output = audio_output
    self.use_fullscreen = use_fullscreen
    self.mpv_proc = None
    self.sock = None
    self.current_track = None
    self.beat_data = None
    self.current_time_pos = 0.0
    self.is_playing = False
    self.current_beat_num = 1
    self.current_beat_phase = 0.0
    self.lock = threading.Lock()
    self.running = True

    # Start MPV instance if not already running
    self._ensure_mpv_running()

    # Start 100Hz sync loop
    self.sync_thread = threading.Thread(target=self._sync_loop, daemon=True)
    self.sync_thread.start()

  def _ensure_mpv_running(self):
    if os.path.exists(IPC_SOCKET):
      try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(IPC_SOCKET)
        s.close()
        print("[MPV] Connected to existing mpv IPC socket")
        return
      except Exception:
        os.remove(IPC_SOCKET)

    # Launch mpv daemon
    cmd = [
        "mpv",
        "--idle=yes",
        f"--input-ipc-server={IPC_SOCKET}",
        f"--vo={self.video_output}",
        f"--ao={self.audio_output}",
        "--hwdec=auto",
        "--audio-samplerate=48000",
        "--audio-channels=stereo",
        "--volume=85",
        "--force-window=yes",
    ]
    if self.use_fullscreen:
      cmd.append("--fs")

    print(f"[MPV] Spawning mpv daemon: {' '.join(cmd)}")
    self.mpv_proc = subprocess.Popen(
        cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )

    # Wait for socket to become available
    for _ in range(30):
      if os.path.exists(IPC_SOCKET):
        time.sleep(0.1)
        break
      time.sleep(0.1)

  def send_ipc(self, command_list):
    """Sends a JSON command to the mpv IPC socket."""
    try:
      s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
      s.connect(IPC_SOCKET)
      payload = json.dumps({"command": command_list}) + "\n"
      s.sendall(payload.encode("utf-8"))
      resp = s.recv(4096).decode("utf-8")
      s.close()
      return json.loads(resp)
    except Exception as e:
      return {"error": str(e)}

  def load_media(self, media_path, beat_json_path=None):
    """Loads a media file into mpv and attaches its beat metadata."""
    with self.lock:
      self.current_track = media_path
      if beat_json_path and os.path.exists(beat_json_path):
        with open(beat_json_path, "r") as f:
          self.beat_data = json.load(f)
      else:
        self.beat_data = None

    self.send_ipc(["loadfile", os.path.abspath(media_path), "replace"])
    self.send_ipc(["set_property", "pause", False])
    self.is_playing = True
    print(f"[MPV] Loaded media: {media_path}")

  def play(self):
    self.send_ipc(["set_property", "pause", False])
    self.is_playing = True

  def pause(self):
    self.send_ipc(["set_property", "pause", True])
    self.is_playing = False

  def toggle_play(self):
    if self.is_playing:
      self.pause()
    else:
      self.play()

  def seek(self, seconds):
    self.send_ipc(["seek", seconds, "relative"])

  def set_volume(self, vol):
    vol = max(0, min(100, int(vol)))
    self.send_ipc(["set_property", "volume", vol])

  def get_status(self):
    with self.lock:
      return {
          "track": (
              os.path.basename(self.current_track)
              if self.current_track
              else None
          ),
          "time_pos": round(self.current_time_pos, 2),
          "is_playing": self.is_playing,
          "bpm": self.beat_data.get("bpm", 0) if self.beat_data else 0,
          "target_apex_cm": (
              self.beat_data.get("target_apex_cm", 0) if self.beat_data else 0
          ),
          "launch_v0_mps": (
              self.beat_data.get("launch_v0_mps", 0) if self.beat_data else 0
          ),
          "beat_num": self.current_beat_num,
          "beat_phase": round(self.current_beat_phase, 3),
      }

  def _sync_loop(self):
    """100 Hz high-precision phase-lock loop."""
    while self.running:
      time.sleep(0.01)  # 10ms tick (100 Hz)

      # Query time-pos from mpv
      res = self.send_ipc(["get_property", "time-pos"])
      if res and "data" in res and res["data"] is not None:
        pos = float(res["data"])
        with self.lock:
          self.current_time_pos = pos

          # Interpolate beat phase
          if self.beat_data and "beat_period" in self.beat_data:
            t0 = self.beat_data.get("first_beat", 0.0)
            t_period = self.beat_data.get("beat_period", 0.5)

            if pos >= t0:
              elapsed_beats = (pos - t0) / t_period
              beat_idx = int(elapsed_beats)
              self.current_beat_num = (beat_idx % 4) + 1
              self.current_beat_phase = elapsed_beats - beat_idx
            else:
              self.current_beat_num = 1
              self.current_beat_phase = 0.0


if __name__ == "__main__":
  import sys

  player = MPVController()
  if len(sys.argv) > 1:
    media = sys.argv[1]
    beats = (
        sys.argv[2]
        if len(sys.argv) > 2
        else os.path.splitext(media)[0] + "_beats.json"
    )
    player.load_media(media, beats)
    print("Playing... Press Ctrl+C to stop.")
    try:
      while True:
        status = player.get_status()
        print(
            f"\r[STATUS] Time: {status['time_pos']}s | Beat"
            f" {status['beat_num']} (Phase: {status['beat_phase']:.2f}) | Apex:"
            f" {status['target_apex_cm']} cm",
            end="",
        )
        time.sleep(0.05)
    except KeyboardInterrupt:
      player.pause()
