#!/usr/bin/env python3
"""Ventuno Q Jukebox Engine & Ballistic Metronome Server.

Provides a unified REST API and mobile/plinth web app to:
1. Search YouTube & YouTube Music via yt-dlp.
2. Auto-cache ad-free 720p video & pristine 48kHz audio.
3. Automatically compute beat timestamps & ballistic trajectory plans.
4. Drive hardware video to the 5" screen and audio to the headphone amp via mpv.
"""

import json
import os
import subprocess
import threading
from flask import Flask, jsonify, request, send_from_directory
from beat_tracker import analyze_beats

app = Flask(__name__, static_folder='.')

LIBRARY_DIR = os.path.abspath("library")
os.makedirs(LIBRARY_DIR, exist_ok=True)

@app.route('/')
def index():
    return send_from_directory('.', 'round_display_ui.html')

@app.route('/media/<path:filename>')
def serve_media(filename):
    return send_from_directory('.', filename)

CURRENT_TRACK_META = {
    "title": "Dua Lipa — Levitating",
    "artist": "Dua Lipa",
    "bpm": 103.0,
    "target_apex_cm": 41.6,
    "thumbnail": "https://img.youtube.com/vi/TUVcZfQe-Kw/hqdefault.jpg",
}

# Check if local levitating file exists from earlier
LOCAL_LEVITATING = os.path.abspath("levitating.mp4.webm")
if os.path.exists(LOCAL_LEVITATING):
  beat_file = os.path.splitext(LOCAL_LEVITATING)[0] + "_beats.json"
  if not os.path.exists(beat_file):
    try:
      analyze_beats(LOCAL_LEVITATING, beat_file)
    except Exception as e:
      print(f"[INIT] Beat analyze warning: {e}")

@app.route("/api/status", methods=["GET"])
def get_status():
  return jsonify(CURRENT_TRACK_META)


@app.route("/api/volume", methods=["POST"])
def set_volume():
  data = request.json or {}
  vol = data.get("volume", 85)
  player.set_volume(vol)
  return jsonify({"volume": vol})


@app.route("/api/seek", methods=["POST"])
def seek():
  data = request.json or {}
  secs = data.get("seconds", 10)
  player.seek(secs)
  return jsonify({"seek": secs})


@app.route("/api/search", methods=["GET"])
def search_youtube():
  query = request.args.get("q", "")
  if not query:
    return jsonify([])

  cmd = [
      "yt-dlp",
      "--default-search",
      "ytsearch5",
      "--dump-json",
      "--no-playlist",
      f"ytsearch5:{query}",
  ]
  try:
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL
    )
    stdout, _ = proc.communicate(timeout=12)
    results = []
    for line in stdout.decode("utf-8").strip().split("\n"):
      if line:
        entry = json.loads(line)
        results.append({
            "id": entry.get("id"),
            "title": entry.get("title"),
            "artist": entry.get("uploader", "Unknown Artist"),
            "duration": entry.get("duration", 0),
            "thumbnail": entry.get("thumbnail"),
            "url": entry.get("webpage_url"),
        })
    return jsonify(results)
  except Exception as e:
    return jsonify({"error": str(e)}), 500


@app.route("/api/load", methods=["POST"])
def load_track():
  data = request.json or {}
  video_url = data.get("url") or f"https://www.youtube.com/watch?v={data.get('id')}"
  title = data.get("title", "Unknown Track")
  artist = data.get("artist", "")
  thumb = data.get("thumbnail", "")

  def download_and_play():
    global CURRENT_TRACK_META
    print(f"[LOAD] Processing track: {title} ({video_url})")
    out_template = os.path.join(LIBRARY_DIR, "%(id)s.%(ext)s")

    # Download best 720p video + best audio
    cmd = [
        "yt-dlp",
        "-f",
        "bestvideo[height<=720]+bestaudio/best[height<=720]",
        "-o",
        out_template,
        "--no-playlist",
        video_url,
    ]
    subprocess.run(cmd, check=True)

    # Find the resulting file
    vid_id = data.get("id") or "download"
    matching = [
        os.path.join(LIBRARY_DIR, f)
        for f in os.listdir(LIBRARY_DIR)
        if vid_id in f and not f.endswith(".json")
    ]
    if not matching:
      return
    media_path = matching[0]

    # Analyze beat grid
    beat_path = os.path.splitext(media_path)[0] + "_beats.json"
    beats = analyze_beats(media_path, beat_path)

    CURRENT_TRACK_META = {
        "title": title,
        "artist": artist,
        "bpm": beats["bpm"],
        "target_apex_cm": beats["target_apex_cm"],
        "thumbnail": thumb,
    }

    # Load into hardware player
    player.load_media(media_path, beat_path)

  threading.Thread(target=download_and_play, daemon=True).start()
  return jsonify({"status": "downloading", "title": title})


# -------------------------------------------------------------
# Mobile & Plinth Web Interface
# -------------------------------------------------------------
HTML_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Ventuno Juggler Console</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
</head>
<body class="bg-slate-950 text-slate-100 antialiased min-h-screen p-4 flex flex-col items-center">
  <div class="w-full max-w-md flex flex-col gap-5">
    
    <!-- Top Status Header -->
    <div class="flex items-center justify-between border-b border-slate-800 pb-3">
      <div class="flex items-center gap-2">
        <span class="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
        <span class="font-bold text-sm tracking-wider uppercase">Ventuno Q Jukebox</span>
      </div>
      <span class="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-400">
        HARDWARE DRM • ALSA
      </span>
    </div>

    <!-- Active Track Card with Circular Beat Dial -->
    <div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl flex flex-col items-center relative overflow-hidden">
      
      <!-- Pulsing Beat Halo -->
      <div id="halo" class="absolute w-48 h-48 rounded-full border-4 border-rose-500/20 opacity-0 scale-75 transition-all duration-100 pointer-events-none"></div>

      <!-- Album Art Thumbnail -->
      <div class="w-32 h-32 rounded-full overflow-hidden border-2 border-rose-500/60 shadow-xl mb-3 relative flex items-center justify-center bg-slate-950">
        <img id="thumbImg" src="https://img.youtube.com/vi/TUVcZfQe-Kw/hqdefault.jpg" class="w-full h-full object-cover">
        <div id="spindle" class="absolute w-5 h-5 rounded-full bg-slate-950 border-2 border-rose-400"></div>
      </div>

      <!-- Track Metadata -->
      <div class="text-center">
        <div class="font-extrabold text-base text-white tracking-tight" id="trackTitle">Dua Lipa — Levitating</div>
        <div class="text-xs text-rose-400 font-semibold font-mono mt-0.5" id="trackArtist">Dua Lipa</div>
      </div>

      <!-- Real-Time Ballistic Telemetry -->
      <div class="flex items-center gap-3 mt-4 text-xs font-mono">
        <div class="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
          <div class="text-slate-400 text-[10px]">TEMPO</div>
          <div class="text-rose-400 font-bold text-sm" id="bpmVal">103 BPM</div>
        </div>
        <div class="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
          <div class="text-slate-400 text-[10px]">BEAT</div>
          <div class="text-white font-extrabold text-sm" id="beatVal">BEAT 1</div>
        </div>
        <div class="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
          <div class="text-slate-400 text-[10px]">APEX</div>
          <div class="text-cyan-400 font-bold text-sm" id="apexVal">41.6 cm</div>
        </div>
      </div>

      <!-- Playback Transport Controls -->
      <div class="flex items-center gap-4 mt-5">
        <button onclick="seek(-10)" class="w-10 h-10 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center transition active:scale-90">
          -10s
        </button>
        <button id="playBtn" onclick="togglePlay()" class="px-6 py-3 rounded-full bg-rose-500 hover:bg-rose-400 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-rose-500/30 transition active:scale-95">
          <span id="playIcon">⏸ PAUSE</span>
        </button>
        <button onclick="seek(10)" class="w-10 h-10 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center transition active:scale-90">
          +10s
        </button>
      </div>

      <!-- Volume Slider -->
      <div class="w-full flex items-center gap-3 mt-5 px-4 text-xs font-mono text-slate-400">
        <span>VOL:</span>
        <input type="range" min="0" max="100" value="85" oninput="setVol(this.value)" class="w-full accent-rose-500 cursor-pointer">
        <span id="volVal" class="w-8 text-right font-bold text-white">85%</span>
      </div>
    </div>

    <!-- YouTube Music Search Section -->
    <div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col gap-3">
      <div class="font-bold text-xs uppercase tracking-wider text-slate-300">🔍 Search YouTube & YouTube Music</div>
      <div class="flex items-center gap-2">
        <input id="searchInput" type="text" placeholder="Search track, artist, or paste URL..." onkeydown="if(event.key==='Enter') searchMusic()" class="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500">
        <button onclick="searchMusic()" class="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs transition cursor-pointer">
          Search
        </button>
      </div>
      
      <!-- Results List -->
      <div id="resultsList" class="flex flex-col gap-2 mt-1 max-h-60 overflow-y-auto"></div>
    </div>

  </div>

  <script>
    let isPlaying = true;
    let lastBeat = -1;

    // Poll status at 20 Hz
    setInterval(async () => {
      try {
        const res = await fetch('/api/status');
        const st = await res.json();
        
        document.getElementById('trackTitle').innerText = st.title || 'Dua Lipa — Levitating';
        document.getElementById('trackArtist').innerText = st.artist || '';
        document.getElementById('bpmVal').innerText = Math.round(st.bpm) + ' BPM';
        document.getElementById('apexVal').innerText = st.target_apex_cm + ' cm';
        document.getElementById('beatVal').innerText = 'BEAT ' + st.beat_num;
        if (st.thumbnail) document.getElementById('thumbImg').src = st.thumbnail;

        // Visual Beat Ripple Trigger
        if (st.beat_num !== lastBeat) {
          lastBeat = st.beat_num;
          const halo = document.getElementById('halo');
          halo.style.opacity = '0.9';
          halo.style.transform = 'scale(1.15)';
          setTimeout(() => {
            halo.style.opacity = '0';
            halo.style.transform = 'scale(0.85)';
          }, 110);
        }

        isPlaying = st.is_playing;
        document.getElementById('playIcon').innerText = isPlaying ? '⏸ PAUSE' : '▶ PLAY';
      } catch(e) {}
    }, 50);

    async function togglePlay() {
      await fetch('/api/play_pause', { method: 'POST' });
    }

    async function seek(sec) {
      await fetch('/api/seek', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ seconds: sec })
      });
    }

    async function setVol(v) {
      document.getElementById('volVal').innerText = v + '%';
      await fetch('/api/volume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ volume: parseInt(v) })
      });
    }

    async function searchMusic() {
      const q = document.getElementById('searchInput').value.trim();
      if (!q) return;
      const list = document.getElementById('resultsList');
      list.innerHTML = '<div class="text-xs text-rose-400 font-mono text-center py-2">Searching YouTube...</div>';
      
      const res = await fetch('/api/search?q=' + encodeURIComponent(q));
      const items = await res.json();
      list.innerHTML = '';

      items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-rose-500/50 cursor-pointer transition';
        div.onclick = () => loadTrack(item);
        div.innerHTML = `
          <div class="flex items-center gap-2.5 overflow-hidden pr-2">
            <img src="${item.thumbnail}" class="w-10 h-10 rounded-lg object-cover flex-shrink-0">
            <div class="overflow-hidden text-left">
              <div class="font-bold text-xs text-slate-100 truncate">${item.title}</div>
              <div class="text-[10px] text-slate-400 truncate">${item.artist}</div>
            </div>
          </div>
          <button class="px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-bold flex-shrink-0">
            Play
          </button>
        `;
        list.appendChild(div);
      });
    }

    async function loadTrack(item) {
      alert('Downloading & Analyzing: ' + item.title);
      await fetch('/api/load', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(item)
      });
    }
  </script>
</body>
</html>
"""


@app.route("/")
def index():
  return render_template_string(HTML_PAGE)


if __name__ == "__main__":
  print("=" * 60)
  print("🚀 Ventuno Jukebox Engine & Ballistic Metronome Live!")
  print("   Control from your phone or Mac at: http://192.168.0.214:8080")
  print("=" * 60)
  app.run(host="0.0.0.0", port=8080)
