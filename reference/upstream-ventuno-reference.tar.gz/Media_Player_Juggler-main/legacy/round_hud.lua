-- round_hud.lua: Apple-Grade Horological HUD for 5" Screen (Full-Bleed, Ultra-Smooth Silk Wave)
-- 
-- Refinements:
-- 1. Full-Bleed 5-Inch Match: Expanded radius to 0.495 * display dimension so UI reaches the physical aluminum bezel.
-- 2. Liquid Smooth Wave: Increased points to 85 (step size < 6px) and switched to gentle, majestic low-frequency harmonics (S-curve swell like the reference image).
-- 3. Multi-layer Silk Transparency: Delicate pearl & ice-blue filaments weaving without sharp angles or jagged vertices.
-- 4. Perfectly balanced Apple horological complications at native 60 FPS hardware scanout.

local mp = require 'mp'

local bpm = 103.0
local beat_period = 60.0 / bpm -- 0.5825s
local first_beat_offset = 0.22

local last_beat_idx = -1
local beat_spring = 0.0

local ov = mp.create_osd_overlay("ass-events")

local function update_hud()
    local pos = mp.get_property_number("time-pos")
    if not pos then
        ov:remove()
        return
    end

    local dims = mp.get_property_native("osd-dimensions")
    local ow = (dims and dims.w) or mp.get_property_number("osd-width") or 1080
    local oh = (dims and dims.h) or mp.get_property_number("osd-height") or 1080

    ov.res_x = ow
    ov.res_y = oh

    local cx = math.floor(ow / 2)
    local cy = math.floor(oh / 2)
    -- True full-bleed radius for 5" physical circular glass (49.5% of display)
    local radius = math.floor(math.min(ow, oh) * 0.495)

    -- Beat phase calculation
    local adjusted_time = pos - first_beat_offset
    local beat_fraction = 0.0
    if adjusted_time > 0 then
        local total_beats = adjusted_time / beat_period
        local beat_idx = math.floor(total_beats)
        beat_fraction = total_beats - beat_idx
        if beat_idx ~= last_beat_idx then
            last_beat_idx = beat_idx
            beat_spring = 1.0
        end
    end

    beat_spring = beat_spring * 0.85
    if beat_spring < 0.01 then beat_spring = 0.0 end
    local beat_pulse = math.exp(-beat_fraction * 4.5)

    local events = {}

    -- =========================================================================
    -- 1. LIQUID SILK RIBBON WAVE (Ultra-Smooth 85-Point Harmonics)
    -- =========================================================================
    -- Low frequency broad S-curves matching the reference photo
    local r_base = radius * 0.88
    local base_amp = 36 + beat_pulse * 32
    local pts = 85 -- Sub-pixel smoothness, zero jagged polygonal corners

    for i = 1, 8 do
        local offset = (i / 8.0)
        -- Translucent pearl/ice-blue gradient layers
        local alpha_val = math.floor((0.28 + math.sin(offset * math.pi) * 0.48 + beat_pulse * 0.18) * 255)
        local alpha_hex = string.format("%02X", math.max(15, math.min(235, 255 - alpha_val)))
        
        -- Forward points (top edge of filament)
        local top_pts = {}
        for p = 0, pts do
            local t = p / pts
            -- Arc sweeps broadly from 0.74 PI (lower-left) around bottom to 1.94 PI (mid-upper-right)
            local angle = math.pi * 0.74 + t * (math.pi * 1.20)
            
            -- Broad, majestic ocean-swell harmonics (NO sharp teeth)
            local wave1 = math.sin(t * 2.8 - pos * 2.6 + offset * 1.8)
            local wave2 = math.cos(t * 5.2 + pos * 1.8 - offset * 1.2)
            local disp = (wave1 * 0.72 + wave2 * 0.28) * base_amp * (1.0 - math.abs(t - 0.5) * 0.45)
            
            local pr = r_base - 52 + disp + (offset * 32)
            local px = math.floor(cx + math.cos(angle) * pr)
            local py = math.floor(cy + math.sin(angle) * pr)
            table.insert(top_pts, { x = px, y = py, angle = angle, pr = pr })
        end

        -- Build closed polygon: Forward on top, Return on bottom with 2.2px thickness
        local path = string.format("{\\pos(0,0)\\p1\\c&HFFFFFF&\\alpha&H%s&\\bord0}", alpha_hex)
        -- Forward
        for p = 1, #top_pts do
            if p == 1 then
                path = path .. string.format("m %d %d ", top_pts[p].x, top_pts[p].y)
            else
                path = path .. string.format("l %d %d ", top_pts[p].x, top_pts[p].y)
            end
        end
        -- Return backward
        local thickness = 2.2
        for p = #top_pts, 1, -1 do
            local bot_pr = top_pts[p].pr + thickness
            local bx = math.floor(cx + math.cos(top_pts[p].angle) * bot_pr)
            local by = math.floor(cy + math.sin(top_pts[p].angle) * bot_pr)
            path = path .. string.format("l %d %d ", bx, by)
        end
        path = path .. "{\\p0}"
        table.insert(events, path)
    end

    -- =========================================================================
    -- 2. TOP CIRCULAR PROGRESS ARC & YOUTUBE CAPSULE
    -- =========================================================================
    local arc_y = cy - math.floor(radius * 0.96)
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs12\\c&H475569&\\shad1\\4c&H000000&}──────────  {\\c&HFFFFFF&\\b1}──────────────────  {\\c&H475569&\\b0}──────────",
        cx, arc_y
    ))

    local search_y = cy - math.floor(radius * 0.84)
    local pill_w = 176
    local pill_h = 34
    local px1, py1 = cx - pill_w / 2, search_y - pill_h / 2
    local px2, py2 = cx + pill_w / 2, search_y + pill_h / 2
    table.insert(events, string.format(
        "{\\pos(0,0)\\p1\\c&H080C16&\\alpha&H40&\\bord1\\3c&H334155&\\3a&H50&}m %d %d l %d %d l %d %d l %d %d {\\p0}",
        px1, py1, px2, py1, px2, py2, px1, py2
    ))
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs16\\bord0\\shad2\\4c&H000000&}" ..
        "{\\c&H0000FF&}▶ {\\b1\\c&HFFFFFF&}YouTube{\\b0\\c&H64748B&}  │  " ..
        "{\\c&HE2E8F0&}Search  {\\fs14\\c&H94A3B8&}⌕  🎙",
        cx, search_y
    ))

    -- =========================================================================
    -- 3. LEFT COMPLICATION: 103 BPM + PHASE LOCK
    -- =========================================================================
    local left_x = cx - math.floor(radius * 0.65)
    local left_y = cy - math.floor(radius * 0.15)
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs42\\b1\\c&HFFFFFF&\\bord0\\shad3\\4c&H000000&}103 {\\fs18\\b0\\c&HE2E8F0&}BPM",
        left_x, left_y
    ))
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs13\\b1\\bord0\\shad2\\4c&H000000&}" ..
        "{\\c&H34D399&}● {\\c&H94A3B8&\\fsp2}PHASE LOCK",
        left_x, left_y + 30
    ))

    -- =========================================================================
    -- 4. RIGHT COMPLICATION: VERTICAL ATTITUDE CAPSULE (ROLL / PITCH)
    -- =========================================================================
    local right_x = cx + math.floor(radius * 0.78)
    local right_y = cy + 10
    local rpx1, rpy1 = right_x - 22, right_y - 28
    local rpx2, rpy2 = right_x + 22, right_y + 28
    table.insert(events, string.format(
        "{\\pos(0,0)\\p1\\c&H080C16&\\alpha&H40&\\bord1\\3c&H334155&\\3a&H50&}m %d %d l %d %d l %d %d l %d %d {\\p0}",
        rpx1, rpy1, rpx2, rpy1, rpx2, rpy2, rpx1, rpy2
    ))
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs14\\b1\\bord0\\shad2\\4c&H000000&}" ..
        "{\\c&HFFFFFF&}Roll\\N{\\fs8\\c&H64748B&}─────\\N{\\fs14\\c&H94A3B8&}Pitch",
        right_x, right_y
    ))

    -- =========================================================================
    -- 5. BOTTOM COMPLICATION: 3-RRS ROBOT PADDLE & BOUNCING BALL AT APEX
    -- =========================================================================
    local bot_y = cy + math.floor(radius * 0.75)

    -- Dynamic Ball Bouncing (parabolic apex trajectory)
    local ball_hop = math.floor(math.sin(beat_fraction * math.pi) * 22.0)
    local ball_y = bot_y - 32 - ball_hop
    table.insert(events, string.format("{\\an5\\pos(%d,%d)\\fs22\\c&HFFFFFF&\\blur1\\shad2\\4c&H000000&}●", cx, ball_y))

    -- Trajectory radiating pips
    table.insert(events, string.format("{\\an5\\pos(%d,%d)\\fs12\\c&H94A3B8&\\shad1\\4c&H000000&}·   ·   ·", cx, bot_y - 22))

    -- Kinematic Platform Base & Linkage Arms
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs16\\c&HE2E8F0&\\shad2\\4c&H000000&}╱───╲",
        cx, bot_y - 10
    ))
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs14\\b1\\c&H64748B&\\shad2\\4c&H000000&}▲",
        cx, bot_y - 2
    ))

    -- Precision Telemetry Text
    table.insert(events, string.format(
        "{\\an5\\pos(%d,%d)\\fnUbuntu,DejaVu Sans\\fs15\\c&H94A3B8&\\bord0\\shad2\\4c&H000000&}" ..
        "Precision Impact: {\\b1\\c&HFFFFFF&}41.6 CM",
        cx, bot_y + 20
    ))

    ov.data = table.concat(events, "\n")
    ov:update()
end

local timer = mp.add_periodic_timer(0.016, update_hud)

mp.register_event("end-file", function()
    ov:remove()
end)
