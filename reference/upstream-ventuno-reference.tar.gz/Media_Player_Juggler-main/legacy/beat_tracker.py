#!/usr/bin/env python3
"""High-speed beat and kick-drum onset detector for the Ventuno Q Juggler.

Uses ffmpeg and numpy to extract low-frequency energy transients (kick drums)
and generate a millisecond-precision beat grid for any audio/video file.
"""

import json
import os
import subprocess
import numpy as np


def analyze_beats(media_path, output_json_path=None):
  """Extracts BPM and exact beat timestamps from a media file."""
  print(f"[BEAT] Analyzing beats for: {media_path}")

  # 1. Extract 16kHz mono audio via ffmpeg to raw PCM pipe
  cmd = [
      "ffmpeg",
      "-i",
      media_path,
      "-vn",
      "-ac",
      "1",
      "-ar",
      "16000",
      "-f",
      "s16le",
      "-",
  ]
  proc = subprocess.Popen(
      cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL
  )
  raw_bytes, _ = proc.communicate()

  if len(raw_bytes) < 32000:
    raise ValueError("Audio stream too short or failed to decode")

  samples = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
  sample_rate = 16000
  duration = len(samples) / sample_rate

  # 2. Low-pass filter to isolate kick drum energy (< 150 Hz)
  # Simple moving average / integrator on raw rectified signal
  window_size = int(sample_rate * 0.02)  # 20ms window
  energy = np.convolve(np.abs(samples), np.ones(window_size) / window_size, mode="same")

  # 3. Compute energy novelty curve (first derivative)
  diff = np.diff(energy, prepend=0)
  novelty = np.maximum(0, diff)

  # Normalize novelty curve
  if np.max(novelty) > 0:
    novelty /= np.max(novelty)

  # 4. Auto-correlation to estimate global BPM (between 70 and 180 BPM)
  min_bpm, max_bpm = 70.0, 180.0
  min_lag = int(sample_rate * (60.0 / max_bpm))
  max_lag = int(sample_rate * (60.0 / min_bpm))

  # Downsample novelty for fast auto-correlation (100 Hz sampling rate)
  hop = 160
  novelty_ds = novelty[::hop]
  min_lag_ds = min_lag // hop
  max_lag_ds = max_lag // hop

  corr = np.correlate(novelty_ds, novelty_ds, mode="full")
  corr_half = corr[len(novelty_ds) - 1 :]
  valid_corr = corr_half[min_lag_ds:max_lag_ds]

  best_lag_ds = min_lag_ds + np.argmax(valid_corr)
  beat_period_sec = (best_lag_ds * hop) / sample_rate
  estimated_bpm = 60.0 / beat_period_sec

  # Clean rounding to standard pop tempos
  bpm_rounded = round(estimated_bpm, 1)

  # 5. Extract peak downbeat timestamps
  threshold = np.mean(novelty) + 1.8 * np.std(novelty)
  peaks = []
  min_peak_dist = int(sample_rate * (beat_period_sec * 0.65))

  last_peak = -min_peak_dist
  for i in range(len(novelty)):
    if novelty[i] > threshold and (i - last_peak) > min_peak_dist:
      # Local maximum search within +/- 15ms
      local_win = novelty[max(0, i - 240) : min(len(novelty), i + 240)]
      if len(local_win) > 0 and novelty[i] >= np.max(local_win):
        t_sec = i / sample_rate
        peaks.append(round(t_sec, 4))
        last_peak = i

  # 6. Fit regular beat lattice
  first_beat = peaks[0] if len(peaks) > 0 else 0.0
  regular_beats = []
  t_curr = first_beat
  while t_curr < duration:
    regular_beats.append(round(t_curr, 4))
    t_curr += beat_period_sec

  result = {
      "bpm": bpm_rounded,
      "beat_period": round(beat_period_sec, 4),
      "duration": round(duration, 2),
      "first_beat": round(first_beat, 4),
      "target_apex_cm": round((981.0 / 8.0) * (beat_period_sec**2), 2),
      "launch_v0_mps": round(9.81 * (beat_period_sec / 2.0), 2),
      "beat_timestamps": regular_beats,
  }

  if output_json_path:
    with open(output_json_path, "w") as f:
      json.dump(result, f, indent=2)

  print(
      f"[BEAT] Analysis complete: {bpm_rounded} BPM | Apex:"
      f" {result['target_apex_cm']} cm | Total beats: {len(regular_beats)}"
  )
  return result


if __name__ == "__main__":
  import sys

  if len(sys.argv) > 1:
    media = sys.argv[1]
    out = (
        sys.argv[2]
        if len(sys.argv) > 2
        else os.path.splitext(media)[0] + "_beats.json"
    )
    analyze_beats(media, out)
  else:
    print("Usage: python3 beat_tracker.py <media_file> [output_json]")
