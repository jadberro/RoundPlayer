import urllib.request
import json
import sys

port = sys.argv[1] if len(sys.argv) > 1 else "8080"
track_id = sys.argv[2] if len(sys.argv) > 2 else "hifi_8e32cc74e6cc"

url = f"http://127.0.0.1:{port}/api/hifi/play"
data = json.dumps({"track_id": track_id}).encode('utf-8')
headers = {"Content-Type": "application/json"}

req = urllib.request.Request(url, data=data, headers=headers, method="POST")
with urllib.request.urlopen(req, timeout=5) as resp:
    print(resp.read().decode('utf-8'))
