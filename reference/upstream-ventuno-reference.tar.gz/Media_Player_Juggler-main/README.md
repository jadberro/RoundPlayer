# 3-RRS Ballistic Juggler & Round HUD

A high-speed, music-synchronized 3-RRS parallel robotic mechanism that bounces a ball to music beats, paired with a custom 1080×1080 circular HUD display and mobile web remote.

---

## 🌟 System Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Mobile Web Remote (Port 8080)                  │
│       • YouTube / Shorts / URL Casting  • Tactile Jogs  • Queue        │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ HTTP / WebSocket (Proxy)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│             Master Playback Manager Daemon (playback_manager.py)       │
│       • 1080p Caching Pipeline     • Aubio Beat & Onset Extraction     │
│       • Weather & Circadian Engine • 60 Hz Unix Telemetry Socket       │
└───────────────┬───────────────────────────────────┬────────────────────┘
                │                                   │ /tmp/juggler_telemetry.sock
                ▼                                   ▼
┌───────────────────────────────────┐   ┌────────────────────────────────┐
│   Hardware Mechanism & Kinematics │   │   Round HUD Kiosk App (Flutter)│
│   • 3-RRS Delta Parallel Linkage  │   │   • 1080×1080 Round Display    │
│   • SimpleFOC Motor Drivers       │   │   • EGL Hardware Video Deck    │
│   • High-speed Optical Ball Track │   │   • Ambient Circadian Clock    │
└───────────────────────────────────┘   └────────────────────────────────┘
```

---

## 🚀 Key Modules

### 1. Master Playback Manager (`playback_manager.py`)
- **Deterministic 1080p Pipeline**: Ingests, scales, and prepares high-bitrate video while streaming.
- **Aubio Beat & Onset Analysis**: Extracts precise timestamps and tempo (`beats.npy`) for microsecond robotic bounce synchronisation.
- **Dynamic Aura & Circadian Engine**: Derives dominant colour palettes and harmonises the ambient HUD clock with live weather conditions and solar hour.
- **High-Rate Telemetry**: Broadcasts at 60 Hz over `/tmp/juggler_telemetry.sock` (BPM, phase error, apex height, ball state, pitch, and roll).

### 2. Round HUD Flutter App (`round_hud_app/`)
- Custom-built for 5-inch 1080×1080 round circular capacitive touchscreen.
- **Direct Hardware Decoding**: Uses `media_kit` with EGL hardware-accelerated video rendering.
- **Dynamic Centerpiece**: Ambient idle clock featuring weather telemetry and circadian twilight tones.
- **Live Cast Capsule**: Optimistic casting preparation pill displaying live download percentage and Aubio processing state.
- **Tactile On-Screen Dial**: Rotary jog navigation, search keyboard, and queue manager.

### 3. Mobile Web Remote (`web_remote.py`)
- PWA served on port `8080` with zero cloud dependencies.
- Real-time two-way synchronization via WebSocket telemetry.
- Direct casting from YouTube search, music, shorts, or raw video IDs.
- Mechanical stall triggers, apex height adjustment, and homing calibration.

### 4. Hardware & Mechanical CAD (`Hardware/`)
- CAD assemblies and parts for the 3-RRS ballistic parallel robot, paddle linkage, motor brackets, and 5-inch round display housing.

---

## 🛠️ Deployment & Service Management

### Running the Python Backend
```bash
# Start Playback Daemon
python3 playback_manager.py

# Start Web Remote
python3 web_remote.py
```

### Systemd Services (on board)
- `juggler_daemon.service` — Core playback manager and telemetry server.
- `juggler_web.service` — Mobile web remote server.
- `round_hud.service` — Flutter Round HUD display kiosk.

```bash
# Restart services
sudo systemctl restart juggler_daemon.service juggler_web.service
systemctl --user restart round_hud.service
```

### Deploying the Flutter Round HUD
```powershell
.\deploy.ps1 sync-and-build
```

---

## 📄 License
MIT License.
