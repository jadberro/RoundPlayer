#!/usr/bin/env python3
"""
3-RRS Ballistic Juggler - Apple-Grade Mobile Web Remote (Port 8080)
Responsive PWA with real-time two-way synchronization, physical jog controls,
YouTube/TIDAL search & direct URL casting, cached library browser,
and dynamic queue management.
"""

import os
import json
import asyncio
import urllib.request
import urllib.parse
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Response, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

PLAYBACK_MANAGER_URL = "http://127.0.0.1:8000"
CACHE_DIR = "/data/juggler_cache"

app = FastAPI(title="Ballistic Music Juggler - Web Remote")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

HTML_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>Ballistic Juggler Remote</title>
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="theme-color" content="#060810">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
    body {
      background: #060810;
      color: #F8FAFC;
      font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Segoe UI", Roboto, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
      padding-bottom: 96px;
    }
    header {
      position: sticky;
      top: 0;
      z-index: 50;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 20px;
      background: rgba(6, 8, 16, 0.85);
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    .brand-title {
      font-size: 17px;
      font-weight: 800;
      letter-spacing: -0.4px;
      background: linear-gradient(135deg, #FFFFFF 0%, #94A3B8 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .badge-status {
      font-size: 11px;
      font-weight: 700;
      padding: 4px 10px;
      border-radius: 999px;
      background: rgba(0, 229, 255, 0.12);
      border: 1px solid rgba(0, 229, 255, 0.3);
      color: #00E5FF;
      letter-spacing: 0.5px;
    }
    .tab-content {
      display: none;
      padding: 20px;
      flex-direction: column;
      gap: 18px;
      max-width: 520px;
      margin: 0 auto;
      width: 100%;
    }
    .tab-content.active { display: flex; }
    .glass-card {
      background: rgba(18, 24, 38, 0.65);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid rgba(255, 255, 255, 0.09);
      border-radius: 24px;
      padding: 22px;
      box-shadow: 0 16px 36px rgba(0, 0, 0, 0.45);
    }
    .cover-container {
      width: 100%;
      aspect-ratio: 1 / 1;
      border-radius: 20px;
      overflow: hidden;
      position: relative;
      background: #0D1322;
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .cover-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .track-meta {
      margin-top: 18px;
      text-align: center;
    }
    .track-title {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: -0.4px;
      color: #FFFFFF;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .track-artist {
      font-size: 14px;
      font-weight: 600;
      color: #94A3B8;
      margin-top: 4px;
    }
    .telemetry-row {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      margin-top: 14px;
    }
    .telemetry-chip {
      flex: 1;
      background: rgba(255, 255, 255, 0.04);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 14px;
      padding: 10px;
      text-align: center;
    }
    .telemetry-chip .val {
      font-size: 15px;
      font-weight: 800;
      color: #38BDF8;
    }
    .telemetry-chip .lbl {
      font-size: 10px;
      font-weight: 700;
      color: #64748B;
      letter-spacing: 0.5px;
      margin-top: 2px;
    }
    .transport-bar {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 22px;
      margin-top: 20px;
    }
    .btn-transport {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.12);
      color: #F8FAFC;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.15s ease;
    }
    .btn-transport:active {
      transform: scale(0.92);
      background: rgba(255, 255, 255, 0.16);
    }
    .btn-transport svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
    }
    .btn-circle {
      width: 62px;
      height: 62px;
      border-radius: 50%;
      border: none;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.15s ease;
      background: #00E5FF;
      color: #040814;
      box-shadow: 0 4px 18px rgba(0, 229, 255, 0.35);
    }
    .btn-circle:active { transform: scale(0.92); }
    .btn-circle svg { width: 28px; height: 28px; fill: currentColor; }
    .stall-btn {
      width: 100%;
      padding: 14px;
      border-radius: 16px;
      border: 1px solid rgba(239, 68, 68, 0.4);
      background: rgba(239, 68, 68, 0.12);
      color: #F87171;
      font-size: 13px;
      font-weight: 800;
      letter-spacing: 1px;
      cursor: pointer;
      margin-top: 16px;
      transition: all 0.2s ease;
    }
    .stall-btn.frozen {
      background: rgba(239, 68, 68, 0.35);
      border-color: #EF4444;
      color: #FFFFFF;
      box-shadow: 0 0 20px rgba(239, 68, 68, 0.4);
    }
    .jog-slider-group {
      margin-top: 14px;
    }
    .jog-header {
      display: flex;
      justify-content: space-between;
      font-size: 13px;
      font-weight: 700;
      color: #94A3B8;
      margin-bottom: 8px;
    }
    .jog-slider {
      width: 100%;
      -webkit-appearance: none;
      height: 6px;
      border-radius: 3px;
      background: rgba(255, 255, 255, 0.12);
      outline: none;
    }
    .jog-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 22px;
      height: 22px;
      border-radius: 50%;
      background: #00E5FF;
      cursor: pointer;
      box-shadow: 0 0 10px rgba(0, 229, 255, 0.6);
    }
    .input-field {
      width: 100%;
      padding: 14px 18px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 16px;
      color: #FFFFFF;
      font-size: 15px;
      outline: none;
      margin-bottom: 12px;
    }
    .input-field:focus { border-color: #00E5FF; }
    .action-btn {
      width: 100%;
      padding: 14px;
      background: linear-gradient(135deg, #00E5FF 0%, #0088FF 100%);
      border: none;
      border-radius: 16px;
      color: #040814;
      font-size: 14px;
      font-weight: 800;
      cursor: pointer;
    }
    .track-item {
      display: flex;
      align-items: center;
      padding: 12px;
      border-radius: 16px;
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.06);
      margin-bottom: 10px;
      cursor: pointer;
      gap: 12px;
    }
    .track-item:active { background: rgba(0, 229, 255, 0.1); }
    .item-thumb {
      width: 50px;
      height: 50px;
      border-radius: 10px;
      object-fit: cover;
      background: #111827;
      flex-shrink: 0;
    }
    .item-meta {
      flex: 1;
      overflow: hidden;
    }
    .item-title {
      font-size: 14px;
      font-weight: 700;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .item-artist {
      font-size: 12px;
      color: #94A3B8;
      margin-top: 3px;
    }
    .badge-instant {
      font-size: 10px;
      font-weight: 700;
      padding: 3px 7px;
      border-radius: 6px;
      background: rgba(16, 185, 129, 0.18);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #34D399;
      letter-spacing: 0.3px;
      display: inline-block;
      margin-top: 4px;
    }
    .badge-cloud {
      font-size: 10px;
      font-weight: 700;
      padding: 3px 7px;
      border-radius: 6px;
      background: rgba(56, 189, 248, 0.16);
      border: 1px solid rgba(56, 189, 248, 0.35);
      color: #38BDF8;
      letter-spacing: 0.3px;
      display: inline-block;
      margin-top: 4px;
    }
    .badge-hifi {
      font-size: 10px;
      font-weight: 800;
      padding: 3px 8px;
      border-radius: 6px;
      background: rgba(251, 191, 36, 0.16);
      border: 1px solid rgba(251, 191, 36, 0.45);
      color: #FBBF24;
      letter-spacing: 0.5px;
      display: inline-block;
      margin-top: 4px;
    }
    .queue-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.06);
      border-radius: 14px;
      margin-bottom: 10px;
      transition: background 0.2s;
    }
    .queue-index {
      font-size: 12px;
      font-weight: 800;
      color: #64748B;
      min-width: 20px;
    }
    .btn-icon-danger {
      background: rgba(239, 68, 68, 0.12);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #F87171;
      width: 28px;
      height: 28px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      cursor: pointer;
    }
    .btn-icon-danger:active {
      transform: scale(0.9);
    }
    .hifi-tree-node {
      margin-bottom: 12px;
    }
    .hifi-artist-header {
      font-size: 15px;
      font-weight: 800;
      color: #F8FAFC;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: rgba(255, 255, 255, 0.04);
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.08);
      cursor: pointer;
    }
    .hifi-album-group {
      margin-left: 14px;
      margin-top: 8px;
      border-left: 2px solid rgba(251, 191, 36, 0.25);
      padding-left: 12px;
    }
    .hifi-album-header {
      font-size: 13px;
      font-weight: 700;
      color: #FBBF24;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 6px 10px;
      background: rgba(251, 191, 36, 0.08);
      border-radius: 10px;
      margin-bottom: 6px;
      cursor: pointer;
    }
    .hifi-track-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      background: rgba(255, 255, 255, 0.02);
      border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 12px;
      margin-bottom: 6px;
      transition: background 0.2s;
    }
    .hifi-track-item:active {
      background: rgba(251, 191, 36, 0.12);
    }
    nav {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 78px;
      background: rgba(6, 8, 16, 0.88);
      backdrop-filter: blur(28px);
      -webkit-backdrop-filter: blur(28px);
      border-top: 1px solid rgba(255, 255, 255, 0.08);
      display: flex;
      justify-content: space-around;
      align-items: center;
      z-index: 50;
      padding-bottom: env(safe-area-inset-bottom);
    }
    .nav-btn {
      background: none;
      border: none;
      color: #64748B;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      padding: 8px 12px;
      position: relative;
    }
    .nav-btn.active { color: #00E5FF; }
    .nav-btn svg { width: 22px; height: 22px; fill: currentColor; }
  </style>
</head>
<body>
  <header>
    <div class="brand-title">3-RRS JUGGLER</div>
    <div id="socketStatus" class="badge-status">INITIALIZING</div>
  </header>

  <!-- TAB 1: NOW PLAYING -->
  <div id="tabNowPlaying" class="tab-content active">
    <div class="glass-card">
      <div class="cover-container">
        <img id="coverImg" class="cover-img" src="/media/DBHipNYuAZk/cover.jpg" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect fill=%22%23111827%22 width=%22100%22 height=%22100%22/><text fill=%22%236B7280%22 font-size=%2240%22 x=%2250%22 y=%2260%22 text-anchor=%22middle%22>♪</text></svg>'">
      </div>
      <div class="track-meta">
        <div id="trackTitle" class="track-title">Loading track...</div>
        <div id="trackArtist" class="track-artist">Ballistic Juggler</div>
        <div id="hifiBadge" class="badge-hifi" style="display:none; margin-top:6px;">24-BIT / LOSSLESS FLAC</div>
        <div id="castPrepBanner" style="display:none; margin-top:10px; padding:8px 14px; border-radius:12px; background:rgba(0,229,255,0.12); border:1px solid rgba(0,229,255,0.35); text-align:center;">
          <div id="castPrepText" style="font-size:12px; font-weight:700; color:#38BDF8;">🚀 Casting to HUD: Preparing 1080p...</div>
          <div style="height:4px; border-radius:2px; background:rgba(255,255,255,0.12); margin-top:6px; overflow:hidden;">
            <div id="castPrepBar" style="height:100%; width:10%; background:linear-gradient(90deg, #00E5FF, #38BDF8); transition:width 0.3s ease;"></div>
          </div>
        </div>
      </div>
      <div class="telemetry-row">
        <div class="telemetry-chip">
          <div id="bpmBadge" class="val">126 BPM</div>
          <div class="lbl">TEMPO</div>
        </div>
        <div class="telemetry-chip">
          <div id="ballStateBadge" class="val">AIRBORNE</div>
          <div class="lbl">BALL STATE</div>
        </div>
      </div>
      <div class="transport-bar">
        <button class="btn-transport" onclick="skipPrev(); haptic(24);">
          <svg viewBox="0 0 24 24"><path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>
        </button>
        <button class="btn-circle" onclick="togglePlay(); haptic(20);">
          <span id="playIcon">
            <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
          </span>
        </button>
        <button class="btn-transport" onclick="skipNext(); haptic(24);">
          <svg viewBox="0 0 24 24"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>
        </button>
      </div>
      <div style="display:flex; gap:10px; margin-top:14px;">
        <button id="stopCastBtn" style="flex:1; padding:12px; border-radius:12px; font-size:11px; font-weight:800; letter-spacing:1px; background:rgba(239,68,68,0.18); border:1px solid rgba(239,68,68,0.45); color:#fca5a5; cursor:pointer;" onclick="stopCast(); haptic(30);">⏏ STOP CAST</button>
        <button id="stallBtn" class="stall-btn" style="flex:1; margin-top:0;" onclick="toggleStall(); haptic(35);">STALL MECHANISM</button>
      </div>
    </div>

    <div class="glass-card">
      <div style="font-size:14px; font-weight:800; margin-bottom:14px;">Physical Jog Telemetry</div>
      <div class="jog-slider-group">
        <div class="jog-header">
          <span>Apex Flight Height</span>
          <span id="apexVal" style="color:#00E5FF;">416.2 mm</span>
        </div>
        <input type="range" class="jog-slider" min="350" max="500" step="1" value="416" oninput="onApexChange(this.value)">
      </div>
      <div class="jog-slider-group" style="margin-top:16px;">
        <div class="jog-header">
          <span>ALSA Master Volume</span>
          <span id="volumeVal" style="color:#00E5FF;">80%</span>
        </div>
        <input type="range" class="jog-slider" min="0" max="100" step="1" value="80" oninput="onVolumeChange(this.value)">
      </div>
    </div>
  </div>

  <!-- TAB 2: QUEUE -->
  <div id="tabQueue" class="tab-content">
    <div class="glass-card">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
        <span style="font-size:16px; font-weight:800;">Up Next <span id="queueCount" style="color:#00E5FF; font-size:14px;">(0)</span></span>
        <button style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.3); color:#F87171; border-radius:8px; padding:5px 12px; font-size:11px; font-weight:700; cursor:pointer;" onclick="clearQueue(); haptic(30);">Clear All</button>
      </div>
      <div id="queueList"></div>
    </div>
  </div>

  <!-- TAB 3: SEARCH & INGEST -->
  <div id="tabSearch" class="tab-content">
    <div class="glass-card">
      <div style="display:flex; gap:8px; margin-bottom:12px;">
        <button id="searchModeYt" class="action-btn" style="flex:1; margin:0; background:#38BDF8; color:#040814; font-weight:800;" onclick="setSearchMode('yt')">YouTube</button>
        <button id="searchModeHifi" class="action-btn" style="flex:1; margin:0; background:rgba(255,255,255,0.08); color:#F8FAFC; font-weight:800;" onclick="setSearchMode('hifi')">💿 Hi-Fi Lossless</button>
      </div>
      <input type="text" id="searchInput" class="input-field" placeholder="Search YouTube or Hi-Fi..." onkeydown="if(event.key==='Enter') executeSearch()">
      <button class="action-btn" onclick="executeSearch(); haptic();">Search Tracks</button>
    </div>

    <div class="glass-card" id="directUrlCard">
      <div style="font-size:15px; font-weight:800; margin-bottom:12px;">Cast Direct URL</div>
      <input type="text" id="urlInput" class="input-field" placeholder="Paste YouTube link...">
      <button class="action-btn" onclick="castDirectUrl(); haptic();">Cast to Plinth</button>
    </div>

    <div id="searchResults"></div>
  </div>

  <!-- TAB 4: LIBRARY -->
  <div id="tabLibrary" class="tab-content">
    <div class="glass-card">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
        <span style="font-size:16px; font-weight:800;">Cached Library</span>
        <span id="cacheCount" style="font-size:13px; color:#38BDF8; font-weight:700;">Loading...</span>
      </div>
      <div id="libraryList"></div>
    </div>
  </div>

  <!-- TAB: HI-FI LOSSLESS -->
  <div id="tabHiFi" class="tab-content">
    <div class="glass-card">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <span style="font-size:16px; font-weight:800; color:#FBBF24;">📀 Lossless Audiophile</span>
        <span class="badge-hifi">24-BIT / FLAC</span>
      </div>
      <div style="font-size:12px; color:#94A3B8; margin-bottom:16px;">
        Lossless direct Bit-Perfect playback synchronized with Aubio ballistic trajectory tracking.
      </div>

      <!-- Google Drive Sync Section -->
      <div style="background:rgba(255,255,255,0.03); border:1px solid rgba(251,191,36,0.2); border-radius:14px; padding:12px; margin-bottom:16px;">
        <div style="font-size:11px; font-weight:800; color:#FBBF24; letter-spacing:0.5px; margin-bottom:8px;">GOOGLE DRIVE FOLDER SYNC</div>
        <div style="display:flex; gap:8px;">
          <input type="text" id="driveUrlInput" placeholder="https://drive.google.com/drive/folders/..." style="flex:1; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:8px 12px; color:#F8FAFC; font-size:12px; outline:none;" value="https://drive.google.com/drive/folders/YOUR_PUBLIC_FOLDER_ID?usp=sharing">
          <button class="action-btn" style="background:linear-gradient(135deg, #F59E0B, #D97706); color:#000; font-weight:800; padding:8px 14px; border-radius:10px; font-size:11px;" onclick="syncDrive(); haptic(25);">SYNC</button>
        </div>
        <div id="syncStatus" style="font-size:11px; color:#94A3B8; margin-top:8px;">Ready to sync.</div>
        <div id="driveFoldersList" style="margin-top:10px; display:flex; flex-direction:column; gap:6px;"></div>
      </div>

      <!-- Instant Smart Mixes & Playlists Quick Bar -->
      <div style="font-size:11px; font-weight:800; color:#FBBF24; letter-spacing:0.5px; margin-bottom:8px;">INSTANT SMART MIXES & FAVORITES</div>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px;">
        <button class="action-btn" style="background:rgba(16,185,129,0.15); border:1px solid rgba(16,185,129,0.4); color:#34D399; font-weight:800; padding:10px 8px; font-size:11.5px; border-radius:10px;" onclick="playSmartMix('random'); haptic(25);">
          🎲 SHUFFLE 50
        </button>
        <button class="action-btn" style="background:rgba(59,130,246,0.15); border:1px solid rgba(59,130,246,0.4); color:#60A5FA; font-weight:800; padding:10px 8px; font-size:11.5px; border-radius:10px;" onclick="playSmartMix('recently_added'); haptic(25);">
          🆕 RECENT 50
        </button>
        <button class="action-btn" style="background:rgba(245,158,11,0.15); border:1px solid rgba(245,158,11,0.4); color:#FBBF24; font-weight:800; padding:10px 8px; font-size:11.5px; border-radius:10px;" onclick="playSmartMix('audiophile'); haptic(25);">
          💎 24-BIT MASTER
        </button>
        <button class="action-btn" style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.4); color:#F87171; font-weight:800; padding:10px 8px; font-size:11.5px; border-radius:10px;" onclick="playPlaylistWeb('favorites'); haptic(25);">
          ❤️ FAVORITES
        </button>
      </div>

      <!-- User Playlists Section -->
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; margin-top:16px;">
        <div style="font-size:11px; font-weight:800; color:#FBBF24; letter-spacing:0.5px;">CUSTOM PLAYLISTS</div>
        <button style="background:rgba(251,191,36,0.15); border:1px solid rgba(251,191,36,0.4); color:#FBBF24; border-radius:8px; padding:4px 10px; font-size:11px; font-weight:700; cursor:pointer;" onclick="promptCreatePlaylist(); haptic(20);">
          + New Playlist
        </button>
      </div>
      <div id="webPlaylistsContainer" style="display:flex; flex-direction:column; gap:6px; margin-bottom:16px;">
        <div style="color:#64748B; font-size:12px; text-align:center; padding:10px;">Loading playlists...</div>
      </div>

      <!-- HiFi Library Browser Tree -->
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <div style="display:flex; align-items:center; gap:8px;">
          <span style="font-size:13px; font-weight:800; color:#E2E8F0;">Library Structure</span>
          <button id="hifiRefreshBtn" style="background:rgba(251,191,36,0.12); border:1px solid rgba(251,191,36,0.35); color:#FBBF24; border-radius:8px; padding:3px 8px; font-size:11px; font-weight:700; cursor:pointer; display:flex; align-items:center; gap:4px;" onclick="rescanHiFi(); haptic(20);">
            <span>🔄 Rescan</span>
          </button>
        </div>
        <span id="hifiTrackCount" style="font-size:11px; color:#FBBF24; font-weight:700;">Loading...</span>
      </div>
      <div id="hifiTreeContainer" style="display:flex; flex-direction:column; gap:8px;">
        <div style="text-align:center; padding:24px; color:#64748B; font-size:13px;">Loading Hi-Fi catalog...</div>
      </div>
    </div>
  </div>

  <!-- TAB: SETTINGS -->
  <div id="tabSettings" class="tab-content">
    <div class="glass-card">
      <div style="font-size:16px; font-weight:800; margin-bottom:14px;">Centerpiece & Plinth Settings</div>
      
      <div class="jog-header" style="margin-top:10px;">
        <span>Ambient Aura Brightness</span>
        <span id="setBrightnessVal" style="color:#00E5FF;">85%</span>
      </div>
      <input type="range" class="jog-slider" id="setBrightnessSlider" min="20" max="100" value="85" onchange="updateRemoteSetting('ambient_brightness', this.value / 100); document.getElementById('setBrightnessVal').innerText = this.value + '%';">

      <div class="jog-header" style="margin-top:20px;">
        <span>Idle Sleep Timeout</span>
        <span id="setTimeoutVal" style="color:#00E5FF;">120s</span>
      </div>
      <div style="display:flex; gap:8px; margin-top:8px;">
        <button class="action-btn" style="padding:9px 0; font-size:12px;" onclick="updateRemoteSetting('idle_timeout_seconds', 30); haptic();">30s</button>
        <button class="action-btn" style="padding:9px 0; font-size:12px;" onclick="updateRemoteSetting('idle_timeout_seconds', 60); haptic();">60s</button>
        <button class="action-btn" style="padding:9px 0; font-size:12px;" onclick="updateRemoteSetting('idle_timeout_seconds', 120); haptic();">120s</button>
        <button class="action-btn" style="padding:9px 0; font-size:12px;" onclick="updateRemoteSetting('idle_timeout_seconds', 300); haptic();">300s</button>
      </div>

      <!-- OV9281 Machine Vision & Ball Tracking Test Card -->
      <div class="jog-header" style="margin-top:24px;">
        <span>OV9281 Camera Vision (Port 1)</span>
      </div>
      <div style="background:rgba(0,229,255,0.06); border:1px solid rgba(0,229,255,0.3); border-radius:14px; padding:12px; margin-top:8px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
          <span style="font-size:11px; font-weight:800; color:#00E5FF;">LIVE 3D BALL TRACKER (40mm)</span>
          <span id="remoteVisionFps" style="font-size:10px; color:#A7F3D0; font-weight:700;">120 FPS</span>
        </div>
        <img id="remoteVisionImg" src="/api/vision/stream" style="width:100%; border-radius:10px; border:1px solid rgba(0,229,255,0.25); aspect-ratio:4/3; object-fit:cover; background:#000;" onerror="this.style.display='none';">
        <div style="display:flex; justify-content:space-between; margin-top:8px; font-size:11px; color:#94A3B8;">
          <span id="remoteVisionBalls">Balls: 2</span>
          <span id="remoteVisionLatency">Latency: 2.4ms</span>
          <span id="remoteVisionExposure">Exp: 1200µs</span>
        </div>
        <div style="display:flex; gap:6px; margin-top:10px;">
          <button class="action-btn" style="flex:1; font-size:11px; padding:6px 0;" onclick="setVisionTheme('cyberpunk'); haptic(20);">Cyberpunk</button>
          <button class="action-btn" style="flex:1; font-size:11px; padding:6px 0;" onclick="setVisionTheme('heatmap'); haptic(20);">Heatmap</button>
          <button class="action-btn" style="flex:1; font-size:11px; padding:6px 0;" onclick="setVisionTheme('monochrome'); haptic(20);">Monochrome</button>
        </div>
      </div>

      <!-- AUDIOPHILE DAC PRO & PIPEWIRE TUNING -->
      <div class="jog-header" style="margin-top:24px;">
        <span>Audiophile DAC Pro & Audio Engine</span>
      </div>
      <div style="background:rgba(16,185,129,0.06); border:1px solid rgba(16,185,129,0.3); border-radius:14px; padding:12px; margin-top:8px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
          <div>
            <span style="font-size:11px; font-weight:800; color:#34D399;">TI PCM5122 DAC PRO (32-BIT)</span>
            <div id="dacLiveStateText" style="font-size:9px; color:#94A3B8; font-family:monospace; margin-top:2px;">STATE: PLAYING · VOL: +0.0 dB</div>
          </div>
          <span id="dacLivePllBadge" style="font-size:10px; color:#10B981; font-weight:700; padding:2px 8px; background:rgba(16,185,129,0.15); border-radius:6px; border:1px solid #10B981;">PLL: LOCKED</span>
        </div>
        
        <div style="display:flex; gap:6px; margin-bottom:12px;">
          <button class="action-btn" style="flex:1; padding:8px 0; font-size:10px; background:rgba(245,158,11,0.18); border-color:#F59E0B; color:#FDE68A; font-weight:bold;" onclick="applyDacBestQuality(); haptic(30);">
            ✨ AUDIOPHILE PROFILE
          </button>
          <button class="action-btn" style="flex:1; padding:8px 0; font-size:10px; background:rgba(255,255,255,0.06); border-color:rgba(255,255,255,0.2); color:#E2E8F0; font-weight:bold;" onclick="resetDacDefaults(); haptic(30);">
            🔄 FACTORY DEFAULTS
          </button>
        </div>

        <!-- 1. Interpolation Filter -->
        <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">INTERPOLATION FILTER (SOUND CHARACTER)</div>
        <div style="display:flex; gap:4px; margin-bottom:10px; flex-wrap:wrap;">
          <button class="action-btn" id="filterBtn_ringless" style="flex:1; min-width:65px; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('filter', 'ringless'); haptic(20);">Ringless</button>
          <button class="action-btn" id="filterBtn_fir" style="flex:1; min-width:50px; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('filter', 'fir'); haptic(20);">FIR</button>
          <button class="action-btn" id="filterBtn_iir" style="flex:1; min-width:50px; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('filter', 'iir'); haptic(20);">IIR</button>
          <button class="action-btn" id="filterBtn_high-atten" style="flex:1; min-width:75px; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('filter', 'high-atten'); haptic(20);">Hi-Atten</button>
          <button class="action-btn" id="filterBtn_fixed" style="flex:1; min-width:55px; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('filter', 'fixed'); haptic(20);">Fixed</button>
        </div>

        <!-- 2. Analog Output Stage -->
        <div style="display:flex; gap:10px; margin-bottom:10px;">
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">ANALOG LINE GAIN</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="gainBtn_0" style="flex:1; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('analog-gain', '0'); haptic(20);">0 dB (2V)</button>
              <button class="action-btn" id="gainBtn_-6" style="flex:1; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('analog-gain', '-6'); haptic(20);">-6 dB (1V)</button>
            </div>
          </div>
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">ANALOG BOOST (+0.8dB)</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="boostBtn_off" style="flex:1; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('boost', 'off'); haptic(20);">Off</button>
              <button class="action-btn" id="boostBtn_on" style="flex:1; font-size:10px; padding:6px 0;" onclick="setAudioDacSetting('boost', 'on'); haptic(20);">On</button>
            </div>
          </div>
        </div>

        <!-- 3. Channel Routing -->
        <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">CHANNEL ROUTING</div>
        <div style="display:flex; gap:4px; margin-bottom:10px; flex-wrap:wrap;">
          <button class="action-btn" id="chanBtn_stereo" style="flex:1; min-width:55px; font-size:10px; padding:5px 0;" onclick="setAudioDacSetting('channels', 'stereo'); haptic(20);">Stereo</button>
          <button class="action-btn" id="chanBtn_swap" style="flex:1; min-width:55px; font-size:10px; padding:5px 0;" onclick="setAudioDacSetting('channels', 'swap'); haptic(20);">Swap L/R</button>
          <button class="action-btn" id="chanBtn_mono-left" style="flex:1; min-width:55px; font-size:10px; padding:5px 0;" onclick="setAudioDacSetting('channels', 'mono-left'); haptic(20);">Mono L</button>
          <button class="action-btn" id="chanBtn_mono-right" style="flex:1; min-width:55px; font-size:10px; padding:5px 0;" onclick="setAudioDacSetting('channels', 'mono-right'); haptic(20);">Mono R</button>
        </div>

        <!-- 4. Stereo Balance Slider -->
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
          <span style="font-size:10px; color:#94A3B8; font-weight:700;">STEREO BALANCE TRIM</span>
          <span id="dacBalanceVal" style="font-size:10px; color:#00E5FF; font-family:monospace; font-weight:bold;">0.0 dB (Center)</span>
        </div>
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">
          <span style="font-size:9px; color:#64748B;">L</span>
          <input type="range" id="dacBalanceSlider" min="-12" max="12" step="0.5" value="0" style="flex:1; accent-color:#00E5FF;" oninput="onDacBalanceInput(this.value);" onchange="onDacBalanceChange(this.value);">
          <span style="font-size:9px; color:#64748B;">R</span>
        </div>

        <!-- 5. Transitions & Silence Gate (Ramp / Auto-Mute / Deemphasis / Soft Mute) -->
        <div style="display:flex; gap:10px; margin-bottom:10px;">
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">VOLUME RAMP</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="rampBtn_1_0_5dB" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('ramp', '1/0.5dB'); haptic(20);">1/0.5dB</button>
              <button class="action-btn" id="rampBtn_1_1dB" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('ramp', '1/1dB'); haptic(20);">1/1dB</button>
              <button class="action-btn" id="rampBtn_instant" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('ramp', 'instant'); haptic(20);">Instant</button>
            </div>
          </div>
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">AUTO-MUTE GATE</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="autoMuteBtn_off" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('auto-mute', 'off'); haptic(20);">Off</button>
              <button class="action-btn" id="autoMuteBtn_106ms" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('auto-mute', '106ms'); haptic(20);">106ms</button>
              <button class="action-btn" id="autoMuteBtn_1_07s" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('auto-mute', '1.07s'); haptic(20);">1.07s</button>
            </div>
          </div>
        </div>

        <div style="display:flex; gap:10px; margin-bottom:12px;">
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">CD DE-EMPHASIS</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="deemphBtn_off" style="flex:1; font-size:10px; padding:5px 0;" onclick="setAudioDacSetting('deemphasis', 'off'); haptic(20);">Off</button>
              <button class="action-btn" id="deemphBtn_on" style="flex:1; font-size:10px; padding:5px 0;" onclick="setAudioDacSetting('deemphasis', 'on'); haptic(20);">On</button>
            </div>
          </div>
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">HARDWARE MUTE</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="muteBtn_off" style="flex:1; font-size:10px; padding:5px 0;" onclick="setAudioDacSetting('mute', 'off'); haptic(20);">Unmuted</button>
              <button class="action-btn" id="muteBtn_on" style="flex:1; font-size:10px; padding:5px 0; color:#F87171;" onclick="setAudioDacSetting('mute', 'on'); haptic(20);">Muted</button>
            </div>
          </div>
        </div>

        <!-- 6. PipeWire 32-bit Engine Section -->
        <div style="font-size:10px; color:#34D399; font-weight:800; margin-bottom:6px; border-top:1px solid rgba(255,255,255,0.08); padding-top:8px;">PIPEWIRE 32-BIT HIGH-RES SOUND ENGINE</div>
        
        <div style="display:flex; gap:10px; margin-bottom:10px;">
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">RESAMPLE QUALITY</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="resampleBtn_4" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-resample-quality', 4); haptic(20);">4</button>
              <button class="action-btn" id="resampleBtn_10" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-resample-quality', 10); haptic(20);">10</button>
              <button class="action-btn" id="resampleBtn_12" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-resample-quality', 12); haptic(20);">12</button>
              <button class="action-btn" id="resampleBtn_14" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-resample-quality', 14); haptic(20);">14 Max</button>
            </div>
          </div>
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">PW KEEP-AWAKE</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="keepAwakeBtn_on" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-keep-awake', 'on'); haptic(20);">ON (0 Pop)</button>
              <button class="action-btn" id="keepAwakeBtn_off" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-keep-awake', 'off'); haptic(20);">OFF</button>
            </div>
          </div>
        </div>

        <div style="display:flex; gap:10px; margin-bottom:10px;">
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">32-BIT HI-RES STREAM</div>
            <div style="display:flex; gap:4px;">
              <button class="action-btn" id="hiresBtn_on" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-hires', 'on'); haptic(20);">ON (96/192k)</button>
              <button class="action-btn" id="hiresBtn_off" style="flex:1; font-size:9px; padding:5px 0;" onclick="setAudioDacSetting('pw-hires', 'off'); haptic(20);">OFF (48k)</button>
            </div>
          </div>
          <div style="flex:1;">
            <div style="font-size:10px; color:#94A3B8; font-weight:700; margin-bottom:4px;">DITHER ALGORITHM</div>
            <select id="ditherSelect" style="width:100%; background:rgba(0,0,0,0.4); border:1px solid rgba(255,255,255,0.15); color:#E2E8F0; font-size:10px; padding:5px 6px; border-radius:6px;" onchange="setAudioDacSetting('pw-dither', this.value); haptic(20);">
              <option value="none">none</option>
              <option value="triangular">triangular</option>
              <option value="triangular-hf">triangular-hf</option>
              <option value="lipshitz5">lipshitz5 (Optimal)</option>
              <option value="wannamaker3">wannamaker3</option>
            </select>
          </div>
        </div>

        <div style="font-size:9px; color:#64748B; text-align:center; margin-top:8px;">
          Persisted to /etc/ventudac.json · Real-time I²C direct registers (no playback interruption)
        </div>
      </div>

      <div class="jog-header" style="margin-top:24px;">
        <span>Quick Power & Maintenance</span>
      </div>

      <button class="stall-btn" style="margin-top:10px; background:rgba(0,229,255,0.15); border-color:#00E5FF; color:#00E5FF;" onclick="calibrateKinematics(); haptic();">
        CALIBRATE KINEMATICS HOMING
      </button>
      <button class="stall-btn" style="margin-top:10px;" onclick="restartServices(); haptic();">
        RESTART JUGGLER DAEMONS
      </button>
    </div>
  </div>

  <!-- BOTTOM NAV -->
  <nav>
    <button class="nav-btn active" onclick="switchTab('tabNowPlaying', this); haptic();">
      <svg viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
      <span>Now Playing</span>
    </button>
    <button class="nav-btn" onclick="switchTab('tabQueue', this); loadQueue(); haptic();">
      <svg viewBox="0 0 24 24"><path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/></svg>
      <span>Queue <span id="navQueueBadge" style="color:#00E5FF; font-size:10px;"></span></span>
    </button>
    <button class="nav-btn" onclick="switchTab('tabSearch', this); haptic();">
      <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
      <span>Search</span>
    </button>
    <button class="nav-btn" onclick="switchTab('tabLibrary', this); loadLibrary(); haptic();">
      <svg viewBox="0 0 24 24"><path d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H8V4h12v12z"/></svg>
      <span>Library</span>
    </button>
    <button class="nav-btn" onclick="switchTab('tabHiFi', this); loadHiFiTree(); haptic();">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 14.5c-2.49 0-4.5-2.01-4.5-4.5S9.51 7.5 12 7.5s4.5 2.01 4.5 4.5-2.01 4.5-4.5 4.5zm0-5.5c-.55 0-1 .45-1 1s.45 1 1 1 1-.45 1-1-.45-1-1-1z"/></svg>
      <span>Hi-Fi</span>
    </button>
    <button class="nav-btn" onclick="switchTab('tabSettings', this); loadSettings(); haptic();">
      <svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
      <span>Settings</span>
    </button>
  </nav>

  <!-- Modal for Playlist operations -->
  <div id="hifiModal" style="display:none; position:fixed; inset:0; z-index:9999; background:rgba(0,0,0,0.75); backdrop-filter:blur(6px); align-items:center; justify-content:center; padding:20px;">
    <div style="background:#0F172A; border:1px solid rgba(251,191,36,0.3); border-radius:18px; width:100%; max-width:380px; padding:20px; box-shadow:0 20px 40px rgba(0,0,0,0.8);">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
        <h3 id="hifiModalTitle" style="font-size:15px; font-weight:800; color:#FBBF24; margin:0;">Add to Playlist</h3>
        <button style="background:none; border:none; color:#94A3B8; font-size:22px; cursor:pointer;" onclick="closeHifiModal()">✕</button>
      </div>
      <div id="hifiModalBody" style="display:flex; flex-direction:column; gap:8px; max-height:300px; overflow-y:auto;"></div>
    </div>
  </div>

  <script>
    let isPlaying = false;
    let isFrozen = false;
    let activeTrackId = "";

    function haptic(ms = 18) {
      if (navigator.vibrate) {
        try { navigator.vibrate(ms); } catch (_) {}
      }
    }

    function switchTab(tabId, btn) {
      document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
      document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
      document.getElementById(tabId).classList.add('active');
      btn.classList.add('active');
    }

    // Connect WebSocket using relative protocol and host
    let socket;
    function connectSocket() {
      const wsProto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${wsProto}//${window.location.host}/ws/telemetry`;
      socket = new WebSocket(wsUrl);
      socket.onopen = () => {
        const s = document.getElementById('socketStatus');
        s.innerText = 'ONLINE';
        s.style.color = '#10B981';
        s.style.borderColor = 'rgba(16, 185, 129, 0.4)';
        s.style.background = 'rgba(16, 185, 129, 0.12)';
      };
      socket.onclose = () => {
        const s = document.getElementById('socketStatus');
        s.innerText = 'RECONNECTING';
        s.style.color = '#F59E0B';
        s.style.borderColor = 'rgba(245, 158, 11, 0.4)';
        s.style.background = 'rgba(245, 158, 11, 0.12)';
        setTimeout(connectSocket, 2000);
      };
      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          updateTelemetry(data);
        } catch (_) {}
      };
    }

    let castingPollTimer = null;
    let localCastingVideoId = null;
    let knownHiFiVersion = 0;

    function updateTelemetry(data) {
      if (data.vision) {
        const v = data.vision;
        const fpsEl = document.getElementById('remoteVisionFps');
        if (fpsEl) fpsEl.innerText = `${(v.fps || 120).toFixed(1)} FPS`;
        const ballsEl = document.getElementById('remoteVisionBalls');
        if (ballsEl) ballsEl.innerText = `Balls: ${v.ball_count || 0}`;
        const latEl = document.getElementById('remoteVisionLatency');
        if (latEl) latEl.innerText = `Latency: ${(v.latency_ms || 2.4).toFixed(1)}ms`;
        const expEl = document.getElementById('remoteVisionExposure');
        if (expEl) expEl.innerText = `Exp: ${v.exposure_us || 1200}µs`;
      }

      if (data.caching_video_id) {
        const prepBanner = document.getElementById('castPrepBanner');
        const prepText = document.getElementById('castPrepText');
        const prepBar = document.getElementById('castPrepBar');
        if (prepBanner) {
          prepBanner.style.display = 'block';
          const pct = data.caching_percent || 0;
          if (prepBar) prepBar.style.width = Math.max(5, Math.min(100, pct)) + '%';
          if (prepText) prepText.innerText = `🚀 ${data.caching_progress || 'Preparing 1080p'} (${pct}%)`;
        }
        if (data.caching_title) {
          document.getElementById('trackTitle').innerText = data.caching_title;
        }
        if (data.caching_artist) {
          document.getElementById('trackArtist').innerText = data.caching_artist;
        }
      } else {
        if (!localCastingVideoId) {
          const prepBanner = document.getElementById('castPrepBanner');
          if (prepBanner && prepBanner.style.display !== 'none') {
            prepBanner.style.display = 'none';
          }
          if (data.track_id && data.track_id !== activeTrackId) {
            activeTrackId = data.track_id;
            if (activeTrackId.startsWith('hifi_')) {
              document.getElementById('coverImg').src = `/api/hifi/cover?track_id=${activeTrackId}`;
            } else {
              document.getElementById('coverImg').src = `/media/${activeTrackId}/cover.jpg`;
            }
            loadQueue();
          }
          if (data.title) document.getElementById('trackTitle').innerText = data.title;
          if (data.artist) document.getElementById('trackArtist').innerText = data.artist;
          
          const hifiBadge = document.getElementById('hifiBadge');
          if (hifiBadge) {
            if (data.is_hifi) {
              const fmt = data.format || 'FLAC';
              const depth = data.bit_depth ? `${data.bit_depth}-BIT` : '24-BIT';
              const rate = data.sample_rate_hz ? `${(data.sample_rate_hz / 1000).toFixed(1)} kHz` : '';
              hifiBadge.style.display = 'inline-block';
              hifiBadge.innerText = `📀 ${depth} / ${rate} • ${fmt} LOSSLESS`;
            } else {
              hifiBadge.style.display = 'none';
            }
          }
        }
      }
      if (data.bpm) document.getElementById('bpmBadge').innerText = `${Math.round(data.bpm)} BPM`;
      if (data.ball_state) document.getElementById('ballStateBadge').innerText = data.ball_state;
      if (data.apex_height_mm !== undefined) {
        document.getElementById('apexVal').innerText = `${parseFloat(data.apex_height_mm).toFixed(1)} mm`;
      }
      if (data.is_playing !== undefined) {
        isPlaying = data.is_playing;
        document.getElementById('playIcon').innerHTML = isPlaying
          ? '<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>'
          : '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
      }
      if (data.is_frozen !== undefined) {
        isFrozen = data.is_frozen;
        const sBtn = document.getElementById('stallBtn');
        if (isFrozen) {
          sBtn.classList.add('frozen');
          sBtn.innerText = 'STALL ACTIVE (TAP TO RESUME)';
        } else {
          sBtn.classList.remove('frozen');
          sBtn.innerText = 'TRIGGER MECHANICAL STALL';
        }
      }
      if (data.hifi_catalog_version !== undefined) {
        if (knownHiFiVersion !== 0 && data.hifi_catalog_version > knownHiFiVersion) {
          knownHiFiVersion = data.hifi_catalog_version;
          loadHiFiTree();
          loadWebPlaylists();
        } else {
          knownHiFiVersion = data.hifi_catalog_version;
        }
      }
      if (data.hifi_sync_status) {
        updateDriveSyncUI(data.hifi_sync_status, data.hifi_sync_message);
      }
    }

    async function fetchInitialState() {
      try {
        const res = await fetch('/api/state');
        if (res.ok) {
          const data = await res.json();
          if (data.caching_video_id) {
            const prepBanner = document.getElementById('castPrepBanner');
            const prepText = document.getElementById('castPrepText');
            const prepBar = document.getElementById('castPrepBar');
            if (prepBanner) {
              prepBanner.style.display = 'block';
              const pct = data.caching_percent || 0;
              if (prepBar) prepBar.style.width = Math.max(5, Math.min(100, pct)) + '%';
              if (prepText) prepText.innerText = `🚀 ${data.caching_progress || 'Preparing 1080p'} (${pct}%)`;
            }
            if (data.caching_title) document.getElementById('trackTitle').innerText = data.caching_title;
            if (data.caching_artist) document.getElementById('trackArtist').innerText = data.caching_artist;
          } else if (!localCastingVideoId) {
            const prepBanner = document.getElementById('castPrepBanner');
            if (prepBanner) prepBanner.style.display = 'none';
            if (data.active_video_id) {
              activeTrackId = data.active_video_id;
              document.getElementById('coverImg').src = `/media/${activeTrackId}/cover.jpg`;
            }
            if (data.title) document.getElementById('trackTitle').innerText = data.title;
            if (data.artist) document.getElementById('trackArtist').innerText = data.artist;
          }
          if (data.current_bpm) document.getElementById('bpmBadge').innerText = `${Math.round(data.current_bpm)} BPM`;
          if (data.volume !== undefined) {
            document.getElementById('volumeVal').innerText = `${Math.round(data.volume)}%`;
          }
          if (data.apex_height_mm !== undefined) {
            document.getElementById('apexVal').innerText = `${parseFloat(data.apex_height_mm).toFixed(1)} mm`;
          }
        }
      } catch (_) {}
    }

    async function sendControl(action, value) {
      try {
        await fetch('/api/control', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: action, value: value })
        });
      } catch (_) {}
    }

    function togglePlay() {
      sendControl(isPlaying ? 'pause' : 'play', null);
      isPlaying = !isPlaying;
      document.getElementById('playIcon').innerHTML = isPlaying
        ? '<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>'
        : '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
    }

    async function stopCast() {
      try {
        if (castingPollTimer) { clearInterval(castingPollTimer); castingPollTimer = null; }
        localCastingVideoId = null;
        const prepBanner = document.getElementById('castPrepBanner');
        if (prepBanner) prepBanner.style.display = 'none';
        await fetch('/api/control', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'stop_cast' })
        });
        setTimeout(fetchInitialState, 200);
      } catch (e) {
        console.error('Stop cast error:', e);
      }
    }

    function toggleStall() {
      sendControl('stall', null);
      isFrozen = !isFrozen;
      const sBtn = document.getElementById('stallBtn');
      if (isFrozen) {
        sBtn.classList.add('frozen');
        sBtn.innerText = 'STALL ACTIVE (TAP TO RESUME)';
      } else {
        sBtn.classList.remove('frozen');
        sBtn.innerText = 'TRIGGER MECHANICAL STALL';
      }
    }

    async function setVisionTheme(theme) {
      try {
        await fetch('/api/vision/control', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ color_mode: theme })
        });
      } catch (_) {}
    }


    let apexDebounce;
    function onApexChange(val) {
      document.getElementById('apexVal').innerText = `${val} mm`;
      clearTimeout(apexDebounce);
      apexDebounce = setTimeout(() => {
        sendControl('apex_height', parseFloat(val));
        haptic(10);
      }, 50);
    }

    let volDebounce;
    function onVolumeChange(val) {
      document.getElementById('volumeVal').innerText = `${val}%`;
      clearTimeout(volDebounce);
      volDebounce = setTimeout(() => {
        sendControl('volume', parseFloat(val));
        haptic(10);
      }, 50);
    }

    async function skipNext() {
      try {
        await fetch('/api/queue/next', { method: 'POST' });
        setTimeout(() => { fetchInitialState(); loadQueue(); }, 300);
      } catch (_) {}
    }

    async function skipPrev() {
      try {
        await fetch('/api/queue/prev', { method: 'POST' });
        setTimeout(() => { fetchInitialState(); loadQueue(); }, 300);
      } catch (_) {}
    }

    async function playTrack(videoId, title, artist, thumb) {
      try {
        localCastingVideoId = videoId;
        // Immediate optimistic UI updates
        if (title) document.getElementById('trackTitle').innerText = title;
        if (artist) document.getElementById('trackArtist').innerText = artist;
        if (thumb) document.getElementById('coverImg').src = thumb;

        const prepBanner = document.getElementById('castPrepBanner');
        const prepText = document.getElementById('castPrepText');
        const prepBar = document.getElementById('castPrepBar');
        if (prepBanner) {
          prepBanner.style.display = 'block';
          prepText.innerText = '🚀 Casting to HUD: Preparing 1080p...';
          prepBar.style.width = '10%';
        }

        switchTab('tabNowPlaying', document.querySelectorAll('.nav-btn')[0]);

        const res = await fetch(`/api/play/${videoId}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            video_id: videoId,
            title: title || '',
            artist: artist || '',
            thumbnail_url: thumb || ''
          })
        });

        const data = await res.json();
        if (data.status === 'caching') {
          if (castingPollTimer) clearInterval(castingPollTimer);
          castingPollTimer = setInterval(async () => {
            try {
              const sRes = await fetch(`/api/cache/status/${videoId}`);
              if (sRes.ok) {
                const sData = await sRes.json();
                if (prepText && prepBar) {
                  const pct = sData.percent || Math.round((sData.progress || 0) * 100);
                  prepBar.style.width = Math.max(5, Math.min(100, pct)) + '%';
                  prepText.innerText = `🚀 ${sData.step || 'Preparing 1080p'} (${pct}%)`;
                }
                if (sData.status === 'ready') {
                  clearInterval(castingPollTimer);
                  castingPollTimer = null;
                  localCastingVideoId = null;
                  if (prepBanner) prepBanner.style.display = 'none';
                  fetchInitialState();
                  loadQueue();
                } else if (sData.status === 'error') {
                  clearInterval(castingPollTimer);
                  castingPollTimer = null;
                  localCastingVideoId = null;
                  if (prepText) prepText.innerText = `❌ Error: ${sData.error || 'Download failed'}`;
                  setTimeout(() => { if (prepBanner) prepBanner.style.display = 'none'; }, 4000);
                }
              }
            } catch (_) {}
          }, 600);
        } else {
          localCastingVideoId = null;
          if (prepBanner) prepBanner.style.display = 'none';
          setTimeout(() => { fetchInitialState(); loadQueue(); }, 300);
        }
      } catch (e) {
        alert('Failed to play track: ' + e);
        localCastingVideoId = null;
        if (document.getElementById('castPrepBanner')) {
          document.getElementById('castPrepBanner').style.display = 'none';
        }
      }
    }

    async function loadQueue() {
      try {
        const res = await fetch('/api/queue');
        if (res.ok) {
          const data = await res.json();
          const queue = Array.isArray(data) ? data : (data.queue || []);
          document.getElementById('queueCount').innerText = `(${queue.length})`;
          const navBadge = document.getElementById('navQueueBadge');
          if (navBadge) navBadge.innerText = queue.length > 0 ? `(${queue.length})` : '';
          
          const list = document.getElementById('queueList');
          if (queue.length === 0) {
            list.innerHTML = '<div style="text-align:center; padding:32px 10px; color:#64748B; font-size:14px;">Queue is empty.<br>Search and add tracks to queue up next!</div>';
            return;
          }
          list.innerHTML = queue.map((item, idx) => `
            <div class="queue-item">
              <span class="queue-index">${idx + 1}</span>
              <img class="item-thumb" src="${item.thumbnail_url || '/media/' + item.video_id + '/cover.jpg'}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect fill=%22%23111827%22 width=%22100%22 height=%22100%22/><text fill=%22%236B7280%22 font-size=%2240%22 x=%2250%22 y=%2260%22 text-anchor=%22middle%22>♪</text></svg>'">
              <div class="item-meta">
                <div class="item-title">${item.title || 'Untitled Track'}</div>
                <div class="item-artist">${item.artist || 'Unknown'} ${item.duration ? '• ' + item.duration : ''}</div>
              </div>
              <button class="btn-icon-danger" onclick="removeFromQueue(${idx}); haptic(20);">✕</button>
            </div>
          `).join('');
        }
      } catch (_) {}
    }

    async function addToQueue(videoId, title, artist, duration, thumb) {
      try {
        haptic(25);
        await fetch('/api/queue/add', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            video_id: videoId,
            title: title || '',
            artist: artist || '',
            duration: duration || '',
            thumbnail_url: thumb || '',
            source: 'youtube'
          })
        });
        loadQueue();
      } catch (e) {
        alert('Failed to add to queue: ' + e);
      }
    }

    async function removeFromQueue(index) {
      try {
        await fetch(`/api/queue/remove/${index}`, { method: 'POST' });
        loadQueue();
      } catch (_) {}
    }

    async function clearQueue() {
      try {
        await fetch('/api/queue/clear', { method: 'POST' });
        loadQueue();
      } catch (_) {}
    }

    async function loadLibrary() {
      try {
        const res = await fetch('/api/tracks');
        if (res.ok) {
          const tracks = await res.json();
          document.getElementById('cacheCount').innerText = `${tracks.length} Tracks`;
          const list = document.getElementById('libraryList');
          list.innerHTML = tracks.map(t => `
            <div class="track-item" onclick="playTrack('${t.video_id}', '${(t.title || '').replace(/'/g, "\\\\'")}', '${(t.artist || '').replace(/'/g, "\\\\'")}', '/media/${t.video_id}/cover.jpg'); haptic(20);">
              <img class="item-thumb" src="/media/${t.video_id}/cover.jpg" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect fill=%22%23111827%22 width=%22100%22 height=%22100%22/><text fill=%22%236B7280%22 font-size=%2240%22 x=%2250%22 y=%2260%22 text-anchor=%22middle%22>♪</text></svg>'">
              <div class="item-meta">
                <div class="item-title">${t.title || 'Unknown Track'}</div>
                <div class="item-artist">${t.artist || 'Unknown'} • ${t.bpm ? Math.round(t.bpm) + ' BPM' : ''}</div>
              </div>
              <div style="display:flex; gap:8px; align-items:center;">
                <button style="background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.15); color:#F8FAFC; border-radius:8px; padding:6px 10px; font-weight:700; font-size:11px; cursor:pointer;" onclick="event.stopPropagation(); addToQueue('${t.video_id}', '${(t.title || '').replace(/'/g, "\\\\'")}', '${(t.artist || '').replace(/'/g, "\\\\'")}', '', '/media/${t.video_id}/cover.jpg');">
                  + QUEUE
                </button>
                <span style="color:#00E5FF; font-size:18px;">▶</span>
              </div>
            </div>
          `).join('');
        }
      } catch (_) {}
    }

    let currentSearchMode = 'yt';
    function setSearchMode(mode) {
      currentSearchMode = mode;
      const btnYt = document.getElementById('searchModeYt');
      const btnHifi = document.getElementById('searchModeHifi');
      const directCard = document.getElementById('directUrlCard');
      const input = document.getElementById('searchInput');
      if (mode === 'yt') {
        btnYt.style.background = '#38BDF8';
        btnYt.style.color = '#040814';
        btnHifi.style.background = 'rgba(255,255,255,0.08)';
        btnHifi.style.color = '#F8FAFC';
        if (directCard) directCard.style.display = 'block';
        input.placeholder = 'Search YouTube Music...';
      } else {
        btnHifi.style.background = '#F59E0B';
        btnHifi.style.color = '#040814';
        btnYt.style.background = 'rgba(255,255,255,0.08)';
        btnYt.style.color = '#F8FAFC';
        if (directCard) directCard.style.display = 'none';
        input.placeholder = 'Search Hi-Fi FLAC library...';
      }
      const q = input.value.trim();
      if (q || mode === 'hifi') {
        executeSearch();
      }
    }

    async function executeSearch() {
      const q = document.getElementById('searchInput').value.trim();
      const cont = document.getElementById('searchResults');
      if (currentSearchMode === 'hifi') {
        cont.innerHTML = '<div style="text-align:center; padding:20px; color:#FBBF24;">Searching Lossless Library...</div>';
        try {
          const res = await fetch(`/api/hifi/search?q=${encodeURIComponent(q)}`);
          const items = await res.json();
          if (!items || items.length === 0) {
            cont.innerHTML = '<div style="text-align:center; padding:20px; color:#94A3B8;">No lossless tracks found matching your query.</div>';
            return;
          }
          cont.innerHTML = items.map(t => {
            const safeTitle = (t.title || '').replace(/'/g, "\\\\'");
            const safeArtist = (t.artist || '').replace(/'/g, "\\\\'");
            const coverUrl = t.key ? `/api/hifi/cover?key=${encodeURIComponent(t.key)}` : '';
            return `
            <div class="track-item" onclick="playHiFiTrack('${t.track_id}', '${safeTitle}', '${safeArtist}'); haptic(20);">
              <img class="item-thumb" src="${coverUrl}" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect fill=%22%23111827%22 width=%22100%22 height=%22100%22/><text fill=%22%23F59E0B%22 font-size=%2240%22 x=%2250%22 y=%2260%22 text-anchor=%22middle%22>♪</text></svg>'">
              <div class="item-meta">
                <div class="item-title">${t.title}</div>
                <div class="item-artist">${t.artist} • ${t.album || ''}</div>
                <div><span style="background:rgba(245,158,11,0.2); border:1px solid #F59E0B; color:#FBBF24; font-size:10px; font-weight:800; padding:2px 6px; border-radius:6px;">${t.format || 'FLAC'} LOSSLESS</span></div>
              </div>
              <div style="display:flex; flex-direction:row; gap:6px; align-items:center;">
                <button style="background:#F59E0B; border:none; border-radius:8px; padding:6px 12px; font-weight:800; font-size:11px; color:#040814; cursor:pointer;" onclick="event.stopPropagation(); playHiFiTrack('${t.track_id}', '${safeTitle}', '${safeArtist}'); haptic(20);">
                  PLAY
                </button>
                <button style="background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.2); border-radius:8px; padding:6px 9px; font-size:12px; color:#F8FAFC; cursor:pointer;" title="Add to Playlist" onclick="event.stopPropagation(); openAddToPlaylistModal('${t.track_id}', '${safeTitle}', '${safeArtist}'); haptic(20);">
                  + 📑
                </button>
              </div>
            </div>
            `;
          }).join('');
        } catch (e) {
          cont.innerHTML = `<div style="text-align:center; padding:20px; color:#F87171;">Search error: ${e}</div>`;
        }
        return;
      }

      if (!q) return;
      cont.innerHTML = '<div style="text-align:center; padding:20px; color:#94A3B8;">Searching YouTube Music...</div>';
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
        const items = await res.json();
        if (items.length === 0) {
          cont.innerHTML = '<div style="text-align:center; padding:20px; color:#94A3B8;">No results found.</div>';
          return;
        }
        cont.innerHTML = items.map(t => {
          const safeTitle = (t.title || '').replace(/'/g, "\\\\'");
          const safeArtist = (t.artist || '').replace(/'/g, "\\\\'");
          const badgeHtml = t.is_cached
            ? '<span class="badge-instant">⚡ Instant Play</span>'
            : '<span class="badge-cloud">☁️ Cache & Play</span>';
          return `
          <div class="track-item" onclick="playTrack('${t.video_id}', '${safeTitle}', '${safeArtist}', '${t.thumbnail_url || ''}'); haptic(20);">
            <img class="item-thumb" src="${t.thumbnail_url || ''}">
            <div class="item-meta">
              <div class="item-title">${t.title}</div>
              <div class="item-artist">${t.artist} ${t.duration ? '• ' + t.duration : ''}</div>
              <div>${badgeHtml}</div>
            </div>
            <div style="display:flex; flex-direction:column; gap:6px; align-items:flex-end;">
              <button style="background:#00E5FF; border:none; border-radius:8px; padding:6px 12px; font-weight:800; font-size:11px; color:#040814; cursor:pointer;" onclick="event.stopPropagation(); playTrack('${t.video_id}', '${safeTitle}', '${safeArtist}', '${t.thumbnail_url || ''}'); haptic(20);">
                ${t.is_cached ? 'PLAY' : 'CAST'}
              </button>
              <button style="background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.15); color:#F8FAFC; border-radius:8px; padding:5px 9px; font-weight:700; font-size:10px; cursor:pointer;" onclick="event.stopPropagation(); addToQueue('${t.video_id}', '${safeTitle}', '${safeArtist}', '${t.duration || ''}', '${t.thumbnail_url || ''}');">
                + QUEUE
              </button>
            </div>
          </div>
          `;
        }).join('');
      } catch (e) {
        cont.innerHTML = `<div style="text-align:center; padding:20px; color:#F87171;">Search error: ${e}</div>`;
      }
    }

    function castDirectUrl() {
      const input = document.getElementById('urlInput').value.trim();
      if (!input) return;
      let videoId = null;
      if (/^[a-zA-Z0-9_-]{11}$/.test(input)) {
        videoId = input;
      } else {
        const m = input.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/)|music\.youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/);
        if (m) videoId = m[1];
      }
      if (videoId) {
        haptic(30);
        playTrack(videoId, 'YouTube Link (' + videoId + ')', 'Direct Cast');
      } else {
        alert('Invalid YouTube URL or Video ID');
      }
    }

    async function loadSettings() {
      try {
        const res = await fetch('/api/settings');
        if (res.ok) {
          const data = await res.json();
          if (data.ambient_brightness) {
            const pct = Math.round(data.ambient_brightness * 100);
            document.getElementById('setBrightnessSlider').value = pct;
            document.getElementById('setBrightnessVal').innerText = pct + '%';
          }
          if (data.idle_timeout_seconds !== undefined) {
            document.getElementById('setTimeoutVal').innerText = data.idle_timeout_seconds + 's';
          }
        }
      } catch (_) {}
      loadAudioSettings();
    }

    let dacBalanceDebounce = null;
    function onDacBalanceInput(val) {
      const v = parseFloat(val);
      const text = v === 0 ? '0.0 dB (Center)' : (v < 0 ? `${v.toFixed(1)} dB (Left)` : `+${v.toFixed(1)} dB (Right)`);
      const el = document.getElementById('dacBalanceVal');
      if (el) el.innerText = text;
    }
    function onDacBalanceChange(val) {
      clearTimeout(dacBalanceDebounce);
      dacBalanceDebounce = setTimeout(() => {
        setAudioDacSetting('balance', parseFloat(val));
      }, 50);
    }

    async function loadAudioSettings() {
      try {
        const res = await fetch('/api/audio/settings');
        if (res.ok) {
          const data = await res.json();
          const s = data.settings || {};
          const live = data.live || {};
          
          if (live.PLL) {
            const badge = document.getElementById('dacLivePllBadge');
            if (badge) badge.innerText = 'PLL: ' + live.PLL.toUpperCase();
          }
          const stateEl = document.getElementById('dacLiveStateText');
          if (stateEl) {
            stateEl.innerText = `STATE: ${(live.state || 'PLAYING').toUpperCase()} · VOL: ${live['volume L/R'] || '+0.0 dB'}`;
          }

          function setPillActive(btnId, isActive) {
            const btn = document.getElementById(btnId);
            if (!btn) return;
            if (isActive) {
              btn.style.background = 'rgba(0,229,255,0.3)';
              btn.style.borderColor = '#00E5FF';
              btn.style.color = '#00E5FF';
              btn.style.fontWeight = 'bold';
            } else {
              btn.style.background = '';
              btn.style.borderColor = '';
              btn.style.color = '';
              btn.style.fontWeight = '';
            }
          }
          
          ['ringless', 'fir', 'iir', 'high-atten', 'fixed'].forEach(f => {
            setPillActive('filterBtn_' + f, s.filter === f);
          });

          ['0', '-6'].forEach(g => {
            setPillActive('gainBtn_' + g, String(s['analog-gain']) === g);
          });

          ['on', 'off'].forEach(b => {
            setPillActive('boostBtn_' + b, s.boost === b);
          });

          ['stereo', 'swap', 'mono-left', 'mono-right'].forEach(c => {
            setPillActive('chanBtn_' + c, s.channels === c);
          });

          if (s.balance !== undefined) {
            const balSlider = document.getElementById('dacBalanceSlider');
            if (balSlider) balSlider.value = s.balance;
            onDacBalanceInput(s.balance);
          }

          setPillActive('rampBtn_1_0_5dB', s.ramp === '1/0.5dB');
          setPillActive('rampBtn_1_1dB', s.ramp === '1/1dB');
          setPillActive('rampBtn_instant', s.ramp === 'instant');

          setPillActive('autoMuteBtn_off', s['auto-mute'] === 'off');
          setPillActive('autoMuteBtn_106ms', s['auto-mute'] === '106ms');
          setPillActive('autoMuteBtn_1_07s', s['auto-mute'] === '1.07s');

          ['on', 'off'].forEach(d => {
            setPillActive('deemphBtn_' + d, s.deemphasis === d);
          });

          ['on', 'off'].forEach(m => {
            setPillActive('muteBtn_' + m, s.mute === m);
          });

          ['4', '10', '12', '14'].forEach(q => {
            setPillActive('resampleBtn_' + q, String(s['pw-resample-quality']) === q);
          });

          ['on', 'off'].forEach(k => {
            setPillActive('keepAwakeBtn_' + k, s['pw-keep-awake'] === k);
          });

          ['on', 'off'].forEach(h => {
            setPillActive('hiresBtn_' + h, s['pw-hires'] === h);
          });

          if (s['pw-dither']) {
            const sel = document.getElementById('ditherSelect');
            if (sel) sel.value = s['pw-dither'];
          }
        }
      } catch (_) {}
    }

    async function setAudioDacSetting(key, val) {
      try {
        await fetch('/api/audio/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ [key]: val })
        });
        await loadAudioSettings();
      } catch (_) {}
    }

    async function applyDacBestQuality() {
      try {
        await fetch('/api/audio/preset/best-quality', { method: 'POST' });
        await loadAudioSettings();
      } catch (_) {}
    }

    async function resetDacDefaults() {
      if (confirm('Reset all DAC Pro & PipeWire audio parameters to factory defaults?')) {
        try {
          await fetch('/api/audio/reset', { method: 'POST' });
          await loadAudioSettings();
        } catch (_) {}
      }
    }

    async function updateRemoteSetting(key, val) {
      try {
        await fetch('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ [key]: val })
        });
        loadSettings();
      } catch (_) {}
    }

    async function calibrateKinematics() {
      try {
        await fetch('/api/control', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'calibrate' })
        });
        alert('Homing calibration initiated.');
      } catch (_) {}
    }

    async function restartServices() {
      if (confirm('Restart background juggler daemons?')) {
        try {
          await fetch('/api/system/restart-services', { method: 'POST' });
          alert('Restart command sent.');
        } catch (_) {}
      }
    }

    // Hi-Fi Audiophile Library Handlers
    let hifiTreeData = null;
    let syncPollTimer = null;

    function updateDriveSyncUI(status, msg) {
      const statusEl = document.getElementById('syncStatus');
      if (!statusEl) return;
      if (status === 'syncing' || status === 'scanning') {
        statusEl.innerHTML = `<span style="color:#F59E0B; font-weight:800;">🔄 ${msg || 'Syncing Google Drive in background...'}</span>`;
        if (!syncPollTimer) {
          syncPollTimer = setInterval(pollSyncStatus, 2500);
        }
      } else if (status === 'ready') {
        statusEl.innerHTML = `<span style="color:#10B981; font-weight:700;">🟢 ${msg || 'Library synced and up to date.'}</span>`;
        if (syncPollTimer) {
          clearInterval(syncPollTimer);
          syncPollTimer = null;
        }
        loadDriveFolders();
      } else if (status === 'error') {
        statusEl.innerHTML = `<span style="color:#F87171; font-weight:700;">⚠️ ${msg || 'Sync error.'}</span>`;
        if (syncPollTimer) {
          clearInterval(syncPollTimer);
          syncPollTimer = null;
        }
      } else {
        statusEl.innerText = msg || 'Ready to sync.';
      }
    }

    async function pollSyncStatus() {
      try {
        const res = await fetch('/api/hifi/sync_status');
        if (res.ok) {
          const data = await res.json();
          updateDriveSyncUI(data.status, data.message);
          if (data.status === 'ready') {
            loadHiFiTree();
          }
        }
      } catch (_) {}
    }

    async function loadDriveFolders() {
      const cont = document.getElementById('driveFoldersList');
      if (!cont) return;
      try {
        const res = await fetch('/api/hifi/drive_folders');
        if (res.ok) {
          const data = await res.json();
          const folders = data.folders || [];
          if (folders.length === 0) {
            cont.innerHTML = '<div style="font-size:10px; color:#64748B;">No external folders added yet.</div>';
            return;
          }
          cont.innerHTML = folders.map(f => {
            const fId = (typeof f === 'object' ? (f.folder_id || f.id || '') : f) || '';
            const disp = fId.length > 20 ? fId.substring(0, 18) + '...' : fId;
            return `
            <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(0,0,0,0.25); border:1px solid rgba(255,255,255,0.06); padding:6px 10px; border-radius:8px;">
              <span style="font-size:11px; color:#E2E8F0; font-family:monospace;">📁 ${disp}</span>
              <span style="font-size:10px; color:#FBBF24; font-weight:700;">Active</span>
            </div>
          `;
          }).join('');
        }
      } catch (_) {}
    }

    async function syncDrive() {
      const inputEl = document.getElementById('driveUrlInput');
      const url = inputEl ? inputEl.value.trim() : '';
      const statusEl = document.getElementById('syncStatus');
      updateDriveSyncUI('syncing', url ? 'Scanning newly added Google Drive folder...' : 'Updating Google Drive library in background...');
      try {
        const payload = url ? { folder_url: url } : {};
        const res = await fetch('/api/hifi/sync_drive', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          if (!syncPollTimer) {
            syncPollTimer = setInterval(pollSyncStatus, 2000);
          }
        } else {
          statusEl.innerText = 'Sync request failed.';
        }
      } catch (e) {
        statusEl.innerText = 'Sync error: ' + e;
      }
    }

    async function rescanHiFi() {
      const btn = document.getElementById('hifiRefreshBtn');
      if (btn) btn.innerHTML = '<span>⏳ Syncing...</span>';
      try {
        await fetch('/api/hifi/sync_drive', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({})
        });
        if (!syncPollTimer) {
          syncPollTimer = setInterval(pollSyncStatus, 2000);
        }
      } catch (e) {
        console.error('Rescan error:', e);
      } finally {
        if (btn) btn.innerHTML = '<span>🔄 Rescan</span>';
      }
    }


    async function loadHiFiTree() {
      const cont = document.getElementById('hifiTreeContainer');
      const countEl = document.getElementById('hifiTrackCount');
      try {
        const res = await fetch('/api/hifi/tree');
        if (res.ok) {
          hifiTreeData = await res.json();
          const totalTracks = hifiTreeData.total_tracks || 0;
          const totalAlbums = hifiTreeData.total_albums || 0;
          if (countEl) countEl.innerText = `${totalTracks} Tracks • ${totalAlbums} Albums`;
          renderHiFiTree(hifiTreeData, cont);
        } else {
          cont.innerHTML = '<div style="text-align:center; padding:20px; color:#F87171;">Failed to load Hi-Fi catalog.</div>';
        }
      } catch (e) {
        cont.innerHTML = `<div style="text-align:center; padding:20px; color:#F87171;">Error: ${e}</div>`;
      }
    }

    function renderHiFiTree(data, container) {
      if (!data.artists || data.artists.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:24px; color:#64748B;">No Hi-Fi tracks found in /data/hifi_music/. Sync above to download.</div>';
        return;
      }
      let html = '';
      data.artists.forEach((artist, aIdx) => {
        html += `
          <div class="hifi-tree-node">
            <div class="hifi-artist-header" onclick="toggleHiFiSection('art_${aIdx}')">
              <span style="color:#FBBF24;">🎙</span>
              <span style="flex:1;">${artist.name}</span>
              <span style="font-size:11px; color:#94A3B8;">${artist.albums.length} albums ▾</span>
            </div>
            <div id="art_${aIdx}" style="display:block;">
        `;
        artist.albums.forEach((album, albIdx) => {
          html += `
            <div class="hifi-album-group">
              <div class="hifi-album-header" onclick="toggleHiFiSection('alb_${aIdx}_${albIdx}')">
                <span style="color:#FBBF24;">💿</span>
                <span style="flex:1;">${album.name}</span>
                <span style="font-size:10px; color:#CBD5E1;">${album.tracks.length} tracks ▾</span>
              </div>
              <div id="alb_${aIdx}_${albIdx}" style="display:block;">
          `;
          album.tracks.forEach(track => {
            const cleanTitle = (track.title || 'Unknown').replace(/'/g, "\\'");
            const cleanArtist = (track.artist || artist.name || '').replace(/'/g, "\\'");
            const fmt = track.format || 'FLAC';
            const depth = track.bit_depth ? `${track.bit_depth}-bit` : '';
            const rate = track.sample_rate_hz ? `${(track.sample_rate_hz / 1000).toFixed(1)}k` : '';
            const spec = [depth, rate, fmt].filter(Boolean).join(' • ');

            html += `
              <div class="hifi-track-item">
                <div style="flex:1; min-width:0; padding-right:8px;" onclick="playHiFiTrack('${track.id}', '${cleanTitle}', '${cleanArtist}'); haptic(20);">
                  <div style="font-size:13px; font-weight:700; color:#F8FAFC; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${track.title || 'Untitled Track'}</div>
                  <div style="font-size:10px; color:#FBBF24; margin-top:2px; font-weight:700;">${spec}</div>
                </div>
                <div style="display:flex; gap:6px; align-items:center;">
                  <button class="action-btn" style="padding:6px 10px; font-size:11px; background:rgba(251,191,36,0.18); border:1px solid rgba(251,191,36,0.4); color:#FBBF24; font-weight:800;" onclick="event.stopPropagation(); playHiFiTrack('${track.id}', '${cleanTitle}', '${cleanArtist}'); haptic(25);">▶ PLAY</button>
                  <button style="background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.15); color:#F8FAFC; border-radius:8px; padding:6px 9px; font-size:12px; cursor:pointer;" title="Add to Playlist" onclick="event.stopPropagation(); openAddToPlaylistModal('${track.id}', '${cleanTitle}', '${cleanArtist}'); haptic(20);">+ 📑</button>
                </div>
              </div>
            `;
          });
          html += `
              </div>
            </div>
          `;
        });
        html += `
            </div>
          </div>
        `;
      });
      container.innerHTML = html;
    }

    function toggleHiFiSection(id) {
      const el = document.getElementById(id);
      if (el) {
        el.style.display = el.style.display === 'none' ? 'block' : 'none';
      }
    }

    // Custom Playlists & Favorites Web Remote Logic
    async function loadWebPlaylists() {
      const cont = document.getElementById('webPlaylistsContainer');
      if (!cont) return;
      try {
        const res = await fetch('/api/hifi/playlists');
        if (res.ok) {
          const data = await res.json();
          const list = data.playlists || [];
          if (list.length === 0) {
            cont.innerHTML = '<div style="color:#64748B; font-size:12px; text-align:center; padding:10px;">No custom playlists yet. Tap "+ New Playlist" to create one.</div>';
            return;
          }
          cont.innerHTML = list.map(pl => `
            <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.04); border:1px solid rgba(251,191,36,0.25); border-radius:12px; padding:10px 12px;">
              <div style="flex:1; min-width:0; padding-right:10px;" onclick="playPlaylistWeb('${pl.id}')">
                <div style="font-size:13px; font-weight:800; color:#F8FAFC; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${pl.name}</div>
                <div style="font-size:10px; color:#FBBF24; margin-top:2px; font-weight:700;">${pl.track_count || 0} TRACKS</div>
              </div>
              <div style="display:flex; gap:6px; align-items:center;">
                <button class="action-btn" style="padding:6px 12px; font-size:11px; background:rgba(251,191,36,0.18); border:1px solid rgba(251,191,36,0.4); color:#FBBF24; font-weight:800;" onclick="playPlaylistWeb('${pl.id}'); haptic(25);">▶ PLAY</button>
                <button style="background:rgba(239,68,68,0.15); border:1px solid rgba(239,68,68,0.35); color:#F87171; border-radius:8px; padding:6px 8px; font-size:11px; cursor:pointer;" title="Delete" onclick="deletePlaylistWeb('${pl.id}', '${pl.name.replace(/'/g, "\\'")}'); haptic(30);">🗑</button>
              </div>
            </div>
          `).join('');
        }
      } catch (e) {
        cont.innerHTML = `<div style="color:#F87171; font-size:12px;">Failed to load playlists: ${e}</div>`;
      }
    }

    async function promptCreatePlaylist() {
      const name = prompt('Enter a name for the new playlist:');
      if (!name || !name.trim()) return;
      try {
        const res = await fetch('/api/hifi/playlists', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: name.trim() })
        });
        if (res.ok) {
          loadWebPlaylists();
        } else {
          alert('Failed to create playlist');
        }
      } catch (e) {
        alert('Error creating playlist: ' + e);
      }
    }

    async function deletePlaylistWeb(playlistId, name) {
      if (!confirm(`Delete playlist "${name}"?`)) return;
      try {
        const res = await fetch(`/api/hifi/playlists/${playlistId}`, { method: 'DELETE' });
        if (res.ok) {
          loadWebPlaylists();
        }
      } catch (e) {
        alert('Delete failed: ' + e);
      }
    }

    async function openAddToPlaylistModal(trackId, title, artist) {
      const modal = document.getElementById('hifiModal');
      const titleEl = document.getElementById('hifiModalTitle');
      const bodyEl = document.getElementById('hifiModalBody');
      if (!modal || !bodyEl) return;

      titleEl.innerText = `Add to Playlist`;
      bodyEl.innerHTML = '<div style="color:#64748B; font-size:12px; text-align:center; padding:12px;">Loading playlists...</div>';
      modal.style.display = 'flex';

      try {
        const res = await fetch('/api/hifi/playlists');
        const data = await res.json();
        const playlists = data.playlists || [];

        let html = `
          <div style="font-size:12px; color:#E2E8F0; margin-bottom:8px; font-weight:700;">
            ${title} <span style="color:#94A3B8; font-weight:400;">by ${artist}</span>
          </div>
          <button style="background:rgba(251,191,36,0.18); border:1px solid rgba(251,191,36,0.4); color:#FBBF24; border-radius:10px; padding:10px; font-weight:800; font-size:12px; cursor:pointer; text-align:left; margin-bottom:6px;" onclick="promptCreatePlaylist().then(() => openAddToPlaylistModal('${trackId}', '${title}', '${artist}'))">
            + Create New Playlist
          </button>
        `;

        if (playlists.length === 0) {
          html += '<div style="font-size:11px; color:#64748B; padding:8px 0;">No existing playlists. Create one above!</div>';
        } else {
          playlists.forEach(pl => {
            html += `
              <button style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#F8FAFC; border-radius:10px; padding:10px 12px; font-weight:700; font-size:12px; cursor:pointer; text-align:left; display:flex; justify-content:space-between; align-items:center;" onclick="addTrackToPlaylistWeb('${pl.id}', '${trackId}')">
                <span>📑 ${pl.name}</span>
                <span style="color:#FBBF24; font-size:10px;">${pl.track_count || 0} tracks</span>
              </button>
            `;
          });
        }
        bodyEl.innerHTML = html;
      } catch (e) {
        bodyEl.innerHTML = `<div style="color:#F87171; font-size:12px;">Error: ${e}</div>`;
      }
    }

    async function addTrackToPlaylistWeb(playlistId, trackId) {
      try {
        const res = await fetch(`/api/hifi/playlists/${playlistId}/add`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ track_id: trackId })
        });
        if (res.ok) {
          closeHifiModal();
          loadWebPlaylists();
          haptic(30);
        } else {
          alert('Failed to add track.');
        }
      } catch (e) {
        alert('Error: ' + e);
      }
    }

    function closeHifiModal() {
      const modal = document.getElementById('hifiModal');
      if (modal) modal.style.display = 'none';
    }

    async function playHiFiTrack(trackId, title, artist) {
      try {
        localCastingVideoId = trackId;
        if (title) document.getElementById('trackTitle').innerText = title;
        if (artist) document.getElementById('trackArtist').innerText = artist;
        document.getElementById('coverImg').src = `/api/hifi/cover?track_id=${trackId}`;
        const hifiBadge = document.getElementById('hifiBadge');
        if (hifiBadge) {
          hifiBadge.style.display = 'inline-block';
          hifiBadge.innerText = '📀 24-BIT / LOSSLESS FLAC';
        }

        switchTab('tabNowPlaying', document.querySelectorAll('.nav-btn')[0]);

        const res = await fetch('/api/hifi/play', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ track_id: trackId })
        });
        if (res.ok) {
          setTimeout(fetchInitialState, 300);
        }
      } catch (e) {
        alert('Failed to play Hi-Fi track: ' + e);
      }
    }

    async function playSmartMix(type, artist) {
      try {
        let url = `/api/hifi/smart_playlist?type=${type}&limit=50`;
        if (artist) url += `&artist=${encodeURIComponent(artist)}`;
        const res = await fetch(url);
        const data = await res.json();
        if (data && data.tracks && data.tracks.length > 0) {
          const first = data.tracks[0];
          await playHiFiTrack(first.track_id || first.id, first.title, first.artist);
          for (let i = 1; i < data.tracks.length; i++) {
            const t = data.tracks[i];
            await fetch('/api/queue/add', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                video_id: 'hifi_' + (t.track_id || t.id),
                title: t.title,
                artist: t.artist,
                album: t.album,
                position: 'end'
              })
            });
          }
          setTimeout(loadQueue, 500);
        }
      } catch (e) {
        alert('Smart mix error: ' + e);
      }
    }

    async function playPlaylistWeb(playlistId) {
      try {
        const res = await fetch(`/api/hifi/playlists/${playlistId}/play`, { method: 'POST' });
        const data = await res.json();
        switchTab('tabNowPlaying', document.querySelectorAll('.nav-btn')[0]);
        setTimeout(fetchInitialState, 400);
        setTimeout(loadQueue, 500);
      } catch (e) {
        alert('Playlist play error: ' + e);
      }
    }

    // Initialize immediately
    fetchInitialState();
    loadLibrary();
    loadQueue();
    loadSettings();
    loadHiFiTree();
    loadDriveFolders();
    loadWebPlaylists();
    pollSyncStatus();
    connectSocket();
  </script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def serve_remote():
    return HTMLResponse(content=HTML_PAGE, status_code=200)

@app.get("/media/{video_id}/{filename}")
async def serve_media(video_id: str, filename: str):
    local_path = os.path.join(CACHE_DIR, video_id, filename)
    if os.path.isfile(local_path):
        media_type = "image/jpeg" if filename.endswith((".jpg", ".jpeg")) else "video/mp4"
        return FileResponse(local_path, media_type=media_type)
    # Stream from Core Playback Manager without redirecting external client to 127.0.0.1
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/media/{video_id}/{filename}")
        resp = urllib.request.urlopen(req, timeout=5)
        return StreamingResponse(resp, media_type=resp.headers.get("Content-Type", "application/octet-stream"))
    except Exception:
        raise HTTPException(status_code=404, detail="Media not found")

@app.get("/api/state")
async def get_state():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/state")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/control")
async def post_control(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/control",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/tracks")
async def get_tracks():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/tracks")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return []

@app.get("/api/search")
async def get_search(q: str):
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/search?q={urllib.parse.quote(q)}")
        with urllib.request.urlopen(req, timeout=6) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return []

@app.get("/api/hifi/search")
async def get_hifi_search(q: str = "", limit: int = 50):
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/hifi/search?q={urllib.parse.quote(q)}&limit={limit}")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return []

@app.post("/api/play/{video_id}")
async def post_play(video_id: str, request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/play/{video_id}",
            data=body if body else b"",
            headers={"Content-Type": "application/json"} if body else {},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/cache/{video_id}")
async def post_cache(video_id: str):
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/cache/{video_id}", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/cache/status/{video_id}")
async def get_cache_status(video_id: str):
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/cache/status/{video_id}")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/queue")
async def get_queue():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/queue")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return []

@app.post("/api/queue/add")
async def post_queue_add(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/queue/add",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/queue/remove/{index}")
async def post_queue_remove(index: int):
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/queue/remove/{index}", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/queue/clear")
async def post_queue_clear():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/queue/clear", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/queue/next")
async def post_queue_next():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/queue/next", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/queue/prev")
async def post_queue_prev():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/queue/prev", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/settings")
async def get_settings():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/settings")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {}

@app.post("/api/settings")
async def post_settings(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/settings",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/system/ip")
async def get_system_ip():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/system/ip")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"ip": "127.0.0.1", "web_url": "http://127.0.0.1:8080"}

@app.get("/api/system/qr.png")
async def get_system_qr():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/system/qr.png")
        resp = urllib.request.urlopen(req, timeout=5)
        return StreamingResponse(resp, media_type="image/png")
    except Exception:
        raise HTTPException(status_code=500, detail="QR generation failed")

@app.post("/api/cache/clear")
async def post_cache_clear():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/cache/clear", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/hifi/tree")
async def get_hifi_tree():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/hifi/tree")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e), "artists": []}

@app.post("/api/hifi/scan")
async def post_hifi_scan():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/hifi/scan", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e), "artists": []}

@app.post("/api/hifi/play")
async def post_hifi_play(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/play",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/hifi/sync_drive")
async def post_hifi_sync_drive(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/sync_drive",
            data=body if (body and len(body.strip()) > 0) else b"{}",
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/hifi/sync_status")
async def get_hifi_sync_status():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/hifi/sync_status")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/hifi/drive_folders")
async def get_hifi_drive_folders():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/hifi/drive_folders")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"folders": []}

@app.get("/api/hifi/cover")
async def get_hifi_cover(request: Request):
    try:
        query_str = str(request.query_params)
        target_url = f"{PLAYBACK_MANAGER_URL}/api/hifi/cover?{query_str}" if query_str else f"{PLAYBACK_MANAGER_URL}/api/hifi/cover"
        req = urllib.request.Request(target_url)
        resp = urllib.request.urlopen(req, timeout=5)
        return StreamingResponse(resp, media_type="image/jpeg")
    except Exception:
        raise HTTPException(status_code=404, detail="HiFi cover not found")

@app.get("/api/hifi/playlists")
async def get_hifi_playlists_remote():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/hifi/playlists")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e), "playlists": []}

@app.get("/api/hifi/playlists/{playlist_id}")
async def get_hifi_playlist_detail_remote(playlist_id: str):
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/hifi/playlists/{urllib.parse.quote(playlist_id)}")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/hifi/playlists")
async def post_hifi_playlist_create_remote(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/playlists",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/hifi/playlists/{playlist_id}/add")
async def post_hifi_playlist_add_remote(playlist_id: str, request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/playlists/{urllib.parse.quote(playlist_id)}/add",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/hifi/playlists/{playlist_id}/remove")
async def post_hifi_playlist_remove_remote(playlist_id: str, request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/playlists/{urllib.parse.quote(playlist_id)}/remove",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.delete("/api/hifi/playlists/{playlist_id}")
async def delete_hifi_playlist_remote(playlist_id: str):
    try:
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/playlists/{urllib.parse.quote(playlist_id)}",
            data=b"",
            method="DELETE"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/hifi/playlists/{playlist_id}/play")
async def post_hifi_playlist_play_remote(playlist_id: str, request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/playlists/{urllib.parse.quote(playlist_id)}/play",
            data=body if body else b"{}",
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/hifi/favorites/toggle")
async def post_hifi_favorite_toggle_remote(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/hifi/favorites/toggle",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/hifi/smart_playlist")
async def get_hifi_smart_playlist_remote(request: Request):
    try:
        query_str = str(request.query_params)
        target_url = f"{PLAYBACK_MANAGER_URL}/api/hifi/smart_playlist?{query_str}" if query_str else f"{PLAYBACK_MANAGER_URL}/api/hifi/smart_playlist"
        req = urllib.request.Request(target_url)
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/search/history/clear")
async def post_search_history_clear():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/search/history/clear", data=b"", method="POST")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

# --- Audiophile DAC Audio Proxy Endpoints ---

@app.get("/api/audio/settings")
async def get_audio_settings_proxy():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/audio/settings")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e), "settings": {}, "live": {}}

@app.post("/api/audio/settings")
async def post_audio_settings_proxy(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/audio/settings",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/audio/preset/best-quality")
async def post_audio_preset_proxy():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/audio/preset/best-quality", data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/audio/reset")
async def post_audio_reset_proxy():
    try:
        req = urllib.request.Request(f"{PLAYBACK_MANAGER_URL}/api/audio/reset", data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/audio/volume")
async def post_audio_volume_proxy(request: Request):
    try:
        body = await request.body()
        req = urllib.request.Request(
            f"{PLAYBACK_MANAGER_URL}/api/audio/volume",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.websocket("/ws/telemetry")
async def websocket_telemetry_proxy(client_ws: WebSocket):
    await client_ws.accept()
    # Read from Unix domain socket directly
    reader = None
    writer = None
    try:
        reader, writer = await asyncio.open_unix_connection("/tmp/juggler_telemetry.sock")
        while True:
            line = await reader.readline()
            if not line:
                break
            text = line.decode('utf-8').strip()
            if text:
                await client_ws.send_text(text)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"[WS Proxy Error] {e}")
    finally:
        if writer:
            writer.close()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)
