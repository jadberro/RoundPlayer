from PIL import Image

with open('/tmp/fb.raw', 'rb') as f:
    raw = f.read(1080 * 1080 * 4)

img = Image.frombytes('RGBA', (1080, 1080), raw, 'raw', 'BGRA')
img.save('/tmp/live_screen.png')
print("Saved /tmp/live_screen.png")
