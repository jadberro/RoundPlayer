import requests
from gdown.download_folder import _download_and_parse_google_drive_link, _get_directory_structure

sess = requests.Session()
sess.headers.update({
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
})

print("Testing _download_and_parse_google_drive_link with 10s timeout...", flush=True)
try:
    root = _download_and_parse_google_drive_link(
        sess=sess,
        folder_id='YOUR_PUBLIC_FOLDER_ID',
        quiet=False,
        verify=True,
        timeout=10
    )
    print(f"Success! Root: {root}", flush=True)
    items = _get_directory_structure(gdrive_file=root, previous_path='/data/hifi_music')
    print(f"Total items: {len(items)}", flush=True)
    for f, p in items[:5]:
        print(f" - {f.name} -> {p}", flush=True)
except Exception as e:
    print(f"Error: {e}", flush=True)
