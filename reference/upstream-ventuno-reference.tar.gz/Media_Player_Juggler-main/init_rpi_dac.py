#!/usr/bin/env python3
import subprocess
import time

SUDO_PASS = "<REDACTED_PASSWORD>"

def sh(cmd: str):
    subprocess.check_call(
        f"echo '{SUDO_PASS}' | sudo -S {cmd}",
        shell=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

def init():
    # 1. Page 0 selection
    sh("i2cset -f -y 0 0x4c 0x00 0x00")
    # 2. Software reset
    sh("i2cset -f -y 0 0x4c 0x01 0x11")
    time.sleep(0.01)
    sh("i2cset -f -y 0 0x4c 0x01 0x00")
    # 3. Normal operating mode (Standby off)
    sh("i2cset -f -y 0 0x4c 0x02 0x00")
    # 4. Digital mute off
    sh("i2cset -f -y 0 0x4c 0x03 0x00")
    # 5. Disable auto-mute shutdown
    sh("i2cset -f -y 0 0x4c 0x07 0x00")
    # 6. Configure PLL to use BCK as reference clock
    sh("i2cset -f -y 0 0x4c 0x0e 0x10")
    sh("i2cset -f -y 0 0x4c 0x25 0x08")
    sh("i2cset -f -y 0 0x4c 0x04 0x01")

    # 7. CRITICAL FIX: Crossbar Audio Routing (Reg 40..43)
    # Map Left DAC input to I2S Left (0x00), Right DAC input to I2S Right (0x01)
    sh("i2cset -f -y 0 0x4c 0x28 0x00")
    sh("i2cset -f -y 0 0x4c 0x29 0x00")
    sh("i2cset -f -y 0 0x4c 0x2a 0x01")
    sh("i2cset -f -y 0 0x4c 0x2b 0x01")

    # 8. Enable GPIO1-6 as outputs
    sh("i2cset -f -y 0 0x4c 0x08 0x3f")
    # Drive all GPIOs high (releases mute relays & enables headphone amp)
    for g in [0x50, 0x51, 0x52, 0x53, 0x54, 0x55]:
        sh(f"i2cset -f -y 0 0x4c {hex(g)} 0x02")

    # 9. Set digital volume to 0.0 dB (full scale)
    sh("i2cset -f -y 0 0x4c 0x3d 0x00")
    sh("i2cset -f -y 0 0x4c 0x3e 0x00")

    # 10. Page 1: Power on analog output drivers
    sh("i2cset -f -y 0 0x4c 0x00 0x01")
    sh("i2cset -f -y 0 0x4c 0x01 0x01")
    sh("i2cset -f -y 0 0x4c 0x02 0x00")
    sh("i2cset -f -y 0 0x4c 0x00 0x00")

if __name__ == "__main__":
    init()
    res = subprocess.check_output("echo '<REDACTED_PASSWORD>' | sudo -S i2cget -f -y 0 0x4c 0x76", shell=True).decode().strip().split()[-1]
    pll = subprocess.check_output("echo '<REDACTED_PASSWORD>' | sudo -S i2cget -f -y 0 0x4c 0x5e", shell=True).decode().strip().split()[-1]
    routing = subprocess.check_output("echo '<REDACTED_PASSWORD>' | sudo -S i2cget -f -y 0 0x4c 0x28", shell=True).decode().strip().split()[-1]
    print(f"PCM5122 Status: FS={res}, PLL={pll}, Routing={routing}")
