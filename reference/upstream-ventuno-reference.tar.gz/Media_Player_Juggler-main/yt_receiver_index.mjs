import YouTubeCastReceiver, { Player } from 'yt-cast-receiver';

let stopTimer = null;

class JugglerPlayer extends Player {
  async doPlay(video, position) {
    if (stopTimer) {
      clearTimeout(stopTimer);
      stopTimer = null;
    }
    console.log(`[Cast Receiver] Play requested: ${video.id} (${video.title || 'Unknown'}) from pos ${position || 0}s`);
    try {
      // Dispatch directly to Playback Manager (sets target_track_id and starts caching or immediate play)
      await fetch(`http://127.0.0.1:8000/api/play/${video.id}`, { method: 'POST' });
      console.log(`[Cast Receiver] Successfully dispatched ${video.id} to Playback Manager.`);
      return true;
    } catch (e) {
      console.error('[Cast Receiver] Error notifying playback manager:', e);
      return false;
    }
  }

  async doPause() {
    console.log('[Cast Receiver] Pause requested');
    try {
      await fetch('http://127.0.0.1:8000/api/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'pause' })
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  async doResume() {
    console.log('[Cast Receiver] Resume requested');
    try {
      await fetch('http://127.0.0.1:8000/api/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'play' })
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  async doStop() {
    console.log('[Cast Receiver] Stop requested (debouncing to prevent track-change interruption)');
    if (stopTimer) clearTimeout(stopTimer);
    stopTimer = setTimeout(async () => {
      try {
        await fetch('http://127.0.0.1:8000/api/control', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'pause' })
        });
      } catch (e) {}
    }, 450);
    return true;
  }

  async doSeek(position) {
    console.log(`[Cast Receiver] Seek to ${position}s`);
    return true;
  }

  async doSetVolume(volume) {
    console.log(`[Cast Receiver] Set volume: ${volume.level}%`);
    try {
      await fetch('http://127.0.0.1:8000/api/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'volume', value: volume.level })
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  async doGetVolume() {
    try {
      const res = await fetch('http://127.0.0.1:8000/api/state');
      if (res.ok) {
        const d = await res.json();
        return { level: Math.round(d.volume !== undefined ? d.volume : 80), muted: false };
      }
    } catch (_) {}
    return { level: 80, muted: false };
  }

  async doGetPosition() {
    try {
      const res = await fetch('http://127.0.0.1:8000/api/state');
      if (res.ok) {
        const d = await res.json();
        return Math.round(d.playback_position_s || 0);
      }
    } catch (_) {}
    return 0;
  }

  async doGetDuration() {
    return 240;
  }
}

const player = new JugglerPlayer();
const receiver = new YouTubeCastReceiver(player, {
  dial: {
    port: 8008,
  },
  device: {
    name: 'Living Room Juggler',
    screenName: 'Living Room Juggler',
    brand: 'Arduino',
    model: '3-RRS Ballistic Juggler'
  },
  logLevel: 'INFO'
});

receiver.on('senderConnect', (sender) => {
  console.log(`[Cast Receiver] Sender connected: ${sender.name}`);
});

receiver.on('senderDisconnect', (sender) => {
  console.log(`[Cast Receiver] Sender disconnected: ${sender.name}`);
});

console.log('[Cast Receiver] Starting YouTube Cast Receiver on port 8008...');
await receiver.start();
console.log('[Cast Receiver] YouTube Cast Receiver is active and advertising as "Living Room Juggler"');
